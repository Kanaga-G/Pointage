import React from 'react'
import { createRoot } from 'react-dom/client'
import LandingPage from './pages/LandingPage'
import Login from './pages/Login'

// Import CSS
import './styles/globals.css'

function App() {
  return (
    <div>
      <h1 style={{ padding: '20px', textAlign: 'center', color: '#2563eb' }}>
        🎉 Xpert Pro - Application Récupérée !
      </h1>
      
      <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
        <div style={{ 
          backgroundColor: '#f0fdf4', 
          padding: '20px', 
          borderRadius: '8px', 
          marginBottom: '20px',
          border: '1px solid #bbf7d0'
        }}>
          <h2>📱 Pages Disponibles</h2>
          <ul style={{ listStyle: 'none', padding: 0 }}>
            <li style={{ marginBottom: '10px' }}>
              <a href="/" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 'bold' }}>
                🏠 Landing Page
              </a>
            </li>
            <li style={{ marginBottom: '10px' }}>
              <a href="/login" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 'bold' }}>
                🔐 Page de Login
              </a>
            </li>
            <li style={{ marginBottom: '10px' }}>
              <a href="/admin" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 'bold' }}>
                👑 Admin Dashboard
              </a>
            </li>
            <li style={{ marginBottom: '10px' }}>
              <a href="/employe" style={{ color: '#2563eb', textDecoration: 'none', fontWeight: 'bold' }}>
                👤 Employé Dashboard
              </a>
            </li>
          </ul>
        </div>

        <div style={{ 
          backgroundColor: '#dbeafe', 
          padding: '20px', 
          borderRadius: '8px',
          border: '1px solid #93c5fd'
        }}>
          <h2>🌐 Serveurs Actifs</h2>
          <p><strong>Frontend:</strong> http://localhost:5173</p>
          <p><strong>Backend:</strong> http://localhost:3003</p>
        </div>

        <div style={{ 
          backgroundColor: '#fefce8', 
          padding: '20px', 
          borderRadius: '8px',
          border: '1px solid #fde047'
        }}>
          <h2>🔐 Identifiants de Test</h2>
          <p><strong>Admin:</strong> admin@xpertpro.com / admin123</p>
          <p><strong>Employé:</strong> jean.dupont@xpertpro.com / password123</p>
        </div>

        <div style={{ 
          backgroundColor: '#f3f4f6', 
          padding: '20px', 
          borderRadius: '8px',
          textAlign: 'center',
          marginTop: '20px'
        }}>
          <h2 style={{ color: '#059669' }}>🚀 Application Prête !</h2>
          <p>Toutes vos données sont récupérées et fonctionnelles</p>
        </div>
      </div>
    </div>
  )
}

// Rendu de l'application
const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(<App />);
} else {
  console.error('Container #root non trouvé');
}
