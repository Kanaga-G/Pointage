export interface ApiError {
  message: string;
  status?: number;
}

const DEFAULT_BASE_URL = "/api";

export class ApiClient {
  constructor(private readonly baseUrl: string = DEFAULT_BASE_URL) {}

  private buildHeaders(initHeaders?: HeadersInit): Headers {
    const headers = new Headers(initHeaders);
    const token = localStorage.getItem('auth_token');
    if (token && !headers.has('Authorization')) {
      headers.set('Authorization', `Bearer ${token}`);
    }
    return headers;
  }

  private buildUrl(path: string): string {
    if (path.startsWith("http://") || path.startsWith("https://")) {
      return path;
    }
    // Si le chemin commence déjà par /api, ne pas ajouter la base
    if (path.startsWith("/api")) {
      return path;
    }
    const normalizedBase = this.baseUrl.replace(/\/+$/, "");
    const normalizedPath = path.replace(/^\/+/, "");
    return `${normalizedBase}/${normalizedPath}`;
  }

  async get<T>(path: string): Promise<T> {
    const response = await fetch(this.buildUrl(path), {
      credentials: "include",
      headers: this.buildHeaders()
    });
    return this.handleResponse<T>(response);
  }

  async post<TPayload, TResponse>(path: string, payload: TPayload | FormData, options?: RequestInit): Promise<TResponse> {
    const isFormData = payload instanceof FormData;
    const headers = this.buildHeaders(options?.headers);
    if (!isFormData && !headers.has('Content-Type')) {
      headers.set('Content-Type', 'application/json');
    }

    const response = await fetch(this.buildUrl(path), {
      method: "POST",
      headers,
      credentials: "include",
      body: isFormData ? payload : JSON.stringify(payload),
      ...options
    });
    return this.handleResponse<TResponse>(response);
  }

  async put<TPayload, TResponse>(path: string, payload: TPayload): Promise<TResponse> {
    const headers = this.buildHeaders({ "Content-Type": "application/json" });
    const response = await fetch(this.buildUrl(path), {
      method: "PUT",
      headers,
      credentials: "include",
      body: JSON.stringify(payload)
    });
    return this.handleResponse<TResponse>(response);
  }

  async delete<TResponse>(path: string): Promise<TResponse> {
    const response = await fetch(this.buildUrl(path), {
      method: "DELETE",
      credentials: "include",
      headers: this.buildHeaders()
    });
    return this.handleResponse<TResponse>(response);
  }

  private async handleResponse<T>(response: Response): Promise<T> {
    const contentType = response.headers.get("content-type") ?? "";
    const isJson = contentType.includes("application/json");

    if (!response.ok) {
      let message = `Erreur HTTP ${response.status}`;

      if (isJson) {
        try {
          const body = await response.json();
          if (typeof body?.message === "string") {
            message = body.message;
          }
        } catch {
          // ignore JSON parse error
        }
      }

      const error: ApiError = {
        message,
        status: response.status
      };
      throw error;
    }

    if (!isJson) {
      return (await response.text()) as unknown as T;
    }

    return (await response.json()) as T;
  }
}

export const apiClient = new ApiClient();

