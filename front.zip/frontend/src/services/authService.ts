// Service d'authentification pour Xpert Pro
import { useState, useEffect } from 'react'
import { apiClient } from './apiClient'

export interface User {
  id: number
  nom: string
  prenom: string
  email: string
  role: 'admin' | 'super_admin' | 'manager' | 'hr' | 'employe'
  departement?: string
  telephone?: string
  adresse?: string
  photo?: string
  statut?: string
  poste?: string
  date_embauche?: string
  contact_urgence_nom?: string
  contact_urgence_telephone?: string
  contact_urgence_relation?: string
  created_at?: string
  updated_at?: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
}

class AuthService {
  private static instance: AuthService
  private authState: AuthState = {
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null
  }
  private listeners: ((state: AuthState) => void)[] = []

  private constructor() {
    this.initializeAuth()
  }

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService()
    }
    return AuthService.instance
  }

  private async initializeAuth() {
    try {
      // Vérifier le token dans localStorage
      const token = localStorage.getItem('auth_token')
      if (token) {
        // Valider le token avec le backend
        const data = await apiClient.get<{ success: boolean; user?: User; message?: string }>('/api/auth/validate')
        if (data?.success && data.user) {
          this.setUser(data.user)
          return
        }
        
        // Token invalide, le supprimer
        localStorage.removeItem('auth_token')
      }
    } catch (error) {
      console.error('Erreur initialisation auth:', error)
    } finally {
      this.setLoading(false)
    }
  }

  private setUser(user: User | null) {
    this.authState = {
      ...this.authState,
      user,
      isAuthenticated: !!user,
      isLoading: false,
      error: null
    }
    this.notifyListeners()
  }

  private setLoading(loading: boolean) {
    this.authState = {
      ...this.authState,
      isLoading: loading
    }
    this.notifyListeners()
  }

  private setError(error: string | null) {
    this.authState = {
      ...this.authState,
      error,
      isLoading: false
    }
    this.notifyListeners()
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener(this.authState))
  }

  // Méthodes publiques
  subscribe(listener: (state: AuthState) => void) {
    this.listeners.push(listener)
    listener(this.authState)
    
    // Retourner fonction de désabonnement
    return () => {
      const index = this.listeners.indexOf(listener)
      if (index > -1) {
        this.listeners.splice(index, 1)
      }
    }
  }

  getState(): AuthState {
    return { ...this.authState }
  }

  async login(email: string, password: string): Promise<{ success: boolean; error?: string }> {
    try {
      this.setLoading(true)

      const data = await apiClient.post<{ email: string; password: string }, any>('/api/auth/login', { email, password })

      if (data.success && data.user && data.token) {
        // Sauvegarder le token
        localStorage.setItem('auth_token', data.token)
        
        // Mettre à jour l'état
        this.setUser(data.user)
        
        return { success: true }
      } else {
        const error = data.message || 'Email ou mot de passe incorrect'
        this.setError(error)
        return { success: false, error }
      }
    } catch (error) {
      const errorMessage = 'Erreur de connexion au serveur'
      this.setError(errorMessage)
      return { success: false, error: errorMessage }
    }
  }

  async register(userData: {
    nom: string
    prenom: string
    email: string
    password: string
    telephone?: string
    departement?: string
  }): Promise<{ success: boolean; error?: string }> {
    try {
      this.setLoading(true)
      
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData)
      })

      const data = await response.json()

      if (data.success) {
        return { success: true }
      } else {
        const error = data.message || 'Erreur lors de l\'inscription'
        this.setError(error)
        return { success: false, error }
      }
    } catch (error) {
      const errorMessage = 'Erreur de connexion au serveur'
      this.setError(errorMessage)
      return { success: false, error: errorMessage }
    }
  }

  logout(): void {
    // Supprimer le token
    localStorage.removeItem('auth_token')
    
    // Réinitialiser l'état
    this.setUser(null)
  }

  // Vérifier si l'utilisateur est admin
  isAdmin(): boolean {
    return this.authState.user?.role === 'admin' || this.authState.user?.role === 'super_admin'
  }

  // Vérifier si l'utilisateur est super admin
  isSuperAdmin(): boolean {
    return this.authState.user?.role === 'super_admin'
  }

  // Vérifier si l'utilisateur est manager
  isManager(): boolean {
    return this.authState.user?.role === 'manager'
  }

  // Vérifier si l'utilisateur est HR
  isHR(): boolean {
    return this.authState.user?.role === 'hr'
  }

  // Vérifier si l'utilisateur est employé (uniquement le rôle employé)
  isEmploye(): boolean {
    return this.authState.user?.role === 'employe'
  }

  // Vérifier si l'utilisateur est un admin (tous les rôles sauf employé)
  isAnyAdmin(): boolean {
    return this.authState.user?.role === 'admin' || 
           this.authState.user?.role === 'super_admin' || 
           this.authState.user?.role === 'manager' || 
           this.authState.user?.role === 'hr'
  }

  // Vérifier si l'utilisateur a accès aux paramètres
  hasSettingsAccess(): boolean {
    return this.authState.user?.role === 'admin' || 
           this.authState.user?.role === 'super_admin'
  }

  // Obtenir l'ID de l'utilisateur
  getUserId(): number | null {
    return this.authState.user?.id || null
  }

  // Mettre à jour le profil utilisateur
  async updateProfile(updates: Partial<User>): Promise<{ success: boolean; error?: string }> {
    try {
      const token = localStorage.getItem('auth_token')
      if (!token) {
        return { success: false, error: 'Non authentifié' }
      }

      const response = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(updates)
      })

      const data = await response.json()

      if (data.success && data.user) {
        // Mettre à jour l'utilisateur dans l'état
        this.setUser(data.user)
        return { success: true }
      } else {
        const error = data.message || 'Erreur lors de la mise à jour'
        return { success: false, error }
      }
    } catch (error) {
      const errorMessage = 'Erreur de connexion au serveur'
      return { success: false, error: errorMessage }
    }
  }
}

// Hook React pour utiliser l'authentification
export function useAuth() {
  const authService = AuthService.getInstance()
  const [authState, setAuthState] = useState<AuthState>(authService.getState())

  useEffect(() => {
    const unsubscribe = authService.subscribe(setAuthState)
    return unsubscribe
  }, [])

  return {
    ...authState,
    login: authService.login.bind(authService),
    register: authService.register.bind(authService),
    logout: authService.logout.bind(authService),
    updateProfile: authService.updateProfile.bind(authService),
    isAdmin: authService.isAdmin.bind(authService),
    isSuperAdmin: authService.isSuperAdmin.bind(authService),
    isManager: authService.isManager.bind(authService),
    isHR: authService.isHR.bind(authService),
    isEmploye: authService.isEmploye.bind(authService),
    isAnyAdmin: authService.isAnyAdmin.bind(authService),
    hasSettingsAccess: authService.hasSettingsAccess.bind(authService),
    getUserId: authService.getUserId.bind(authService)
  }
}

export default AuthService
