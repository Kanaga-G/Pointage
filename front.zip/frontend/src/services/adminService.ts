import { apiClient } from './apiClient'

// ============================================
// TYPES ADMIN SERVICE
// ============================================

export interface AdminStats {
  total_employes: number
  presents: number
  absents: number
  retards: number
  total_heures_jour: number
  taux_presence: number
}

export interface PointageEntry {
  id: number
  employe_id: number
  prenom: string
  nom: string
  departement: string
  date: string
  arrivee: string | null
  depart: string | null
  photo?: string
  retard_minutes?: number
  statut?: 'normal' | 'retard' | 'absent'
}

export interface TempsTotal {
  id: number
  prenom: string
  nom: string
  email: string
  departement: string
  total_travail: string
  photo?: string
  heures_sup?: number
}

export interface Demande {
  id: number
  prenom: string
  nom: string
  poste: string
  departement: string
  type: string
  date_demande: string
  date_debut?: string
  date_fin?: string
  motif?: string
  statut: "en_attente" | "approuve" | "rejete"
  heures_ecoulees?: number
  photo?: string
  urgent?: boolean
}

export interface DemandeStats {
  total: number
  en_attente: number
  approuve: number
  rejete: number
  en_retard: number
}

export interface Employe {
  id: number
  prenom: string
  nom: string
  email: string
  telephone?: string
  poste: string
  departement: string
  statut: string
  date_embauche?: string
  contrat_type?: string
  contrat_duree?: string
  salaire?: number
  adresse?: string
  photo?: string
  manager_id?: number
  taux_horaire?: number
}

export interface Admin {
  id: number
  prenom: string
  nom: string
  email: string
  telephone?: string
  role: string
  adresse?: string
  last_activity?: string
  status?: string
  photo?: string
  is_super_admin?: boolean
  permissions?: string[]
}

export interface Retard {
  id: number
  employe_id: number
  prenom: string
  nom: string
  departement: string
  date_heure: string
  retard_minutes: number
  statut?: string
  retard_raison?: string
  est_justifie?: boolean
  created_at?: string
}

export interface ApiResponse<T> {
  success: boolean
  data?: T
  message?: string
  total?: number
  total_pages?: number
  current_page?: number
}

export interface PaginatedResponse<T> {
  success: boolean
  items: T[]
  total: number
  total_pages: number
  current_page: number
  per_page: number
}

// ============================================
// ADMIN SERVICE CLASS
// ============================================

class AdminService {
  private baseUrl = '/api/admin'

  // ============================================
  // STATISTIQUES
  // ============================================

  async getStats(): Promise<AdminStats> {
    try {
      // Essayer plusieurs endpoints possibles
      let response;
      try {
        response = await apiClient.get<ApiResponse<AdminStats>>('admin/dashboard/stats')
      } catch {
        response = await apiClient.get<ApiResponse<AdminStats>>('dashboard/stats')
      }
      return response.data || {
        total_employes: 0,
        presents: 0,
        absents: 0,
        retards: 0,
        total_heures_jour: 0,
        taux_presence: 0
      }
    } catch (error) {
      console.error('Erreur lors de la récupération des statistiques:', error)
      // Retourner des données par défaut en cas d'erreur
      return {
        total_employes: 0,
        presents: 0,
        absents: 0,
        retards: 0,
        total_heures_jour: 0,
        taux_presence: 0
      }
    }
  }

  async getTodayStats(): Promise<AdminStats> {
    try {
      const response = await apiClient.get<ApiResponse<AdminStats>>('get_pointage_admin_day')
      return response.data || {
        total_employes: 0,
        presents: 0,
        absents: 0,
        retards: 0,
        total_heures_jour: 0,
        taux_presence: 0
      }
    } catch (error) {
      console.error('Erreur lors de la récupération des statistiques du jour:', error)
      throw error
    }
  }

  // ============================================
  // POINTAGES
  // ============================================

  async getPointages(params: {
    page?: number
    per_page?: number
    date?: string
    departement?: string
    search?: string
  } = {}): Promise<PaginatedResponse<PointageEntry>> {
    try {
      const searchParams = new URLSearchParams()
      
      if (params.page) searchParams.append('page_pointage', params.page.toString())
      if (params.per_page) searchParams.append('per_page', params.per_page.toString())
      if (params.date) searchParams.append('date', params.date)
      if (params.departement) searchParams.append('departement', params.departement)
      if (params.search) searchParams.append('search', params.search)

      const response = await apiClient.get<PaginatedResponse<PointageEntry>>(
        `get_pointages?${searchParams.toString()}`
      )
      
      return response
    } catch (error) {
      console.error('Erreur lors de la récupération des pointages:', error)
      throw error
    }
  }

  async exportPointages(params: {
    format: 'pdf' | 'excel'
    date_debut?: string
    date_fin?: string
    departement?: string
  }): Promise<Blob> {
    try {
      const searchParams = new URLSearchParams()
      searchParams.append('format', params.format)
      if (params.date_debut) searchParams.append('date_debut', params.date_debut)
      if (params.date_fin) searchParams.append('date_fin', params.date_fin)
      if (params.departement) searchParams.append('departement', params.departement)

      const response = await fetch(`${this.baseUrl}/pointages/export?${searchParams.toString()}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
        },
      })

      if (!response.ok) {
        throw new Error('Erreur lors de l\'exportation')
      }

      return response.blob()
    } catch (error) {
      console.error('Erreur lors de l\'exportation des pointages:', error)
      throw error
    }
  }

  // ============================================
  // TEMPS TRAVAILLÉS
  // ============================================

  async getTempsTotaux(params: {
    page?: number
    per_page?: number
    month?: string
    year?: string
    departement?: string
  } = {}): Promise<PaginatedResponse<TempsTotal>> {
    try {
      const searchParams = new URLSearchParams()
      
      if (params.page) searchParams.append('page_heures', params.page.toString())
      if (params.per_page) searchParams.append('per_page', params.per_page.toString())
      if (params.month) searchParams.append('month', params.month)
      if (params.year) searchParams.append('year', params.year)
      if (params.departement) searchParams.append('departement', params.departement)

      const response = await apiClient.get<PaginatedResponse<TempsTotal>>(
        `get_temps_totaux?${searchParams.toString()}`
      )
      
      return response
    } catch (error) {
      console.error('Erreur lors de la récupération des temps totaux:', error)
      throw error
    }
  }

  // ============================================
  // DEMANDES
  // ============================================

  async getDemandes(params: {
    page?: number
    per_page?: number
    statut?: string
    type?: string
    departement?: string
    urgent?: boolean
  } = {}): Promise<PaginatedResponse<Demande>> {
    try {
      const searchParams = new URLSearchParams()
      
      if (params.page) searchParams.append('page_demandes', params.page.toString())
      if (params.per_page) searchParams.append('per_page', params.per_page.toString())
      if (params.statut) searchParams.append('statut', params.statut)
      if (params.type) searchParams.append('type', params.type)
      if (params.departement) searchParams.append('departement', params.departement)
      if (params.urgent !== undefined) searchParams.append('urgent', params.urgent.toString())

      const response = await apiClient.get<PaginatedResponse<Demande>>(
        `get_demandes?${searchParams.toString()}`
      )
      
      return response
    } catch (error) {
      console.error('Erreur lors de la récupération des demandes:', error)
      throw error
    }
  }

  async getDemandeStats(): Promise<DemandeStats> {
    try {
      const response = await apiClient.get<ApiResponse<DemandeStats>>('demandes/stats')
      return response.data || {
        total: 0,
        en_attente: 0,
        approuve: 0,
        rejete: 0,
        en_retard: 0
      }
    } catch (error) {
      console.error('Erreur lors de la récupération des statistiques des demandes:', error)
      throw error
    }
  }

  async updateDemandeStatus(id: number, action: 'approuve' | 'rejete', motif?: string): Promise<boolean> {
    try {
      const response = await apiClient.post<{ id: number; action: string; motif?: string }, ApiResponse<any>>(
        'traiter_demande',
        { id, action, motif }
      )
      return response.success
    } catch (error) {
      console.error('Erreur lors de la mise à jour du statut de la demande:', error)
      throw error
    }
  }

  // ============================================
  // EMPLOYÉS
  // ============================================

  async getEmployes(params: {
    page?: number
    per_page?: number
    search?: string
    departement?: string
    statut?: string
  } = {}): Promise<PaginatedResponse<Employe>> {
    try {
      const searchParams = new URLSearchParams()
      
      if (params.page) searchParams.append('page', params.page.toString())
      if (params.per_page) searchParams.append('per_page', params.per_page.toString())
      if (params.search) searchParams.append('search', params.search)
      if (params.departement) searchParams.append('departement', params.departement)
      if (params.statut) searchParams.append('statut', params.statut)

      const response = await apiClient.get<PaginatedResponse<Employe>>(
        `get_employes?${searchParams.toString()}`
      )
      
      return response
    } catch (error) {
      console.error('Erreur lors de la récupération des employés:', error)
      throw error
    }
  }

  async createEmploye(employe: Omit<Employe, 'id'>): Promise<Employe> {
    try {
      const response = await apiClient.post<Omit<Employe, 'id'>, ApiResponse<Employe>>(
        'employes',
        employe
      )
      return response.data!
    } catch (error) {
      console.error('Erreur lors de la création de l\'employé:', error)
      throw error
    }
  }

  async updateEmploye(id: number, employe: Partial<Employe>): Promise<Employe> {
    try {
      const response = await apiClient.put<{ id: number; data: Partial<Employe> }, ApiResponse<Employe>>(
        `employes/${id}`,
        { id, data: employe }
      )
      return response.data!
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'employé:', error)
      throw error
    }
  }

  async deleteEmploye(id: number): Promise<boolean> {
    try {
      const response = await apiClient.delete<ApiResponse<any>>(`employes/${id}`)
      return response.success
    } catch (error) {
      console.error('Erreur lors de la suppression de l\'employé:', error)
      throw error
    }
  }

  // ============================================
  // ADMINISTRATEURS
  // ============================================

  async getAdmins(): Promise<{ admins: Admin[]; is_super_admin: boolean }> {
    try {
      const response = await apiClient.get<ApiResponse<{ admins: Admin[]; is_super_admin: boolean }>>(
        'get_admins'
      )
      return response.data || { admins: [], is_super_admin: false }
    } catch (error) {
      console.error('Erreur lors de la récupération des administrateurs:', error)
      throw error
    }
  }

  async createAdmin(admin: Omit<Admin, 'id'>): Promise<Admin> {
    try {
      const response = await apiClient.post<Omit<Admin, 'id'>, ApiResponse<Admin>>(
        'admins',
        admin
      )
      return response.data!
    } catch (error) {
      console.error('Erreur lors de la création de l\'administrateur:', error)
      throw error
    }
  }

  async updateAdmin(id: number, admin: Partial<Admin>): Promise<Admin> {
    try {
      const response = await apiClient.put<{ id: number; data: Partial<Admin> }, ApiResponse<Admin>>(
        `admins/${id}`,
        { id, data: admin }
      )
      return response.data!
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'administrateur:', error)
      throw error
    }
  }

  // ============================================
  // RETARDS
  // ============================================

  async getRetards(params: {
    page?: number
    per_page?: number
    date?: string
    departement?: string
    justifie?: boolean
  } = {}): Promise<PaginatedResponse<Retard>> {
    try {
      const searchParams = new URLSearchParams()
      
      if (params.page) searchParams.append('page_retard', params.page.toString())
      if (params.per_page) searchParams.append('per_page', params.per_page.toString())
      if (params.date) searchParams.append('date_retard', params.date)
      if (params.departement) searchParams.append('dep_retard', params.departement)
      if (params.justifie !== undefined) searchParams.append('justifie', params.justifie.toString())

      const response = await apiClient.get<PaginatedResponse<Retard>>(
        `get_retards?${searchParams.toString()}`
      )
      
      return response
    } catch (error) {
      console.error('Erreur lors de la récupération des retards:', error)
      throw error
    }
  }

  async justifierRetard(id: number, raison: string): Promise<boolean> {
    try {
      const response = await apiClient.post<{ id: number; raison: string }, ApiResponse<any>>(
        'retards/justifier',
        { id, raison }
      )
      return response.success
    } catch (error) {
      console.error('Erreur lors de la justification du retard:', error)
      throw error
    }
  }

  // ============================================
  // DÉPARTEMENTS
  // ============================================

  async getDepartements(): Promise<string[]> {
    try {
      const response = await apiClient.get<ApiResponse<string[]>>('get_departements')
      return response.data || []
    } catch (error) {
      console.error('Erreur lors de la récupération des départements:', error)
      return []
    }
  }

  // ============================================
  // EXPORTS
  // ============================================

  async exportData(type: string, params: {
    format: 'pdf' | 'excel'
    date_debut?: string
    date_fin?: string
    departement?: string
  }): Promise<Blob> {
    try {
      const searchParams = new URLSearchParams()
      searchParams.append('format', params.format)
      if (params.date_debut) searchParams.append('date_debut', params.date_debut)
      if (params.date_fin) searchParams.append('date_fin', params.date_fin)
      if (params.departement) searchParams.append('departement', params.departement)

      const response = await fetch(`${this.baseUrl}/export/${type}?${searchParams.toString()}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
        },
      })

      if (!response.ok) {
        throw new Error('Erreur lors de l\'exportation')
      }

      return response.blob()
    } catch (error) {
      console.error('Erreur lors de l\'exportation:', error)
      throw error
    }
  }
}

// Export singleton instance
export const adminService = new AdminService()
export default adminService
