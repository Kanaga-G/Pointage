import React from 'react'
import { createRoot } from 'react-dom/client'
import LandingPage from './pages/LandingPage'
import Login from './pages/Login'
import './styles/globals.css'

function App() {
  const [currentPage, setCurrentPage] = React.useState('home');

  const renderPage = () => {
    switch(currentPage) {
      case 'home':
        return <LandingPage />;
      case 'login':
        return <Login />;
      default:
        return (
          <div style={{ padding: '20px', textAlign: 'center' }}>
            <h1 style={{ color: '#2563eb', marginBottom: '20px' }}>
              🎉 Xpert Pro - Récupération Réussie !
            </h1>
            
            <div style={{ 
              backgroundColor: '#f0fdf4', 
              padding: '20px', 
              borderRadius: '8px', 
              marginBottom: '20px',
              border: '1px solid #bbf7d0'
            }}>
              <h2>📱 Pages Disponibles</h2>
              <div style={{ display: 'flex', gap: '10px', justifyContent: 'center', flexWrap: 'wrap' }}>
                <button 
                  onClick={() => setCurrentPage('home')}
                  style={{ 
                    background: currentPage === 'home' ? '#2563eb' : '#e5e7eb',
                    color: currentPage === 'home' ? 'white' : '#374151',
                    border: 'none', 
                    padding: '10px 20px', 
                    borderRadius: '5px', 
                    cursor: 'pointer',
                    marginBottom: '10px'
                  }}
                >
                  🏠 Accueil
                </button>
                <button 
                  onClick={() => setCurrentPage('login')}
                  style={{ 
                    background: currentPage === 'login' ? '#2563eb' : '#e5e7eb',
                    color: currentPage === 'login' ? 'white' : '#374151',
                    border: 'none', 
                    padding: '10px 20px', 
                    borderRadius: '5px', 
                    cursor: 'pointer',
                    marginBottom: '10px'
                  }}
                >
                  🔐 Connexion
                </button>
              </div>
            </div>

            <div style={{ 
              backgroundColor: '#dbeafe', 
              padding: '20px', 
              borderRadius: '8px',
              border: '1px solid #93c5fd'
            }}>
              <h2>🌐 Serveurs Actifs</h2>
              <p><strong>Frontend:</strong> http://localhost:5173</p>
              <p><strong>Backend:</strong> http://localhost:3003</p>
            </div>

            <div style={{ 
              backgroundColor: '#fefce8', 
              padding: '20px', 
              borderRadius: '8px',
              border: '1px solid #fde047'
            }}>
              <h2>🔐 Identifiants de Test</h2>
              <p><strong>Admin:</strong> admin@xpertpro.com / admin123</p>
              <p><strong>Employé:</strong> jean.dupont@xpertpro.com / password123</p>
            </div>

            <div style={{ 
              backgroundColor: '#f3f4f6', 
              padding: '20px', 
              borderRadius: '8px',
              textAlign: 'center',
              marginTop: '20px'
            }}>
              <h2 style={{ color: '#059669' }}>🚀 Application Complètement Récupérée !</h2>
              <p>Toutes vos données sont sécurisées et fonctionnelles</p>
            </div>
          </div>
        );
    }
  };

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f8f9fc' }}>
      {renderPage()}
    </div>
  );
}

export default App
