import React, { useState, useEffect } from 'react'
import { Clock, Calendar, User, Bell, LogOut, Menu, X, Plus, Minus, AlertCircle, CheckCircle, TrendingUp, Activity, FileText, Settings, MapPin, Coffee, Home, RefreshCw } from 'lucide-react'

interface Pointage {
  id: number
  date_heure: string
  type: 'arrivée' | 'départ'
  statut: 'normal' | 'retard' | 'absent'
  lieu?: string
}

interface Demande {
  id: number
  type: 'congé' | 'permission' | 'maladie'
  date_debut: string
  date_fin: string
  motif: string
  statut: 'en_attente' | 'approuvée' | 'rejetée'
  created_at: string
}

interface Statistique {
  total_heures: number
  jours_travaillés: number
  retards: number
  absences: number
  pointages_mois: number
}

export default function EmployeDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeSection, setActiveSection] = useState('overview')
  const [loading, setLoading] = useState(true)
  const [showPointageModal, setShowPointageModal] = useState(false)
  const [showDemandeModal, setShowDemandeModal] = useState(false)
  const [currentTime, setCurrentTime] = useState(new Date())
  
  // États pour les données
  const [user] = useState({
    id: 1,
    prenom: 'Jean',
    nom: 'Dupont',
    email: 'jean.dupont@email.com',
    departement: 'IT',
    poste: 'Développeur',
    telephone: '0123456789'
  })

  const [statistiques, setStatistiques] = useState<Statistique>({
    total_heures: 168,
    jours_travaillés: 22,
    retards: 2,
    absences: 1,
    pointages_mois: 44
  })

  const [pointages, setPointages] = useState<Pointage[]>([])
  const [demandes, setDemandes] = useState<Demande[]>([])
  const [dernierPointage, setDernierPointage] = useState<Pointage | null>(null)

  // Charger les données du dashboard
  useEffect(() => {
    loadDashboardData()
    
    // Mettre à jour l'heure toutes les secondes
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const loadDashboardData = async () => {
    try {
      setLoading(true)
      
      // Simuler des données réelles
      const mockPointages: Pointage[] = [
        { id: 1, date_heure: '2024-01-15 08:45:00', type: 'arrivée', statut: 'normal', lieu: 'Bureau' },
        { id: 2, date_heure: '2024-01-15 12:30:00', type: 'départ', statut: 'normal', lieu: 'Bureau' },
        { id: 3, date_heure: '2024-01-15 13:30:00', type: 'arrivée', statut: 'normal', lieu: 'Bureau' },
        { id: 4, date_heure: '2024-01-14 09:15:00', type: 'arrivée', statut: 'retard', lieu: 'Bureau' },
        { id: 5, date_heure: '2024-01-14 18:00:00', type: 'départ', statut: 'normal', lieu: 'Bureau' },
      ]

      const mockDemandes: Demande[] = [
        { id: 1, type: 'congé', date_debut: '2024-01-20', date_fin: '2024-01-25', motif: 'Vacances', statut: 'approuvée', created_at: '2024-01-10' },
        { id: 2, type: 'permission', date_debut: '2024-01-16', date_fin: '2024-01-16', motif: 'Rendez-vous médical', statut: 'en_attente', created_at: '2024-01-12' },
      ]

      setPointages(mockPointages)
      setDemandes(mockDemandes)
      setDernierPointage(mockPointages[0])
    } catch (error) {
      console.error('Erreur lors du chargement des données:', error)
    } finally {
      setLoading(false)
    }
  }

  const handlePointage = async (type: 'arrivée' | 'départ') => {
    try {
      const nouveauPointage: Pointage = {
        id: pointages.length + 1,
        date_heure: new Date().toISOString().replace('T', ' ').slice(0, 19),
        type,
        statut: type === 'arrivée' && new Date().getHours() > 9 ? 'retard' : 'normal',
        lieu: 'Bureau'
      }
      
      setPointages([nouveauPointage, ...pointages])
      setDernierPointage(nouveauPointage)
      setShowPointageModal(false)
      
      // Simuler une notification
      alert(`Pointage ${type} enregistré avec succès!`)
    } catch (error) {
      console.error('Erreur lors du pointage:', error)
      alert('Erreur lors du pointage. Veuillez réessayer.')
    }
  }

  const handleDemande = async (demandeData: Partial<Demande>) => {
    try {
      const nouvelleDemande: Demande = {
        id: demandes.length + 1,
        type: demandeData.type as 'congé' | 'permission' | 'maladie',
        date_debut: demandeData.date_debut!,
        date_fin: demandeData.date_fin!,
        motif: demandeData.motif!,
        statut: 'en_attente',
        created_at: new Date().toISOString().split('T')[0]
      }
      
      setDemandes([nouvelleDemande, ...demandes])
      setShowDemandeModal(false)
      
      // Simuler une notification
      alert('Demande soumise avec succès!')
    } catch (error) {
      console.error('Erreur lors de la soumission de la demande:', error)
      alert('Erreur lors de la soumission. Veuillez réessayer.')
    }
  }

  const menuItems = [
    { id: 'overview', label: 'Tableau de bord', icon: <Home className="w-5 h-5" /> },
    { id: 'pointage', label: 'Pointage', icon: <Clock className="w-5 h-5" /> },
    { id: 'demandes', label: 'Mes Demandes', icon: <FileText className="w-5 h-5" /> },
    { id: 'calendrier', label: 'Calendrier', icon: <Calendar className="w-5 h-5" /> },
    { id: 'statistiques', label: 'Statistiques', icon: <TrendingUp className="w-5 h-5" /> },
    { id: 'profil', label: 'Mon Profil', icon: <User className="w-5 h-5" /> },
    { id: 'parametres', label: 'Paramètres', icon: <Settings className="w-5 h-5" /> },
  ]

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Carte de bienvenue */}
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg shadow-lg p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold mb-2">Bonjour, {user.prenom}!</h2>
                  <p className="text-blue-100">Voici votre résumé du jour</p>
                  <p className="text-3xl font-bold mt-4">{currentTime.toLocaleTimeString('fr-FR')}</p>
                </div>
                <div className="text-right">
                  <p className="text-blue-100">{currentTime.toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                  {dernierPointage && (
                    <div className="mt-2">
                      <p className="text-sm">Dernier pointage:</p>
                      <p className="font-semibold">{dernierPointage.type} - {dernierPointage.date_heure.split(' ')[1]}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Boutons d'action rapide */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button
                onClick={() => setShowPointageModal(true)}
                className="bg-green-500 text-white rounded-lg p-6 hover:bg-green-600 transition-colors"
              >
                <Clock className="w-8 h-8 mb-2 mx-auto" />
                <h3 className="font-semibold">Pointer maintenant</h3>
                <p className="text-sm text-green-100">Enregistrer votre arrivée/départ</p>
              </button>
              <button
                onClick={() => setShowDemandeModal(true)}
                className="bg-blue-500 text-white rounded-lg p-6 hover:bg-blue-600 transition-colors"
              >
                <Plus className="w-8 h-8 mb-2 mx-auto" />
                <h3 className="font-semibold">Faire une demande</h3>
                <p className="text-sm text-blue-100">Congé, permission, etc.</p>
              </button>
            </div>

            {/* Statistiques */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total heures</p>
                    <p className="text-2xl font-bold text-gray-900">{statistiques.total_heures}h</p>
                  </div>
                  <div className="bg-blue-100 text-blue-600 p-3 rounded-lg">
                    <Clock className="w-5 h-5" />
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Jours travaillés</p>
                    <p className="text-2xl font-bold text-gray-900">{statistiques.jours_travaillés}</p>
                  </div>
                  <div className="bg-green-100 text-green-600 p-3 rounded-lg">
                    <Activity className="w-5 h-5" />
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Retards</p>
                    <p className="text-2xl font-bold text-gray-900">{statistiques.retards}</p>
                  </div>
                  <div className="bg-yellow-100 text-yellow-600 p-3 rounded-lg">
                    <AlertCircle className="w-5 h-5" />
                  </div>
                </div>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Absences</p>
                    <p className="text-2xl font-bold text-gray-900">{statistiques.absences}</p>
                  </div>
                  <div className="bg-red-100 text-red-600 p-3 rounded-lg">
                    <X className="w-5 h-5" />
                  </div>
                </div>
              </div>
            </div>

            {/* Derniers pointages */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">Derniers Pointages</h3>
              <div className="space-y-3">
                {pointages.slice(0, 5).map((pointage) => (
                  <div key={pointage.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        pointage.type === 'arrivée' ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'
                      }`}>
                        {pointage.type === 'arrivée' ? <Plus className="w-5 h-5" /> : <Minus className="w-5 h-5" />}
                      </div>
                      <div>
                        <p className="font-medium">{pointage.type === 'arrivée' ? 'Arrivée' : 'Départ'}</p>
                        <p className="text-sm text-gray-600">{pointage.date_heure}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs ${
                      pointage.statut === 'normal' ? 'bg-green-100 text-green-800' : 
                      pointage.statut === 'retard' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-red-100 text-red-800'
                    }`}>
                      {pointage.statut}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )

      case 'pointage':
        return (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-lg shadow p-8">
              <h2 className="text-2xl font-bold text-center mb-8">Pointage</h2>
              
              <div className="text-center mb-8">
                <p className="text-4xl font-bold text-gray-900 mb-2">{currentTime.toLocaleTimeString('fr-FR')}</p>
                <p className="text-lg text-gray-600">{currentTime.toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                <button
                  onClick={() => handlePointage('arrivée')}
                  className="bg-green-500 text-white rounded-lg p-6 hover:bg-green-600 transition-colors"
                >
                  <Plus className="w-8 h-8 mb-2 mx-auto" />
                  <h3 className="font-semibold">Arrivée</h3>
                  <p className="text-sm text-green-100">Pointer votre arrivée</p>
                </button>
                <button
                  onClick={() => handlePointage('départ')}
                  className="bg-red-500 text-white rounded-lg p-6 hover:bg-red-600 transition-colors"
                >
                  <Minus className="w-8 h-8 mb-2 mx-auto" />
                  <h3 className="font-semibold">Départ</h3>
                  <p className="text-sm text-red-100">Pointer votre départ</p>
                </button>
              </div>

              {dernierPointage && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold mb-2">Dernier pointage</h3>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{dernierPointage.type} - {dernierPointage.date_heure}</p>
                      <p className="text-sm text-gray-600">Lieu: {dernierPointage.lieu}</p>
                    </div>
                    <span className={`px-2 py-1 rounded text-xs ${
                      dernierPointage.statut === 'normal' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {dernierPointage.statut}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )

      case 'demandes':
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Mes Demandes</h2>
              <button
                onClick={() => setShowDemandeModal(true)}
                className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Nouvelle demande
              </button>
            </div>
            <div className="space-y-4">
              {demandes.map((demande) => (
                <div key={demande.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold capitalize">{demande.type}</h3>
                    <span className={`px-2 py-1 rounded text-xs ${
                      demande.statut === 'approuvée' ? 'bg-green-100 text-green-800' : 
                      demande.statut === 'en_attente' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-red-100 text-red-800'
                    }`}>
                      {demande.statut}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-2">{demande.motif}</p>
                  <p className="text-sm text-gray-500">Du {demande.date_debut} au {demande.date_fin}</p>
                  <p className="text-sm text-gray-400">Demande le {demande.created_at}</p>
                </div>
              ))}
            </div>
          </div>
        )

      case 'statistiques':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Mes Statistiques</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">Performance ce mois</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Heures travaillées</span>
                    <span className="font-semibold">{statistiques.total_heures}h</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Jours travaillés</span>
                    <span className="font-semibold">{statistiques.jours_travaillés}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Pointages</span>
                    <span className="font-semibold">{statistiques.pointages_mois}</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">Assiduité</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Retards</span>
                    <span className="font-semibold text-yellow-600">{statistiques.retards}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Absences</span>
                    <span className="font-semibold text-red-600">{statistiques.absences}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Taux de présence</span>
                    <span className="font-semibold text-green-600">95.5%</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">Résumé</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Moyenne/jour</span>
                    <span className="font-semibold">7.6h</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Heures supplémentaires</span>
                    <span className="font-semibold text-blue-600">12h</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Jours de congé restants</span>
                    <span className="font-semibold text-green-600">18</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )

      case 'profil':
        return (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-2xl font-bold mb-6">Mon Profil</h2>
              <div className="flex items-center gap-6 mb-6">
                <div className="w-20 h-20 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-2xl font-bold">{user.prenom[0]}{user.nom[0]}</span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold">{user.prenom} {user.nom}</h3>
                  <p className="text-gray-600">{user.poste}</p>
                  <p className="text-gray-600">{user.departement}</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input type="email" value={user.email} disabled className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Téléphone</label>
                  <input type="tel" value={user.telephone} disabled className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Département</label>
                  <input type="text" value={user.departement} disabled className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Poste</label>
                  <input type="text" value={user.poste} disabled className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50" />
                </div>
              </div>
            </div>
          </div>
        )

      default:
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">{menuItems.find(item => item.id === activeSection)?.label}</h2>
            <p className="text-gray-600">Cette section est en cours de développement.</p>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
              >
                {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
              <h1 className="ml-4 text-xl font-semibold text-gray-900">Espace Employé</h1>
            </div>
            <div className="flex items-center gap-4">
              <button className="p-2 rounded-full text-gray-400 hover:text-gray-500 hover:bg-gray-100">
                <Bell className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">{user.prenom[0]}</span>
                </div>
                <span className="text-sm font-medium text-gray-700">{user.prenom} {user.nom}</span>
              </div>
              <button className="p-2 rounded-full text-gray-400 hover:text-gray-500 hover:bg-gray-100">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`${sidebarOpen ? 'w-64' : 'w-0'} transition-all duration-300 bg-white shadow-lg overflow-hidden`}>
          <nav className="mt-5 px-2">
            <div className="space-y-1">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`${
                    activeSection === item.id
                      ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md w-full text-left`}
                >
                  {item.icon}
                  <span className="ml-3">{item.label}</span>
                </button>
              ))}
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className={`flex-1 p-6 ${sidebarOpen ? 'ml-0' : ''}`}>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
            </div>
          ) : (
            renderContent()
          )}
        </main>
      </div>

      {/* Modal de pointage */}
      {showPointageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold mb-4">Confirmer le pointage</h3>
            <div className="space-y-4">
              <p className="text-gray-600">Voulez-vous vraiment enregistrer ce pointage ?</p>
              <div className="flex gap-4">
                <button
                  onClick={() => setShowPointageModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Annuler
                </button>
                <button
                  onClick={() => handlePointage('arrivée')}
                  className="flex-1 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600"
                >
                  Pointer l'arrivée
                </button>
                <button
                  onClick={() => handlePointage('départ')}
                  className="flex-1 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
                >
                  Pointer le départ
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de demande */}
      {showDemandeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold mb-4">Nouvelle demande</h3>
            <form onSubmit={(e) => {
              e.preventDefault()
              const formData = new FormData(e.currentTarget)
              handleDemande({
                type: formData.get('type') as 'congé' | 'permission' | 'maladie',
                date_debut: formData.get('date_debut') as string,
                date_fin: formData.get('date_fin') as string,
                motif: formData.get('motif') as string
              })
            }}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Type de demande</label>
                  <select name="type" required className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                    <option value="">Sélectionner...</option>
                    <option value="congé">Congé</option>
                    <option value="permission">Permission</option>
                    <option value="maladie">Maladie</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date de début</label>
                  <input type="date" name="date_debut" required className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date de fin</label>
                  <input type="date" name="date_fin" required className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Motif</label>
                  <textarea name="motif" required rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
                </div>
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setShowDemandeModal(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                  >
                    Soumettre
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
