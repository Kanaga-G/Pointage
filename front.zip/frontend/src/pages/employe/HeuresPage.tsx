import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../services/authService';
import LayoutFix from '../../components/LayoutFix';

export default function HeuresPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/login');
    }
    setLoading(false);
  }, [user, navigate]);

  if (loading) {
    return (
      <LayoutFix title="Heures">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </LayoutFix>
    );
  }

  return (
    <LayoutFix title="Heures">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Gestion des Heures</h1>
          <p className="text-gray-600">Consultez vos heures de travail</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">📊</span>
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Statistiques en cours</h3>
          <p className="text-gray-600">Le calcul de vos heures de travail est en préparation</p>
        </div>
      </div>
    </LayoutFix>
  );
}
