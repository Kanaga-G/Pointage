import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../services/authService';
import Header from '../../components/Header';
import Sidebar from '../../components/Sidebar';
import Footer from '../../components/Footer';

export default function SettingsPage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header title="Paramètres" showNavigation={true} />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <h1 className="text-2xl font-bold text-gray-900">Paramètres</h1>
              <p className="text-gray-600">Gérez vos préférences et votre compte</p>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations du compte</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b">
                  <div>
                    <p className="font-medium text-gray-900">Email</p>
                    <p className="text-sm text-gray-600">{user?.email}</p>
                  </div>
                  <span className="text-sm text-gray-500">Non modifiable</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b">
                  <div>
                    <p className="font-medium text-gray-900">Rôle</p>
                    <p className="text-sm text-gray-600">{user?.role}</p>
                  </div>
                  <span className="text-sm text-gray-500">Non modifiable</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <div>
                    <p className="font-medium text-gray-900">Statut</p>
                    <p className="text-sm text-gray-600">{user?.statut || 'Actif'}</p>
                  </div>
                  <span className="text-sm text-gray-500">Non modifiable</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Préférences</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b">
                  <div>
                    <p className="font-medium text-gray-900">Notifications par email</p>
                    <p className="text-sm text-gray-600">Recevoir les rappels de pointage</p>
                  </div>
                  <button className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700">
                    Activer
                  </button>
                </div>
                <div className="flex justify-between items-center py-3 border-b">
                  <div>
                    <p className="font-medium text-gray-900">Langue</p>
                    <p className="text-sm text-gray-600">Français</p>
                  </div>
                  <select className="border border-gray-300 rounded px-3 py-1 text-sm">
                    <option>Français</option>
                    <option>English</option>
                  </select>
                </div>
                <div className="flex justify-between items-center py-3">
                  <div>
                    <p className="font-medium text-gray-900">Thème</p>
                    <p className="text-sm text-gray-600">Apparence de l'interface</p>
                  </div>
                  <select className="border border-gray-300 rounded px-3 py-1 text-sm">
                    <option>Clair</option>
                    <option>Sombre</option>
                    <option>Auto</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Actions du compte</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b">
                  <div>
                    <p className="font-medium text-gray-900">Exporter mes données</p>
                    <p className="text-sm text-gray-600">Télécharger toutes vos données personnelles</p>
                  </div>
                  <button className="bg-gray-600 text-white px-3 py-1 rounded text-sm hover:bg-gray-700">
                    Exporter
                  </button>
                </div>
                <div className="flex justify-between items-center py-3">
                  <div>
                    <p className="font-medium text-red-600">Déconnexion</p>
                    <p className="text-sm text-gray-600">Se déconnecter de votre compte</p>
                  </div>
                  <button 
                    onClick={handleLogout}
                    className="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700"
                  >
                    Se déconnecter
                  </button>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
}
