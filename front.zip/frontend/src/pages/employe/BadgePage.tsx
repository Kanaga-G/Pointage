import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../services/authService';
import { employeService, BadgeToken } from '../../services/employeService';
import LayoutFix from '../../components/LayoutFix';

export default function BadgePageFixed() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [badge, setBadge] = useState<BadgeToken | null>(null);
  const [loading, setLoading] = useState(true);
  const [regenerating, setRegenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadBadge();
  }, [user, navigate]);

  const loadBadge = async () => {
    try {
      setLoading(true);
      // Simuler la récupération du badge
      const mockBadge: BadgeToken = {
        id: 1,
        token: 'XPRT-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
        token_hash: 'hash-' + Math.random().toString(36),
        created_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'active'
      };
      setBadge(mockBadge);
    } catch (err) {
      console.error('Erreur lors du chargement du badge:', err);
      setError('Erreur lors du chargement du badge');
    } finally {
      setLoading(false);
    }
  };

  const handleRegenerate = async () => {
    try {
      setRegenerating(true);
      setError(null);
      
      // Simuler la régénération
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const newBadge: BadgeToken = {
        id: badge?.id || 1,
        token: 'XPRT-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
        token_hash: 'hash-' + Math.random().toString(36),
        created_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'active'
      };
      
      setBadge(newBadge);
      setSuccess('Badge régénéré avec succès');
    } catch (err) {
      console.error('Erreur lors de la régénération:', err);
      setError('Erreur lors de la régénération du badge');
    } finally {
      setRegenerating(false);
    }
  };

  const getQRUrl = (token: string, size: number = 200) => {
    return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${token}`;
  };

  const getInitials = (nom: string, prenom: string) => {
    return `${prenom?.[0] || ''}${nom?.[0] || ''}`.toUpperCase();
  };

  if (loading) {
    return (
      <LayoutFix title="Mon Badge">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </LayoutFix>
    );
  }

  return (
    <LayoutFix title="Mon Badge">
      <div className="max-w-4xl mx-auto">
        {/* En-tête */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Mon Badge</h1>
              <p className="text-gray-600">Gérez votre badge de pointage</p>
            </div>
            <button
              onClick={handleRegenerate}
              disabled={regenerating}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {regenerating ? 'Génération...' : 'Régénérer'}
            </button>
          </div>
        </div>

        {/* Messages */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
            {success}
          </div>
        )}

        {badge ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Badge */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Badge de pointage</h2>
              <div className="flex flex-col items-center">
                {/* Photo et informations */}
                <div className="w-32 h-40 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg shadow-lg p-4 mb-4">
                  <div className="bg-white rounded-full w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                    <span className="text-xl font-bold text-blue-600">
                      {getInitials(user?.nom || '', user?.prenom || '')}
                    </span>
                  </div>
                  <div className="text-center text-white">
                    <p className="font-semibold text-sm">{user?.prenom} {user?.nom}</p>
                    <p className="text-xs opacity-90">{user?.poste || 'Employé'}</p>
                  </div>
                </div>

                {/* QR Code */}
                <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                  <img 
                    src={getQRUrl(badge.token)} 
                    alt="QR Code" 
                    className="w-48 h-48 mx-auto"
                  />
                  <p className="text-xs text-gray-500 text-center mt-2">
                    Token: {badge.token.substring(0, 20)}...
                  </p>
                </div>
              </div>
            </div>

            {/* Informations */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Informations</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">ID Employé</label>
                  <p className="text-gray-900">{user?.id}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nom complet</label>
                  <p className="text-gray-900">{user?.prenom} {user?.nom}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <p className="text-gray-900">{user?.email}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Département</label>
                  <p className="text-gray-900">{user?.departement || 'Non spécifié'}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date de création</label>
                  <p className="text-gray-900">
                    {new Date(badge.created_at).toLocaleDateString('fr-FR')}
                  </p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Statut</label>
                  <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                    Actif
                  </span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun badge</h3>
              <p className="text-gray-600 mb-4">Vous n'avez pas encore de badge de pointage</p>
              <button
                onClick={handleRegenerate}
                disabled={regenerating}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {regenerating ? 'Génération...' : 'Générer mon badge'}
              </button>
            </div>
          </div>
        )}

        {/* Instructions */}
        <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Comment utiliser votre badge</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <h4 className="font-medium text-gray-900 mb-2">Présentez votre badge</h4>
              <p className="text-sm text-gray-600">Approchez votre QR code du scanner</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h4 className="font-medium text-gray-900 mb-2">Validation</h4>
              <p className="text-sm text-gray-600">Votre pointage est enregistré instantanément</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h4 className="font-medium text-gray-900 mb-2">Validation</h4>
              <p className="text-sm text-gray-600">Votre pointage est enregistré instantanément</p>
            </div>
          </div>
        </div>
      </div>
    </LayoutFix>
  );
}
