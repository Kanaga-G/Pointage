import React, { useState, useEffect } from 'react'
import { 
  Clock, 
  Calendar, 
  User, 
  Bell, 
  LogOut, 
  Menu, 
  Plus, 
  AlertCircle, 
  CheckCircle, 
  TrendingUp, 
  Activity, 
  FileText, 
  Settings, 
  MapPin, 
  Coffee, 
  Home, 
  RefreshCw,
  Timer,
  Users,
  BarChart3,
  Download,
  Search,
  Filter,
  Eye,
  Edit,
  Play,
  Pause,
  History,
  X
} from 'lucide-react'
import Header from '../components/layout/Header'
import Sidebar from '../components/layout/Sidebar'

interface Pointage {
  id: number
  date_heure: string
  type: 'arrivée' | 'départ'
  statut: 'normal' | 'retard' | 'absent'
  lieu?: string
}

interface Demande {
  id: number
  type: 'congé' | 'permission' | 'maladie'
  date_debut: string
  date_fin: string
  motif: string
  statut: 'en_attente' | 'approuvée' | 'rejetée'
  created_at: string
}

interface Statistique {
  total_heures: number
  jours_travaillés: number
  retards: number
  absences: number
  pointages_mois: number
}

interface UserInfo {
  id: number
  prenom: string
  nom: string
  email: string
  departement: string
  poste: string
  telephone: string
  role: string
  photo?: string
}

export default function EmployeDashboardImproved() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeSection, setActiveSection] = useState('overview')
  const [loading, setLoading] = useState(true)
  const [showPointageModal, setShowPointageModal] = useState(false)
  const [showDemandeModal, setShowDemandeModal] = useState(false)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [isPointed, setIsPointed] = useState(false)
  const [lastPointage, setLastPointage] = useState<Pointage | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  
  // États pour les données
  const [user] = useState<UserInfo>({
    id: 1,
    prenom: 'Jean',
    nom: 'Dupont',
    email: 'jean.dupont@email.com',
    departement: 'IT',
    poste: 'Développeur',
    telephone: '0123456789',
    role: 'employee'
  })

  const [statistiques, setStatistiques] = useState<Statistique>({
    total_heures: 168,
    jours_travaillés: 22,
    retards: 2,
    absences: 1,
    pointages_mois: 44
  })

  const [pointages, setPointages] = useState<Pointage[]>([
    { id: 1, date_heure: '2024-01-15 08:45', type: 'arrivée', statut: 'normal' },
    { id: 2, date_heure: '2024-01-15 17:30', type: 'départ', statut: 'normal' },
    { id: 3, date_heure: '2024-01-14 09:15', type: 'arrivée', statut: 'retard' },
    { id: 4, date_heure: '2024-01-14 17:45', type: 'départ', statut: 'normal' }
  ])

  const [demandes, setDemandes] = useState<Demande[]>([
    {
      id: 1,
      type: 'congé',
      date_debut: '2024-01-20',
      date_fin: '2024-01-22',
      motif: 'Vacances familiales',
      statut: 'approuvée',
      created_at: '2024-01-10'
    },
    {
      id: 2,
      type: 'permission',
      date_debut: '2024-01-16',
      date_fin: '2024-01-16',
      motif: 'Rendez-vous médical',
      statut: 'en_attente',
      created_at: '2024-01-14'
    }
  ])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    // Simuler le chargement des données
    setTimeout(() => {
      setLoading(false)
    }, 1000)
  }, [])

  const handlePointage = async () => {
    try {
      setLoading(true)
      // Simuler un appel API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const newPointage: Pointage = {
        id: pointages.length + 1,
        date_heure: currentTime.toISOString(),
        type: isPointed ? 'départ' : 'arrivée',
        statut: 'normal'
      }
      
      setPointages([newPointage, ...pointages])
      setLastPointage(newPointage)
      setIsPointed(!isPointed)
      setShowPointageModal(false)
    } catch (error) {
      console.error('Erreur lors du pointage:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleExport = (format: 'pdf' | 'excel') => {
    console.log(`Exporting data as ${format}`)
  }

  const StatCard = ({ title, value, icon: Icon, color, subtitle }: {
    title: string
    value: string | number
    icon: React.ComponentType<any>
    color: string
    subtitle?: string
  }) => (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-all duration-200">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">{value}</p>
          {subtitle && (
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{subtitle}</p>
          )}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
      </div>
    </div>
  )

  const PointageButton = () => (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-8">
      <div className="text-center">
        <div className="mb-6">
          <p className="text-3xl font-bold text-gray-900 dark:text-white">
            {currentTime.toLocaleTimeString('fr-FR')}
          </p>
          <p className="text-gray-500 dark:text-gray-400">
            {currentTime.toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
        
        <button
          onClick={() => setShowPointageModal(true)}
          disabled={loading}
          className={`inline-flex items-center px-8 py-4 text-lg font-medium text-white rounded-xl transition-all duration-200 ${
            isPointed 
              ? 'bg-red-600 hover:bg-red-700' 
              : 'bg-green-600 hover:bg-green-700'
          } ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {loading ? (
            <RefreshCw className="h-6 w-6 mr-3 animate-spin" />
          ) : isPointed ? (
            <Pause className="h-6 w-6 mr-3" />
          ) : (
            <Play className="h-6 w-6 mr-3" />
          )}
          {isPointed ? 'Pointer le départ' : 'Pointer l\'arrivée'}
        </button>
        
        {lastPointage && (
          <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
            Dernier pointage: {lastPointage.type} à {new Date(lastPointage.date_heure).toLocaleTimeString('fr-FR')}
          </div>
        )}
      </div>
    </div>
  )

  const RecentPointages = () => (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Pointages récents</h3>
      </div>
      <div className="divide-y divide-gray-200 dark:divide-gray-700">
        {pointages.slice(0, 5).map((pointage) => (
          <div key={pointage.id} className="p-6 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`p-2 rounded-lg ${
                  pointage.type === 'arrivée' ? 'bg-green-100 dark:bg-green-900' : 'bg-blue-100 dark:bg-blue-900'
                }`}>
                  <Clock className={`h-5 w-5 ${
                    pointage.type === 'arrivée' ? 'text-green-600 dark:text-green-400' : 'text-blue-600 dark:text-blue-400'
                  }`} />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {pointage.type === 'arrivée' ? 'Arrivée' : 'Départ'}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {new Date(pointage.date_heure).toLocaleDateString('fr-FR')}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900 dark:text-white">
                  {new Date(pointage.date_heure).toLocaleTimeString('fr-FR')}
                </p>
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                  pointage.statut === 'normal' 
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                }`}>
                  {pointage.statut === 'normal' ? 'Normal' : 'Retard'}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )

  const DemandesList = () => (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Mes demandes</h3>
          <button
            onClick={() => setShowDemandeModal(true)}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nouvelle demande
          </button>
        </div>
      </div>
      <div className="divide-y divide-gray-200 dark:divide-gray-700">
        {demandes.map((demande) => (
          <div key={demande.id} className="p-6 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3">
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                    demande.type === 'congé' 
                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                      : demande.type === 'permission'
                      ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                      : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                  }`}>
                    {demande.type}
                  </span>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                    demande.statut === 'approuvée'
                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                      : demande.statut === 'rejetée'
                      ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                      : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                  }`}>
                    {demande.statut === 'approuvée' && <CheckCircle className="h-3 w-3 mr-1" />}
                    {demande.statut === 'rejetée' && <AlertCircle className="h-3 w-3 mr-1" />}
                    {demande.statut === 'en_attente' && <Clock className="h-3 w-3 mr-1" />}
                    {demande.statut}
                  </span>
                </div>
                <p className="text-sm text-gray-900 dark:text-white mt-2">{demande.motif}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Du {new Date(demande.date_debut).toLocaleDateString('fr-FR')} au {new Date(demande.date_fin).toLocaleDateString('fr-FR')}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <button className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                  <Eye className="h-4 w-4" />
                </button>
                {demande.statut === 'en_attente' && (
                  <button className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
                    <Edit className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      )
    }

    switch (activeSection) {
      case 'overview':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <PointageButton />
              </div>
              <div className="lg:col-span-2">
                <div className="grid grid-cols-2 gap-6">
                  <StatCard
                    title="Heures ce mois"
                    value={`${statistiques.total_heures}h`}
                    icon={Clock}
                    color="bg-blue-600"
                    subtitle={`${statistiques.jours_travaillés} jours travaillés`}
                  />
                  <StatCard
                    title="Pointages ce mois"
                    value={statistiques.pointages_mois}
                    icon={Activity}
                    color="bg-green-600"
                  />
                  <StatCard
                    title="Retards"
                    value={statistiques.retards}
                    icon={AlertCircle}
                    color="bg-yellow-600"
                  />
                  <StatCard
                    title="Absences"
                    value={statistiques.absences}
                    icon={X}
                    color="bg-red-600"
                  />
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <RecentPointages />
              <DemandesList />
            </div>
          </div>
        )
      
      case 'pointage':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Historique des pointages</h2>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Filtres
                </button>
                <button
                  onClick={() => handleExport('pdf')}
                  className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  <Download className="h-4 w-4 mr-2" />
                  PDF
                </button>
                <button
                  onClick={() => handleExport('excel')}
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Excel
                </button>
              </div>
            </div>
            <RecentPointages />
          </div>
        )
      
      case 'demandes':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Mes demandes</h2>
              <button
                onClick={() => setShowDemandeModal(true)}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Plus className="h-4 w-4 mr-2" />
                Nouvelle demande
              </button>
            </div>
            <DemandesList />
          </div>
        )
      
      default:
        return <div>Section en cours de développement</div>
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} userRole="employee" />
      
      <div className={`transition-all duration-300 ${sidebarOpen ? 'lg:ml-64' : ''}`}>
        <Header 
          user={user}
          title="Espace Employé"
          onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
          sidebarOpen={sidebarOpen}
        />
        
        <main className="p-6">
          {renderContent()}
        </main>
      </div>

      {/* Pointage Modal */}
      {showPointageModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Confirmer le pointage
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Vous êtes sur le point de pointer votre {isPointed ? 'départ' : 'arrivée'} à {currentTime.toLocaleTimeString('fr-FR')}.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowPointageModal(false)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handlePointage}
                disabled={loading}
                className={`px-4 py-2 text-white rounded-lg transition-colors ${
                  isPointed ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'
                } ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {loading ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  'Confirmer'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
