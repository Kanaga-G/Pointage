import React from 'react';
import ModernAdminDashboard from './admin/ModernAdminDashboard';

/**
 * Page d'entrée du dashboard admin moderne
 * Cette page sert de point d'entrée pour le nouveau dashboard
 * avec un design UI/UX moderne et professionnel
 */
const AdminDashboardPage: React.FC = () => {
  return (
    <div className="App">
      <ModernAdminDashboard />
    </div>
  );
};

export default AdminDashboardPage;
