import React, { useState, useEffect } from 'react'
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Shield, 
  Edit, 
  Save, 
  X, 
  Settings,
  Activity,
  Users,
  ArrowLeft,
  Crown,
  Key
} from 'lucide-react'
import { useNavigate, useParams } from 'react-router-dom'
import Header from '../components/layout/Header'
import Sidebar from '../components/layout/Sidebar'

interface AdminDetails {
  id: number
  prenom: string
  nom: string
  email: string
  telephone?: string
  role: string
  adresse?: string
  last_activity?: string
  status?: string
  photo?: string
  permissions: {
    can_manage_employes: boolean
    can_manage_pointages: boolean
    can_manage_demandes: boolean
    can_view_reports: boolean
    can_manage_settings: boolean
    is_super_admin: boolean
  }
  activity_log: Array<{
    id: number
    action: string
    target: string
    date: string
    ip_address: string
  }>
  managed_employes: Array<{
    id: number
    prenom: string
    nom: string
    departement: string
  }>
}

export default function AdminDetails() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [activeTab, setActiveTab] = useState<'profil' | 'permissions' | 'activite' | 'equipe'>('profil')
  
  const [admin, setAdmin] = useState<AdminDetails | null>(null)
  const [formData, setFormData] = useState({
    telephone: '',
    adresse: '',
    email: '',
    role: 'admin'
  })

  useEffect(() => {
    if (id) {
      loadAdminDetails(parseInt(id))
    }
  }, [id])

  const loadAdminDetails = async (adminId: number) => {
    try {
      setLoading(true)
      // Simuler un appel API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const mockData: AdminDetails = {
        id: adminId,
        prenom: 'Marie',
        nom: 'Martin',
        email: 'marie.martin@email.com',
        telephone: '0123456789',
        role: 'admin',
        adresse: '456 Avenue des Champs-Élysées, 75008 Paris',
        last_activity: new Date().toISOString(),
        status: 'active',
        photo: '',
        permissions: {
          can_manage_employes: true,
          can_manage_pointages: true,
          can_manage_demandes: true,
          can_view_reports: true,
          can_manage_settings: false,
          is_super_admin: false
        },
        activity_log: [
          {
            id: 1,
            action: 'Modification employé',
            target: 'Jean Dupont',
            date: '2024-01-15 14:30:00',
            ip_address: '192.168.1.100'
          },
          {
            id: 2,
            action: 'Validation demande',
            target: 'Congé Paul Durand',
            date: '2024-01-15 10:15:00',
            ip_address: '192.168.1.100'
          },
          {
            id: 3,
            action: 'Export rapport',
            target: 'Rapport mensuel',
            date: '2024-01-14 16:45:00',
            ip_address: '192.168.1.100'
          },
          {
            id: 4,
            action: 'Création employé',
            target: 'Sophie Bernard',
            date: '2024-01-14 09:00:00',
            ip_address: '192.168.1.100'
          }
        ],
        managed_employes: [
          { id: 1, prenom: 'Jean', nom: 'Dupont', departement: 'IT' },
          { id: 2, prenom: 'Paul', nom: 'Durand', departement: 'RH' },
          { id: 3, prenom: 'Sophie', nom: 'Bernard', departement: 'Marketing' },
          { id: 4, prenom: 'Pierre', nom: 'Lefebvre', departement: 'Ventes' }
        ]
      }
      
      setAdmin(mockData)
      setFormData({
        telephone: mockData.telephone || '',
        adresse: mockData.adresse || '',
        email: mockData.email,
        role: mockData.role
      })
    } catch (error) {
      console.error('Erreur lors du chargement des détails:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    if (!admin) return
    
    try {
      setSaving(true)
      // Simuler un appel API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setAdmin({
        ...admin,
        telephone: formData.telephone,
        adresse: formData.adresse,
        email: formData.email,
        role: formData.role
      })
      
      setEditing(false)
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error)
    } finally {
      setSaving(false)
    }
  }

  const handleCancel = () => {
    if (admin) {
      setFormData({
        telephone: admin.telephone || '',
        adresse: admin.adresse || '',
        email: admin.email,
        role: admin.role
      })
    }
    setEditing(false)
  }

  const togglePermission = (permission: keyof AdminDetails['permissions']) => {
    if (!admin || !admin.permissions.is_super_admin) return
    
    setAdmin({
      ...admin,
      permissions: {
        ...admin.permissions,
        [permission]: !admin.permissions[permission]
      }
    })
  }

  const currentUser = {
    id: admin?.id || 1,
    prenom: admin?.prenom || 'Admin',
    nom: admin?.nom || 'User',
    email: admin?.email || 'admin@example.com',
    role: 'admin',
    avatar: ''
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!admin) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Administrateur non trouvé</h2>
          <button
            onClick={() => navigate('/admin/admins')}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à la liste
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} userRole="admin" />
      
      <div className={`transition-all duration-300 ${sidebarOpen ? 'lg:ml-64' : ''}`}>
        <Header 
          user={currentUser}
          title={`Profil Admin: ${admin.prenom} ${admin.nom}`}
          onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
          sidebarOpen={sidebarOpen}
        />
        
        <main className="p-6">
          {/* Bouton retour */}
          <button
            onClick={() => navigate('/admin/admins')}
            className="inline-flex items-center px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-6 transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à la liste des admins
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Carte profil */}
            <div className="lg:col-span-1">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <div className="text-center">
                  <div className="relative">
                    <div className="h-24 w-24 mx-auto bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mb-4">
                      {admin.prenom[0]}{admin.nom[0]}
                    </div>
                    {admin.permissions.is_super_admin && (
                      <div className="absolute top-0 right-1/4">
                        <Crown className="h-6 w-6 text-yellow-500" />
                      </div>
                    )}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    {admin.prenom} {admin.nom}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4 capitalize">{admin.role}</p>
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    admin.status === 'active' 
                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                      : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                  }`}>
                    {admin.status === 'active' ? 'Actif' : 'Inactif'}
                  </span>
                </div>
                
                <div className="mt-6 space-y-3">
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <Shield className="h-4 w-4 mr-2" />
                    {admin.permissions.is_super_admin ? 'Super Administrateur' : 'Administrateur'}
                  </div>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <Activity className="h-4 w-4 mr-2" />
                    Dernière activité: {admin.last_activity ? new Date(admin.last_activity).toLocaleDateString('fr-FR') : 'Jamais'}
                  </div>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <Users className="h-4 w-4 mr-2" />
                    {admin.managed_employes.length} employés gérés
                  </div>
                </div>
              </div>
            </div>

            {/* Contenu principal */}
            <div className="lg:col-span-2">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
                {/* Tabs */}
                <div className="border-b border-gray-200 dark:border-gray-700">
                  <nav className="flex space-x-8 px-6">
                    {[
                      { id: 'profil', label: 'Profil' },
                      { id: 'permissions', label: 'Permissions' },
                      { id: 'activite', label: 'Activité' },
                      { id: 'equipe', label: 'Équipe gérée' }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                          activeTab === tab.id
                            ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                            : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </nav>
                </div>

                <div className="p-6">
                  {/* Actions */}
                  {activeTab === 'profil' && (
                    <div className="flex justify-end mb-4">
                      {!editing ? (
                        <button
                          onClick={() => setEditing(true)}
                          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Modifier
                        </button>
                      ) : (
                        <div className="flex space-x-3">
                          <button
                            onClick={handleCancel}
                            disabled={saving}
                            className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
                          >
                            <X className="h-4 w-4 mr-2" />
                            Annuler
                          </button>
                          <button
                            onClick={handleSave}
                            disabled={saving}
                            className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                          >
                            {saving ? (
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            ) : (
                              <Save className="h-4 w-4 mr-2" />
                            )}
                            {saving ? 'Sauvegarde...' : 'Sauvegarder'}
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Contenu des tabs */}
                  {activeTab === 'profil' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          value={editing ? formData.email : admin.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          disabled={!editing}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:bg-gray-50 dark:disabled:bg-gray-800 disabled:text-gray-500 dark:disabled:text-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Téléphone
                        </label>
                        <input
                          type="tel"
                          value={editing ? formData.telephone : admin.telephone}
                          onChange={(e) => setFormData({...formData, telephone: e.target.value})}
                          disabled={!editing}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:bg-gray-50 dark:disabled:bg-gray-800 disabled:text-gray-500 dark:disabled:text-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Rôle
                        </label>
                        <select
                          value={editing ? formData.role : admin.role}
                          onChange={(e) => setFormData({...formData, role: e.target.value})}
                          disabled={!editing || admin.permissions.is_super_admin}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:bg-gray-50 dark:disabled:bg-gray-800 disabled:text-gray-500 dark:disabled:text-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        >
                          <option value="admin">Administrateur</option>
                          <option value="super_admin">Super Administrateur</option>
                        </select>
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Adresse
                        </label>
                        <textarea
                          value={editing ? formData.adresse : admin.adresse}
                          onChange={(e) => setFormData({...formData, adresse: e.target.value})}
                          disabled={!editing}
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:bg-gray-50 dark:disabled:bg-gray-800 disabled:text-gray-500 dark:disabled:text-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                    </div>
                  )}

                  {activeTab === 'permissions' && (
                    <div className="space-y-6">
                      {admin.permissions.is_super_admin && (
                        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                          <p className="text-sm text-blue-800 dark:text-blue-200">
                            <strong>Super Administrateur:</strong> Cet utilisateur a tous les droits et peut modifier les permissions des autres administrateurs.
                          </p>
                        </div>
                      )}
                      
                      <div className="space-y-4">
                        {Object.entries(admin.permissions).filter(([key]) => key !== 'is_super_admin').map(([key, value]) => (
                          <div key={key} className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                            <div className="flex items-center space-x-3">
                              <Key className="h-5 w-5 text-gray-400" />
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">
                                  {key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                </p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">
                                  {key === 'can_manage_employes' && 'Gérer les employés (création, modification, suppression)'}
                                  {key === 'can_manage_pointages' && 'Gérer les pointages et les horaires'}
                                  {key === 'can_manage_demandes' && 'Valider ou rejeter les demandes de congé'}
                                  {key === 'can_view_reports' && 'Accéder aux rapports et statistiques'}
                                  {key === 'can_manage_settings' && 'Modifier les paramètres du système'}
                                </p>
                              </div>
                            </div>
                            <button
                              onClick={() => togglePermission(key as keyof AdminDetails['permissions'])}
                              disabled={!admin.permissions.is_super_admin}
                              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                                value ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700'
                              } ${!admin.permissions.is_super_admin ? 'opacity-50 cursor-not-allowed' : ''}`}
                            >
                              <span
                                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                                  value ? 'translate-x-6' : 'translate-x-1'
                                }`}
                              />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === 'activite' && (
                    <div>
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Journal d'activité</h4>
                      
                      <div className="space-y-4">
                        {admin.activity_log.map((activity) => (
                          <div key={activity.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">{activity.action}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">Cible: {activity.target}</p>
                                <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                                  {new Date(activity.date).toLocaleDateString('fr-FR')} à {new Date(activity.date).toLocaleTimeString('fr-FR')}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="text-xs text-gray-500 dark:text-gray-400">IP: {activity.ip_address}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {activeTab === 'equipe' && (
                    <div>
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                        Équipe gérée ({admin.managed_employes.length} employés)
                      </h4>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {admin.managed_employes.map((employe) => (
                          <div key={employe.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                            <div className="flex items-center space-x-3">
                              <div className="h-10 w-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-medium">
                                {employe.prenom[0]}{employe.nom[0]}
                              </div>
                              <div>
                                <p className="font-medium text-gray-900 dark:text-white">
                                  {employe.prenom} {employe.nom}
                                </p>
                                <p className="text-sm text-gray-500 dark:text-gray-400">{employe.departement}</p>
                              </div>
                            </div>
                            <div className="mt-3">
                              <button
                                onClick={() => navigate(`/employe/${employe.id}`)}
                                className="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 transition-colors"
                              >
                                Voir le profil →
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
