// Landing Page Ultra-Moderne - Version Corrigée et Améliorée
import React, { useEffect, useState } from 'react';

// Type declarations
declare global {
  interface Window {
    landingPage?: any;
    LandingPageController?: any;
  }
}

// Import CSS
import '../styles/landing-page-ultra.css';

// Données pour la landing page
const heroData = {
  stats: [
    { number: '+95%', label: 'Productivité', delay: '0' },
    { number: '-80%', label: 'Erreurs', delay: '100' },
    { number: '100%', label: 'Sécurité', delay: '200' }
  ],
  trustBadges: [
    { icon: 'fa-shield-check', text: 'RGPD Compliant' },
    { icon: 'fa-cloud', text: 'Cloud Français' },
    { icon: 'fa-headset', text: 'Support 7j/7' }
  ],
  liveStats: {
    employees: 42,
    lastScan: '08:42',
    avgTime: '1.8s'
  }
};

const featuresData = [
  {
    icon: 'fa-qrcode',
    title: 'Génération QR Code',
    description: 'Créez des QR codes dynamiques sécurisés pour chaque session de travail',
    features: ['Codes uniques', 'Géolocalisation', 'Expiration auto', 'Personnalisable']
  },
  {
    icon: 'fa-mobile-alt',
    title: 'Scan Mobile',
    description: 'Scan ultra-rapide avec n\'importe quel smartphone, aucune app requise',
    features: ['Aucune installation', 'Compatibilité totale', 'Validation instantanée', 'Scan NFC']
  },
  {
    icon: 'fa-database',
    title: 'Stockage Sécurisé',
    description: 'Données chiffrées AES-256 avec horodatage certifié et backup automatique',
    features: ['Chiffrement AES-256', 'Horodatage certifié', 'Backup automatique', 'Redondance géographique']
  },
  {
    icon: 'fa-chart-bar',
    title: 'Analytics Avancées',
    description: 'Dashboard complet avec rapports automatiques et analyses temps réel',
    features: ['Dashboard temps réel', 'Export PDF/Excel', 'Alertes intelligentes', 'Tableaux de bord']
  }
];

const benefitsData = [
  {
    icon: 'fa-stopwatch',
    title: 'Gain de temps exceptionnel',
    description: 'Réduisez de 80% le temps consacré à la gestion des présences grâce à l\'automatisation',
    value: '80%'
  },
  {
    icon: 'fa-chart-line',
    title: 'Précision maximale',
    description: 'Horodatage certifié et données 100% fiables pour une conformité parfaite',
    value: '100%'
  },
  {
    icon: 'fa-lock',
    title: 'Sécurité renforcée',
    description: 'Système anti-fraude avec géolocalisation et QR codes uniques',
    value: '256-bit'
  },
  {
    icon: 'fa-euro-sign',
    title: 'ROI immédiat',
    description: 'Réduction des coûts administratifs dès le premier mois grâce à l\'automatisation',
    value: '+30%'
  }
];

export default function LandingPage(): JSX.Element {
  const [activeTab, setActiveTab] = useState('employee');
  const [scanning, setScanning] = useState(true);
  const [scanned, setScanned] = useState(false);

  useEffect(() => {
    // Add body classes
    document.body.classList.add('home-page', 'modern-design');

    // Add background particles
    const particlesContainer = document.createElement('div');
    particlesContainer.className = 'background-particles';
    
    // Create 10 particles
    for (let i = 0; i < 10; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particlesContainer.appendChild(particle);
    }
    
    document.body.appendChild(particlesContainer);

    // Simple intersection observer for scroll animations
    const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      });
    }, observerOptions);

    // Observe elements
    document.querySelectorAll('.feature-card-modern, .benefit-item, .stat-card-modern').forEach((el) => {
      observer.observe(el);
    });

    // QR dots animation
    const qrDots = document.querySelectorAll('.qr-dots circle');
    qrDots.forEach((dot, index) => {
      (dot as SVGCircleElement).style.animationDelay = `${index * 0.15}s`;
    });

    // Scanning animation
    const interval = window.setInterval(() => {
      if (scanning && !scanned) {
        setScanning(false);
        setScanned(true);
        setTimeout(() => {
          setScanning(true);
          setScanned(false);
        }, 3000);
      }
    }, 4000);

    // Scroll animation for shapes
    const shapes = document.querySelectorAll('.shape');
    const onScroll = () => {
      const scrolled = window.scrollY;
      shapes.forEach((shape, index) => {
        const speed = 0.2 + index * 0.1;
        const yPos = -(scrolled * speed);
        (shape as HTMLElement).style.transform = `translateY(${yPos}px) rotate(${scrolled * 0.1}deg)`;
      });
    };
    window.addEventListener('scroll', onScroll, { passive: true });

    // Cleanup
    return () => {
      observer.disconnect();
      window.clearInterval(interval);
      window.removeEventListener('scroll', onScroll);
      if (particlesContainer.parentNode) {
        particlesContainer.parentNode.removeChild(particlesContainer);
      }
    };
  }, []);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  return (
    <main className="modern-homepage">
      {/* Hero Section */}
      <section className="hero-section-modern">
        <div className="hero-background">
          <div className="animated-shapes">
            <div className="shape shape-1" />
            <div className="shape shape-2" />
            <div className="shape shape-3" />
          </div>
        </div>

        <div className="container">
          <div className="row align-items-center min-vh-80">
            <div className="col-lg-6 hero-content">
              <div className="badge-modern">
                <i className="fas fa-bolt" />
                <span>Solution Innovante</span>
              </div>

              <h1 className="hero-title-modern">
                <span className="gradient-text">Xpert Pro</span>
                <br />
                Système de Pointage<br />
                <span className="highlight-modern">Intelligent</span>
              </h1>

              <p className="hero-subtitle-modern">
                Transformez votre gestion des présences avec notre solution QR Code moderne. Simple,
                rapide et sécurisé pour les équipes d'aujourd'hui.
              </p>

              {/* Stats */}
              <div className="hero-stats-modern">
                {heroData.stats.map((stat, index) => (
                  <div key={index} className="stat-modern" data-delay={stat.delay}>
                    <div className="stat-number" data-target={stat.number}>{stat.number}</div>
                    <div className="stat-label">{stat.label}</div>
                  </div>
                ))}
              </div>

              {/* CTA Buttons */}
              <div className="cta-buttons-modern">
                <a href="/login?type=employee" className="btn-modern btn-primary-modern">
                  <i className="fas fa-user-check" />
                  <span>Connexion Employé</span>
                </a>
                <a href="/login?type=admin" className="btn-modern btn-secondary-modern">
                  <i className="fas fa-chart-line" />
                  <span>Dashboard Admin</span>
                </a>
              </div>

              {/* Trust Badges */}
              <div className="trust-badges">
                {heroData.trustBadges.map((badge, index) => (
                  <div key={index} className="trust-item">
                    <i className={`fas ${badge.icon}`} />
                    <span>{badge.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Hero Visual */}
            <div className="col-lg-6 hero-visual">
              <div className="floating-dashboard">
                <div className="dashboard-preview-modern">
                  <div className="dashboard-header-modern">
                    <div className="dashboard-title">
                      <i className="fas fa-qrcode" />
                      <h6>Pointage en direct</h6>
                    </div>
                    <div className="status-badge active">
                      <span className="pulse" />
                      En ligne
                    </div>
                  </div>

                  {/* QR Scanner */}
                  <div className="qr-scanner-modern">
                    <div className="qr-container-modern">
                      <div className="qr-code-animated">
                        <svg viewBox="0 0 100 100" className="qr-svg">
                          <path
                            className="qr-pattern"
                            d="M10,10 L30,10 L30,30 L10,30 Z M70,10 L90,10 L90,30 L70,30 Z M10,70 L30,70 L30,90 L10,90 Z M70,70 L90,70 L90,90 L70,70 Z"
                            fill="#0672e4"
                            fillOpacity={0.9}
                          />
                          <g className="qr-dots">
                            {[...Array(8).keys()].map((_, i) => (
                              <circle key={i} cx={45 + (i % 2) * 20} cy={25 + Math.floor(i / 2) * 20} r="2" fill="#0672e4" />
                            ))}
                          </g>
                        </svg>

                        <div className="scan-beam">
                          <div className="scan-line" />
                        </div>
                      </div>

                      <div className="scan-info">
                        <div className="scanning-animation">
                          <i className="fas fa-mobile-alt" />
                          <div className="scanning-text">
                            <span className={scanning ? 'scanning' : 'success'}>
                              {scanning ? (
                                <>
                                  <i className="fas fa-spinner fa-spin" />
                                  Scan en cours...
                                </>
                              ) : (
                                <>
                                  <i className="fas fa-check" />
                                  Pointé !
                                </>
                              )}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Live Stats */}
                    <div className="live-stats">
                      <div className="stat-card-modern">
                        <div className="stat-icon">
                          <i className="fas fa-users" />
                        </div>
                        <div className="stat-content">
                          <div className="stat-value">{heroData.liveStats.employees}</div>
                          <div className="stat-label">Présents</div>
                        </div>
                      </div>
                      <div className="stat-card-modern">
                        <div className="stat-icon">
                          <i className="fas fa-clock" />
                        </div>
                        <div className="stat-content">
                          <div className="stat-value">{heroData.liveStats.lastScan}</div>
                          <div className="stat-label">Dernier scan</div>
                        </div>
                      </div>
                      <div className="stat-card-modern">
                        <div className="stat-icon">
                          <i className="fas fa-bolt" />
                        </div>
                        <div className="stat-content">
                          <div className="stat-value">{heroData.liveStats.avgTime}</div>
                          <div className="stat-label">Temps moyen</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-modern-section">
        <div className="container">
          <div className="section-header-modern">
            <h2 className="section-title-modern">Comment ça marche ?</h2>
            <p className="section-subtitle-modern">Un processus simple en 4 étapes</p>
            <div className="title-decoration" />
          </div>

          <div className="row g-4">
            {featuresData.map((feature, index) => (
              <div key={index} className="col-lg-3 col-md-6">
                <div className="feature-card-modern" data-delay={index * 100}>
                  <div className="feature-icon-wrapper">
                    <div className="feature-icon-bg"></div>
                    <i className={`fas ${feature.icon} feature-icon`}></i>
                  </div>
                  <h3 className="feature-title-modern">{feature.title}</h3>
                  <p className="feature-description-modern">{feature.description}</p>
                  <ul className="feature-list">
                    {feature.features.map((item, itemIndex) => (
                      <li key={itemIndex}>
                        <i className="fas fa-check"></i>
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="feature-hover-effect"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Dashboard Showcase */}
      <section className="dashboard-showcase">
        <div className="container">
          <div className="section-header-modern">
            <h2 className="section-title-modern">Des interfaces intuitives</h2>
            <p className="section-subtitle-modern">Conçues pour simplifier votre quotidien</p>
            <div className="title-decoration" />
          </div>

          <div className="dashboard-tabs">
            <button 
              className={`tab-button ${activeTab === 'employee' ? 'active' : ''}`}
              onClick={() => handleTabChange('employee')}
            >
              <i className="fas fa-user-tie"></i>
              Vue Employé
            </button>
            <button 
              className={`tab-button ${activeTab === 'admin' ? 'active' : ''}`}
              onClick={() => handleTabChange('admin')}
            >
              <i className="fas fa-chart-pie"></i>
              Vue Admin
            </button>
            <button 
              className={`tab-button ${activeTab === 'mobile' ? 'active' : ''}`}
              onClick={() => handleTabChange('mobile')}
            >
              <i className="fas fa-mobile-alt"></i>
              Version Mobile
            </button>
          </div>

          <div className="tab-content">
            <div className={`tab-pane ${activeTab === 'employee' ? 'active' : ''}`} id="employee-tab">
              <div className="dashboard-preview-large">
                <div className="dashboard-header">
                  <div className="user-info">
                    <div className="avatar-large">JD</div>
                    <div>
                      <h5>Jean Dupont</h5>
                      <p className="role">Développeur Full-Stack</p>
                    </div>
                  </div>
                  <div className="today-info">
                    <div className="date">Aujourd'hui, 15 Mars 2024</div>
                    <div className="current-time">08:42:15</div>
                  </div>
                </div>

                <div className="dashboard-grid">
                  <div className="stat-card-large">
                    <div className="stat-icon-large">
                      <i className="fas fa-clock"></i>
                    </div>
                    <div className="stat-content-large">
                      <div className="stat-value-large">7h 42m</div>
                      <div className="stat-label-large">Temps travaillé</div>
                    </div>
                  </div>
                  <div className="stat-card-large">
                    <div className="stat-icon-large">
                      <i className="fas fa-calendar-check"></i>
                    </div>
                    <div className="stat-content-large">
                      <div className="stat-value-large">21</div>
                      <div className="stat-label-large">Jours présents</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className={`tab-pane ${activeTab === 'admin' ? 'active' : ''}`} id="admin-tab">
              <div className="dashboard-preview-large">
                <div className="dashboard-header">
                  <div className="user-info">
                    <div className="avatar-large">AD</div>
                    <div>
                      <h5>Admin Système</h5>
                      <p className="role">Administrateur</p>
                    </div>
                  </div>
                  <div className="today-info">
                    <div className="date">Aujourd'hui, 15 Mars 2024</div>
                    <div className="current-time">08:42:15</div>
                  </div>
                </div>

                <div className="dashboard-grid">
                  <div className="stat-card-large">
                    <div className="stat-icon-large">
                      <i className="fas fa-users"></i>
                    </div>
                    <div className="stat-content-large">
                      <div className="stat-value-large">156</div>
                      <div className="stat-label-large">Employés total</div>
                    </div>
                  </div>
                  <div className="stat-card-large">
                    <div className="stat-icon-large">
                      <i className="fas fa-chart-line"></i>
                    </div>
                    <div className="stat-content-large">
                      <div className="stat-value-large">12</div>
                      <div className="stat-label-large">Scans/jour</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="benefits-modern-section">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-6">
              <div className="benefits-visual">
                <div className="floating-elements">
                  <div className="floating-element speed">
                    <i className="fas fa-bolt"></i>
                    <span>Rapidité</span>
                  </div>
                  <div className="floating-element security">
                    <i className="fas fa-shield-alt"></i>
                    <span>Sécurité</span>
                  </div>
                  <div className="floating-element automation">
                    <i className="fas fa-robot"></i>
                    <span>Automatisation</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-lg-6">
              <div className="benefits-content">
                <h2 className="benefits-title">Pourquoi choisir Xpert Pro ?</h2>

                {benefitsData.map((benefit, index) => (
                  <div key={index} className="benefit-item">
                    <div className="benefit-icon">
                      <i className={`fas ${benefit.icon}`}></i>
                    </div>
                    <div>
                      <h4>{benefit.title}</h4>
                      <p>{benefit.description}</p>
                      <div className="benefit-value">{benefit.value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="final-cta">
        <div className="container">
          <div className="cta-card">
            <h2 className="cta-title">Prêt à transformer votre gestion ?</h2>
            <p className="cta-description">
              Rejoignez des centaines d'entreprises qui font confiance à Xpert Pro 
              pour une gestion des présences moderne et efficace.
            </p>
            <div className="cta-final-buttons">
              <a href="/login" className="btn-modern btn-primary-modern btn-large">
                <i className="fas fa-rocket"></i>
                <span>Commencer Gratuitement</span>
              </a>
              <a href="/demo" className="btn-modern btn-secondary-modern btn-large">
                <i className="fas fa-play"></i>
                <span>Voir la Démo</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
