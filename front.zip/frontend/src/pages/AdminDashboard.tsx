import React, { useEffect, useState } from 'react'
import Header from '../components/Header'
import Sidebar from '../components/Sidebar'
import PanelPointage from '../components/panels/PanelPointage'
import PanelHeures from '../components/panels/PanelHeures'
import PanelDemandes from '../components/panels/PanelDemandes'
import PanelEmployes from '../components/panels/PanelEmployes'
import PanelAdmins from '../components/panels/PanelAdmins'
import PanelRetards from '../components/panels/PanelRetards'
import CalendarPanel from '../components/panels/CalendarPanel'
import { initPanelManager } from '../lib/panelManager'
import { highlightText, animateCounters } from '../lib/uiUtils'

// -------------------------------------------------------------
// Composant `AdminDashboard` : port progressif de
// `admin_dashboard_unifie.php`. Les sections sont commentées
// en français pour faciliter la lecture et poursuite de la migration.
// -------------------------------------------------------------

type DashboardData = {
  stats?: Record<string, any>
  heures_mensuelles?: Record<string, number>
  employes?: any[]
  admins?: any[]
  demandes?: any[]
  retards?: any[]
  temps_totaux?: any[]
  pointages?: any[]
  stats_demandes?: Record<string, any>
}

export default function AdminDashboard() {
  // État principal contenant les données renvoyées par le backend
  const [data, setData] = useState<DashboardData>({})
  const [searchTerm, setSearchTerm] = useState('')
  const [highlightSearch, setHighlightSearch] = useState(false)

  // Chargement initial des données du dashboard
  useEffect(() => {
    fetch('/api/admin/dashboard')
      .then((res) => res.json())
      .then((json) => {
        setData(json || {})
      })
      .catch((err) => console.error('Erreur fetch dashboard', err))
  }, [])

  // Initialisation du gestionnaire de panels (comportement JS porté)
  useEffect(() => {
    initPanelManager(!!(data as any).is_super_admin)
  }, [data])

  // Invocation des utilitaires UI portés : animation des compteurs et highlighting
  useEffect(() => {
    // Animer les compteurs quand les données arrivent
    animateCounters(['stat-total_employes', 'stat-present_today', 'stat-absents_today', 'stat-retards_today'])
  }, [data])

  // Extraction sécurisée des stats (comme dans le PHP)
  const stats = data.stats ?? {}

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1">
        <Header 
          title="Dashboard Administrateur" 
          user={{
            nom: 'Admin',
            prenom: 'User',
            role: 'admin',
            email: 'admin@xpertpro.com'
          }}
          showNavigation={false}
        />

        <main className="p-6 bg-gray-50 min-h-[calc(100vh-64px)]">
          {/* Message recherche (équivalent du bloc PHP) */}
          <div className="mb-4 flex items-center gap-2">
            <input
              placeholder="Recherche globale..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input p-2 border rounded flex-1"
            />
            <button
              className="btn btn-sm btn-primary"
              onClick={() => {
                setHighlightSearch(!!searchTerm)
                if (searchTerm.trim()) highlightText(searchTerm)
              }}
            >
              Rechercher
            </button>
          </div>

          {/* Cartes statistiques */}
          <section className="mb-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard id="stat-total_employes" label="Total employés" value={Number(stats.total_employes ?? 0)} bg="indigo" />
              <StatCard id="stat-present_today" label="Présents aujourd’hui" value={Number(stats.present_today ?? 0)} bg="cyan" />
              <StatCard id="stat-absents_today" label="Absents aujourd’hui" value={Number(stats.absents_today ?? 0)} bg="orange" />
              <StatCard id="stat-retards_today" label="Retards du jour" value={Number(stats.retards_today ?? 0)} bg="red" />
            </div>
          </section>

          {/* Panels dynamiques : on importe les partials portés en composants */}
          <section className="dashboard-content space-y-6">
            <div>
              <PanelPointage data={data.pointages ?? []} />
            </div>

            <div>
              <PanelHeures data={data.temps_totaux ?? []} totalPages={0} />
            </div>

            <div>
              <PanelDemandes data={data.demandes ?? []} stats={data.stats_demandes as any ?? {}} />
            </div>

            <div>
              <PanelEmployes data={data.employes ?? []} />
            </div>

            <div>
              <PanelAdmins data={data.admins ?? []} />
            </div>

            <div>
              <PanelRetards data={data.retards ?? []} />
            </div>
          </section>

          {/* Calendrier (composant séparé) */}
          <div style={{ display: 'none' }}>
            <CalendarPanel />
          </div>
        </main>
      </div>
    </div>
  )
}

// -----------------------------
// Composants utilitaires internes
// -----------------------------
function StatCard({ id, label, value, bg }: { id?: string; label: string; value: number; bg: string }) {
  const colorBg = {
    indigo: 'bg-indigo-100 text-indigo-700',
    cyan: 'bg-cyan-100 text-cyan-700',
    orange: 'bg-orange-100 text-orange-700',
    red: 'bg-red-100 text-red-700'
  }[bg]

  return (
    <div id={id} className={`p-4 rounded-xl shadow-sm ${colorBg}`}>
      <div className="text-sm opacity-80">{label}</div>
      <div className="text-3xl font-semibold">{value}</div>
    </div>
  )
}
