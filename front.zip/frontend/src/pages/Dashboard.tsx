import React from 'react'

const Dashboard: React.FC = () => {
  return (
    <div className="px-4 py-6 sm:px-0">
      <div className="border-4 border-dashed border-gray-200 rounded-lg h-96">
        <div className="p-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Tableau de bord</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900">Employés</h3>
              <p className="text-3xl font-bold text-indigo-600 mt-2">2</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900">Pointages aujourd'hui</h3>
              <p className="text-3xl font-bold text-green-600 mt-2">0</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900">Présents</h3>
              <p className="text-3xl font-bold text-blue-600 mt-2">0</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900">Absents</h3>
              <p className="text-3xl font-bold text-red-600 mt-2">2</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
