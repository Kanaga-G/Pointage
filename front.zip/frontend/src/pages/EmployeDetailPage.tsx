import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, X, Edit2, User, Mail, Phone, Calendar, MapPin, Briefcase } from 'lucide-react';

interface EmployeDetail {
  id: number;
  prenom: string;
  nom: string;
  email: string;
  telephone: string;
  departement: string;
  poste: string;
  date_embauche: string;
  adresse: string;
  statut: 'actif' | 'inactif';
}

const EmployeDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [editMode, setEditMode] = useState(false);
  const [employe, setEmploye] = useState<EmployeDetail | null>(null);
  const [formData, setFormData] = useState<EmployeDetail | null>(null);

  useEffect(() => {
    setTimeout(() => {
      const mockData: EmployeDetail = {
        id: parseInt(id || '1'),
        prenom: 'Jean',
        nom: 'Dupont',
        email: 'jean.dupont@entreprise.com',
        telephone: '+33 6 12 34 56 78',
        departement: 'IT',
        poste: 'Développeur Senior',
        date_embauche: '2020-03-15',
        adresse: '123 Rue de la République, 75001 Paris',
        statut: 'actif'
      };
      setEmploye(mockData);
      setFormData(mockData);
      setLoading(false);
    }, 1000);
  }, [id]);

  const handleInputChange = (field: keyof EmployeDetail, value: string) => {
    if (formData) {
      setFormData({ ...formData, [field]: value });
    }
  };

  const handleSave = () => {
    if (formData) {
      setEmploye(formData);
      setEditMode(false);
      console.log('Données sauvegardées:', formData);
    }
  };

  const handleCancel = () => {
    if (employe) {
      setFormData(employe);
      setEditMode(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="spinner mb-4"></div>
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    );
  }

  if (!employe || !formData) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <p className="text-red-600">Employé non trouvé</p>
          <button 
            onClick={() => navigate('/admin/dashboard')}
            className="btn btn-primary mt-4"
          >
            Retour au dashboard
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate('/admin/dashboard')}
              className="btn btn-secondary flex items-center space-x-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour</span>
            </button>
            <h1 className="text-2xl font-bold">
              {editMode ? 'Modifier l\'employé' : 'Détails de l\'employé'}
            </h1>
          </div>
          <div className="flex space-x-2">
            {editMode ? (
              <>
                <button
                  onClick={handleSave}
                  className="btn btn-success flex items-center space-x-2"
                >
                  <Save className="h-4 w-4" />
                  <span>Sauvegarder</span>
                </button>
                <button
                  onClick={handleCancel}
                  className="btn btn-danger flex items-center space-x-2"
                >
                  <X className="h-4 w-4" />
                  <span>Annuler</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => setEditMode(true)}
                className="btn btn-primary flex items-center space-x-2"
              >
                <Edit2 className="h-4 w-4" />
                <span>Modifier</span>
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-2xl font-bold">
                  {employe.prenom[0]}{employe.nom[0]}
                </div>
                <div>
                  <h2 className="text-xl font-bold">{employe.prenom} {employe.nom}</h2>
                  <p className="text-gray-600">{employe.poste}</p>
                  <span className={`badge ${employe.statut === 'actif' ? 'badge-success' : 'badge-danger'}`}>
                    {employe.statut === 'actif' ? 'Actif' : 'Inactif'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <User className="inline h-4 w-4 mr-1" />
                      Prénom
                    </label>
                    {editMode ? (
                      <input
                        type="text"
                        value={formData.prenom}
                        onChange={(e) => handleInputChange('prenom', e.target.value)}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{employe.prenom}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <Mail className="inline h-4 w-4 mr-1" />
                      Email
                    </label>
                    {editMode ? (
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{employe.email}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <Briefcase className="inline h-4 w-4 mr-1" />
                      Département
                    </label>
                    {editMode ? (
                      <select
                        value={formData.departement}
                        onChange={(e) => handleInputChange('departement', e.target.value)}
                        className="input"
                      >
                        <option value="IT">IT</option>
                        <option value="RH">RH</option>
                        <option value="Finance">Finance</option>
                        <option value="Marketing">Marketing</option>
                      </select>
                    ) : (
                      <p className="text-gray-900">{employe.departement}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <Calendar className="inline h-4 w-4 mr-1" />
                      Date d'embauche
                    </label>
                    {editMode ? (
                      <input
                        type="date"
                        value={formData.date_embauche}
                        onChange={(e) => handleInputChange('date_embauche', e.target.value)}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">
                        {new Date(employe.date_embauche).toLocaleDateString('fr-FR')}
                      </p>
                    )}
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nom</label>
                    {editMode ? (
                      <input
                        type="text"
                        value={formData.nom}
                        onChange={(e) => handleInputChange('nom', e.target.value)}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{employe.nom}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <Phone className="inline h-4 w-4 mr-1" />
                      Téléphone
                    </label>
                    {editMode ? (
                      <input
                        type="tel"
                        value={formData.telephone}
                        onChange={(e) => handleInputChange('telephone', e.target.value)}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{employe.telephone}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Poste</label>
                    {editMode ? (
                      <input
                        type="text"
                        value={formData.poste}
                        onChange={(e) => handleInputChange('poste', e.target.value)}
                        className="input"
                      />
                    ) : (
                      <p className="text-gray-900">{employe.poste}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Statut</label>
                    {editMode ? (
                      <select
                        value={formData.statut}
                        onChange={(e) => handleInputChange('statut', e.target.value as 'actif' | 'inactif')}
                        className="input"
                      >
                        <option value="actif">Actif</option>
                        <option value="inactif">Inactif</option>
                      </select>
                    ) : (
                      <span className={`badge ${employe.statut === 'actif' ? 'badge-success' : 'badge-danger'}`}>
                        {employe.statut === 'actif' ? 'Actif' : 'Inactif'}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <MapPin className="inline h-4 w-4 mr-1" />
                  Adresse
                </label>
                {editMode ? (
                  <textarea
                    value={formData.adresse}
                    onChange={(e) => handleInputChange('adresse', e.target.value)}
                    className="input"
                    rows={3}
                  />
                ) : (
                  <p className="text-gray-900">{employe.adresse}</p>
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-bold mb-4">Actions rapides</h3>
              <div className="space-y-2">
                <button className="btn btn-primary w-full text-left">Voir les pointages</button>
                <button className="btn btn-secondary w-full text-left">Voir les demandes</button>
                <button className="btn btn-secondary w-full text-left">Exporter les données</button>
                <button className="btn btn-danger w-full text-left">Désactiver le compte</button>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
              <h3 className="text-lg font-bold mb-4">Statistiques</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Jours travaillés</span>
                  <span className="font-semibold">142</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Retards</span>
                  <span className="font-semibold text-orange-600">3</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Absences</span>
                  <span className="font-semibold text-red-600">2</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Taux de présence</span>
                  <span className="font-semibold text-green-600">96.5%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeDetailPage;
