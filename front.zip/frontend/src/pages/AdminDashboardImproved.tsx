import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../services/authService';
import LayoutFix from '../components/LayoutFix';
import EmployeTable from '../components/admin/EmployeTable';
import Icon from '../components/Icons';
import { apiClient } from '../services/apiClient';

interface Employe {
  id: number;
  nom: string;
  prenom: string;
  email: string;
  role: string;
  departement: string;
  poste: string;
  telephone?: string;
  statut: string;
  date_embauche: string;
}

interface StatCard {
  title: string;
  value: string | number;
  icon: string;
  color: 'blue' | 'green' | 'yellow' | 'red';
  change?: number;
  changeType?: 'increase' | 'decrease';
}

export default function AdminDashboardImproved() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [employes, setEmployes] = useState<Employe[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [filterStatut, setFilterStatut] = useState('all');

  useEffect(() => {
    if (!user || !['admin', 'super_admin', 'manager', 'hr'].includes(user.role)) {
      navigate('/login');
      return;
    }
    loadEmployes();
  }, [user, navigate]);

  const loadEmployes = async () => {
    try {
      setLoading(true);
      const data = await apiClient.get<any[]>('/employes');
      const mapped: Employe[] = (Array.isArray(data) ? data : []).map((e: any) => ({
        id: Number(e.id) || 0,
        nom: e.nom || '',
        prenom: e.prenom || '',
        email: e.email || '',
        role: e.role || 'employe',
        departement: e.departement || '',
        poste: e.poste || '',
        telephone: e.telephone || undefined,
        statut: e.statut || 'actif',
        date_embauche: e.date_embauche || e.created_at || new Date().toISOString()
      }));
      setEmployes(mapped);
    } catch (error) {
      console.error('Erreur lors du chargement des employés:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredEmployes = employes.filter(employe => {
    const matchesSearch = 
      employe.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employe.prenom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employe.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employe.departement.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employe.poste.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRole = filterRole === 'all' || employe.role === filterRole;
    const matchesStatut = filterStatut === 'all' || employe.statut === filterStatut;

    return matchesSearch && matchesRole && matchesStatut;
  });

  const stats: StatCard[] = [
    {
      title: 'Total Employés',
      value: employes.length,
      icon: 'users',
      color: 'blue'
    },
    {
      title: 'Employés Actifs',
      value: employes.filter(e => e.statut === 'actif').length,
      icon: 'check',
      color: 'green'
    },
    {
      title: 'Nouveaux ce mois',
      value: 2,
      icon: 'chart-line',
      color: 'yellow',
      change: 15,
      changeType: 'increase'
    },
    {
      title: 'Départs ce mois',
      value: 1,
      icon: 'chart-bar',
      color: 'red',
      change: 5,
      changeType: 'decrease'
    }
  ];

  const handleAddEmploye = () => {
    // Naviguer vers la page d'ajout d'employé
    navigate('/admin/employees/new');
  };

  if (loading) {
    return (
      <LayoutFix title="Tableau de Bord Admin">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </LayoutFix>
    );
  }

  return (
    <LayoutFix title="Tableau de Bord Admin">
      <div className="max-w-7xl mx-auto">
        {/* Statistiques */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat: StatCard, index: number) => (
            <div key={index} className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  {stat.change && (
                    <p className={`text-sm mt-1 ${
                      stat.changeType === 'increase' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {stat.changeType === 'increase' ? '+' : '-'}{stat.change}%
                    </p>
                  )}
                </div>
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  stat.color === 'blue' ? 'bg-blue-100' :
                  stat.color === 'green' ? 'bg-green-100' :
                  stat.color === 'yellow' ? 'bg-yellow-100' : 'bg-red-100'
                }`}>
                  <Icon name={stat.icon} className={`w-6 h-6 ${
                    stat.color === 'blue' ? 'text-blue-600' :
                    stat.color === 'green' ? 'text-green-600' :
                    stat.color === 'yellow' ? 'text-yellow-600' : 'text-red-600'
                  }`} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Filtres et recherche */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <div className="flex-1 max-w-lg">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rechercher
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Rechercher par nom, email, département ou poste..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </div>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rôle
              </label>
              <select
                value={filterRole}
                onChange={(e) => setFilterRole(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Tous les rôles</option>
                <option value="admin">Administrateurs</option>
                <option value="employe">Employés</option>
                <option value="manager">Managers</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Statut
              </label>
              <select
                value={filterStatut}
                onChange={(e) => setFilterStatut(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Tous les statuts</option>
                <option value="actif">Actifs</option>
                <option value="inactif">Inactifs</option>
                <option value="suspendu">Suspendus</option>
              </select>
            </div>
          </div>
        </div>

        {/* Tableau des employés */}
        <div className="bg-white rounded-lg shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">
              Liste des Employés ({filteredEmployes.length})
            </h2>
            <p className="text-sm text-gray-600 mt-1">
              Cliquez sur une ligne pour voir les détails de l'employé
            </p>
          </div>
          <EmployeTable employes={filteredEmployes} loading={loading} />
        </div>
      </div>
    </LayoutFix>
  );
}
