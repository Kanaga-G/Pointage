// Page de gestion des badges pour l'admin
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../services/authService';
import { dataService } from '../../services/dataService';
import LayoutFix from '../../components/LayoutFix';

// Types pour les badges
interface Badge {
  id: number;
  token: string;
  token_hash: string;
  user_id: number;
  user_name: string;
  user_email: string;
  user_role: string;
  created_at: string;
  expires_at: string;
  status: 'active' | 'inactive' | 'expired';
  last_used?: string;
  usage_count: number;
}

interface User {
  id: number;
  nom: string;
  prenom: string;
  email: string;
  role: string;
  departement?: string;
  poste?: string;
  statut: string;
}

export default function BadgeManagementPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [badges, setBadges] = useState<Badge[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const [selectedBadge, setSelectedBadge] = useState<number | null>(null);
  const [regenerating, setRegenerating] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    
    // Vérifier si l'utilisateur est admin
    if (user.role !== 'admin' && user.role !== 'super_admin') {
      navigate('/dashboard');
      return;
    }
    
    loadData();
  }, [user, navigate]);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Charger les vraies données depuis la base de données
      const [badgesData, usersData] = await Promise.all([
        dataService.getBadges(),
        dataService.getEmployes()
      ]);
      
      setBadges(badgesData);
      setUsers(usersData);
      
    } catch (err) {
      console.error('Erreur lors du chargement:', err);
      setError('Erreur lors du chargement des données');
    } finally {
      setLoading(false);
    }
  };

  const handleRegenerateBadge = async (badgeId: number) => {
    try {
      setRegenerating(true);
      setError(null);
      setSuccess(null);
      
      const updatedBadge = await dataService.regenerateBadge(badgeId);
      setBadges(prev => prev.map(badge => 
        badge.id === badgeId ? updatedBadge : badge
      ));
      setSuccess('Badge régénéré avec succès');
      
    } catch (err) {
      console.error('Erreur lors de la régénération:', err);
      setError('Erreur lors de la régénération du badge');
    } finally {
      setRegenerating(false);
    }
  };

  const handleRegenerateAllBadges = async () => {
    try {
      setRegenerating(true);
      setError(null);
      setSuccess(null);
      
      const updatedBadges = await dataService.regenerateAllBadges();
      setBadges(updatedBadges);
      setSuccess('Tous les badges ont été régénérés avec succès');
      
    } catch (err) {
      console.error('Erreur lors de la régénération:', err);
      setError('Erreur lors de la régénération des badges');
    } finally {
      setRegenerating(false);
    }
  };

  const handleUpdateStatus = async (badgeId: number, newStatus: 'active' | 'inactive') => {
    try {
      setUpdatingStatus(true);
      setError(null);
      setSuccess(null);
      
      const updatedBadge = await dataService.updateBadgeStatus(badgeId, newStatus);
      setBadges(prev => prev.map(badge => 
        badge.id === badgeId ? updatedBadge : badge
      ));
      setSuccess(`Statut du badge mis à jour: ${newStatus === 'active' ? 'Actif' : 'Inactif'}`);
      
    } catch (err) {
      console.error('Erreur lors de la mise à jour:', err);
      setError('Erreur lors de la mise à jour du statut');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleRegenerateForUser = async (userId: number) => {
    try {
      setRegenerating(true);
      setError(null);
      setSuccess(null);
      
      // Trouver le badge de l'utilisateur et le régénérer
      const userBadge = badges.find(badge => badge.user_id === userId);
      if (userBadge) {
        const updatedBadge = await dataService.regenerateBadge(userBadge.id);
        setBadges(prev => prev.map(badge => 
          badge.id === userBadge.id ? updatedBadge : badge
        ));
        
        const user = users.find(u => u.id === userId);
        setSuccess(`Badge régénéré pour ${user?.prenom} ${user?.nom}`);
      } else {
        setError('Aucun badge trouvé pour cet utilisateur');
      }
      
    } catch (err) {
      console.error('Erreur lors de la régénération:', err);
      setError('Erreur lors de la régénération du badge');
    } finally {
      setRegenerating(false);
    }
  };

  const filteredBadges = badges.filter(badge => {
    const matchesSearch = badge.user_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           badge.user_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           badge.token.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || badge.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const paginatedBadges = filteredBadges.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredBadges.length / itemsPerPage);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'inactive':
        return 'bg-red-100 text-red-800';
      case 'expired':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active':
        return 'Actif';
      case 'inactive':
        return 'Inactif';
      case 'expired':
        return 'Expiré';
      default:
        return 'Inconnu';
    }
  };

  if (loading) {
    return (
      <LayoutFix title="Gestion des Badges">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </LayoutFix>
    );
  }

  return (
    <LayoutFix title="Gestion des Badges">
      <div className="max-w-7xl mx-auto">
        {/* En-tête */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Gestion des Badges</h1>
              <p className="text-gray-600 mt-2">
                Gérez les badges de pointage de tous les utilisateurs
              </p>
            </div>
            
            {/* Actions globales */}
            <div className="flex gap-4">
              <button
                onClick={handleRegenerateAllBadges}
                disabled={regenerating}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center gap-2"
              >
                {regenerating ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    Régénération...
                  </>
                ) : (
                  <>
                    <i className="fas fa-sync-alt"></i>
                    Régénérer tous les badges
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Messages */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}
        
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
            {success}
          </div>
        )}

        {/* Filtres et recherche */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Recherche */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Recherche
              </label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Rechercher par nom, email ou token..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            {/* Filtre par statut */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Statut
              </label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">Tous les statuts</option>
                <option value="active">Actifs</option>
                <option value="inactive">Inactifs</option>
                <option value="expired">Expirés</option>
              </select>
            </div>
            
            {/* Filtre par utilisateur */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Utilisateur
              </label>
              <select
                value={selectedUser || ''}
                onChange={(e) => setSelectedUser(e.target.value ? parseInt(e.target.value) : null)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Tous les utilisateurs</option>
                {users.map(user => (
                  <option key={user.id} value={user.id}>
                    {user.prenom} {user.nom} ({user.email})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Tableau des badges */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Token
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Utilisateur
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Rôle
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Statut
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Utilisations
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Créé le
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Expire le
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {paginatedBadges.map((badge) => (
                  <tr key={badge.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-mono text-gray-900">
                        {badge.token}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm">
                        <div className="font-medium text-gray-900">{badge.user_name}</div>
                        <div className="text-gray-500">{badge.user_email}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                        {badge.user_role}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(badge.status)}`}>
                        {getStatusText(badge.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {badge.usage_count}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(badge.created_at).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(badge.expires_at).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleRegenerateBadge(badge.id)}
                          disabled={regenerating}
                          className="text-blue-600 hover:text-blue-900 disabled:opacity-50"
                          title="Régénérer ce badge"
                        >
                          <i className="fas fa-sync-alt"></i>
                        </button>
                        
                        {badge.status === 'active' ? (
                          <button
                            onClick={() => handleUpdateStatus(badge.id, 'inactive')}
                            disabled={updatingStatus}
                            className="text-red-600 hover:text-red-900 disabled:opacity-50"
                            title="Désactiver ce badge"
                          >
                            <i className="fas fa-ban"></i>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleUpdateStatus(badge.id, 'active')}
                            disabled={updatingStatus}
                            className="text-green-600 hover:text-green-900 disabled:opacity-50"
                            title="Activer ce badge"
                          >
                            <i className="fas fa-check"></i>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
            <div className="flex justify-between items-center">
              <div className="text-sm text-gray-700">
                Affichage de {((currentPage - 1) * itemsPerPage) + 1} à {Math.min(currentPage * itemsPerPage, filteredBadges.length)} sur {filteredBadges.length} badges
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1 text-sm bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50"
                >
                  Précédent
                </button>
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className="px-3 py-1 text-sm bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50"
                >
                  Suivant
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Actions rapides */}
        <div className="bg-white rounded-lg shadow-sm p-6 mt-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Actions rapides</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button
              onClick={handleRegenerateAllBadges}
              disabled={regenerating}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <i className="fas fa-sync-alt"></i>
              Régénérer tous les badges
            </button>
            
            <button
              onClick={() => {
                const activeBadges = badges.filter(b => b.status === 'active');
                if (window.confirm(`Êtes-vous sûr de vouloir désactiver les ${activeBadges.length} badges actifs ?`)) {
                  activeBadges.forEach(badge => {
                    handleUpdateStatus(badge.id, 'inactive');
                  });
                }
              }}
              disabled={updatingStatus}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <i className="fas fa-ban"></i>
              Désactiver tous les badges actifs
            </button>
          </div>
        </div>
      </div>
    </LayoutFix>
  );
}
