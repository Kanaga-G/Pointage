import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../services/authService';
import LayoutFix from '../../components/LayoutFix';
import { apiClient } from '../../services/apiClient';
import { IdentifierGenerator } from '../../services/identifierGenerator';
import '../../styles/identifiers-ultra.css';

interface NewEmploye {
  id?: number;
  matricule?: string;
  nom: string;
  prenom: string;
  email: string;
  role: string;
  departement: string;
  poste: string;
  telephone?: string;
  adresse?: string;
  date_embauche: string;
  statut: string;
  contact_urgence_nom?: string;
  contact_urgence_telephone?: string;
  contact_urgence_relation?: string;
}

export default function EmployeNewPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState<NewEmploye>({
    nom: '',
    prenom: '',
    email: '',
    role: 'employe',
    departement: '',
    poste: '',
    telephone: '',
    adresse: '',
    date_embauche: new Date().toISOString().split('T')[0],
    statut: 'actif',
    contact_urgence_nom: '',
    contact_urgence_telephone: '',
    contact_urgence_relation: ''
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [generatedIds, setGeneratedIds] = useState<{ id: number; matricule: string } | null>(null);

  // Générer automatiquement ID et matricule quand le rôle change
  useEffect(() => {
    const identifiers = IdentifierGenerator.generateIdentifiers(formData.role);
    setGeneratedIds(identifiers);
    setFormData(prev => ({
      ...prev,
      id: identifiers.id,
      matricule: identifiers.matricule
    }));
  }, [formData.role]);

  useEffect(() => {
    if (!user || !['admin', 'super_admin', 'manager', 'hr'].includes(user.role)) {
      navigate('/admin');
      return;
    }
    
    // Générer les identifiants initiaux
    const identifiers = IdentifierGenerator.generateIdentifiers(formData.role);
    setGeneratedIds(identifiers);
    setFormData(prev => ({
      ...prev,
      id: identifiers.id,
      matricule: identifiers.matricule
    }));
  }, [user, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);
      
      // Validation basique
      if (!formData.nom || !formData.prenom || !formData.email) {
        setError('Les champs nom, prénom et email sont obligatoires');
        return;
      }
      
      const res = await apiClient.post<NewEmploye, { success: boolean; employe?: any; message?: string }>('/employes', formData);
      if (!res?.success) {
        throw new Error(res?.message || 'Erreur lors de la création de l\'employé');
      }

      setSuccess('Employé créé avec succès');
      navigate('/admin');
      
    } catch (err) {
      console.error('Erreur lors de la création:', err);
      setError('Erreur lors de la création de l\'employé');
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    navigate('/admin');
  };

  return (
    <LayoutFix title="Nouvel Employé">
      <div className="max-w-4xl mx-auto">
        {/* En-tête */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Ajouter un nouvel employé
              </h1>
              <p className="text-gray-600">
                Remplissez les informations ci-dessous pour créer un nouvel employé
              </p>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={handleCancel}
                className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {saving ? 'Création...' : 'Créer l\'employé'}
              </button>
            </div>
          </div>
        </div>

        {/* Messages */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
            {success}
          </div>
        )}

        {/* Informations de base */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Informations de base</h3>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-600">Génération automatique</span>
            </div>
          </div>
          
          {/* Section des identifiants améliorée */}
          <div className="identifiers-container">
            <div className="particles">
              <div className="particle"></div>
              <div className="particle"></div>
              <div className="particle"></div>
              <div className="particle"></div>
              <div className="particle"></div>
            </div>
            <div className="identifiers-grid">
              <div className="identifier-card id-card">
                <div className="identifier-label">
                  ID (généré automatiquement)
                </div>
                <div className="identifier-value-container">
                  <div className="identifier-value">
                    {generatedIds?.id || '---'}
                  </div>
                </div>
                <p className="identifier-description">ID unique généré par le système</p>
              </div>
              
              <div className="identifier-card matricule-card">
                <div className="identifier-label">
                  Matricule (généré automatiquement)
                </div>
                <div className="identifier-value-container">
                  <div className="identifier-value">
                    {generatedIds?.matricule || '---'}
                  </div>
                </div>
                <p className="identifier-description">Matricule selon le rôle et la date</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nom *
              </label>
              <input
                type="text"
                name="nom"
                value={formData.nom}
                onChange={handleInputChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Dupont"
              />
              <p className="text-xs text-gray-500 mt-1">Obligatoire</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Prénom *
              </label>
              <input
                type="text"
                name="prenom"
                value={formData.prenom}
                onChange={handleInputChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Jean"
              />
              <p className="text-xs text-gray-500 mt-1">Obligatoire</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email professionnel *
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="jean.dupont@xpertpro.com"
              />
              <p className="text-xs text-gray-500 mt-1">Obligatoire - Sera utilisé pour la connexion</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Rôle
              </label>
              <select
                name="role"
                value={formData.role}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="employe">Employé</option>
                <option value="manager">Manager</option>
                <option value="hr">Ressources Humaines</option>
                <option value="admin">Administrateur</option>
              </select>
              <p className="text-xs text-gray-500 mt-1">Détermine les permissions de l'utilisateur</p>
            </div>
          </div>
        </div>

        {/* Informations professionnelles */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations professionnelles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Département
              </label>
              <input
                type="text"
                name="departement"
                value={formData.departement}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="IT, RH, Ventes..."
              />
              <p className="text-xs text-gray-500 mt-1">Département de rattachement</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Poste
              </label>
              <input
                type="text"
                name="poste"
                value={formData.poste}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Développeur, Manager..."
              />
              <p className="text-xs text-gray-500 mt-1">Intitulé du poste</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date d'embauche
              </label>
              <input
                type="date"
                name="date_embauche"
                value={formData.date_embauche}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Date de début du contrat</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Statut
              </label>
              <select
                name="statut"
                value={formData.statut}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="actif">Actif</option>
                <option value="inactif">Inactif</option>
                <option value="suspendu">Suspendu</option>
              </select>
              <p className="text-xs text-gray-500 mt-1">Statut initial de l'employé</p>
            </div>
          </div>
        </div>

        {/* Informations personnelles */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations personnelles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Téléphone
              </label>
              <input
                type="tel"
                name="telephone"
                value={formData.telephone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="0612345678"
              />
              <p className="text-xs text-gray-500 mt-1">Numéro de téléphone personnel</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Adresse
              </label>
              <textarea
                name="adresse"
                value={formData.adresse}
                onChange={handleInputChange}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="123 Rue de la Tech, 75001 Paris"
              />
              <p className="text-xs text-gray-500 mt-1">Adresse postale</p>
            </div>
          </div>
        </div>

        {/* Contact d'urgence */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact d'urgence</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nom du contact
              </label>
              <input
                type="text"
                name="contact_urgence_nom"
                value={formData.contact_urgence_nom}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Marie Dupont"
              />
              <p className="text-xs text-gray-500 mt-1">Personne à contacter en cas d'urgence</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Téléphone du contact
              </label>
              <input
                type="tel"
                name="contact_urgence_telephone"
                value={formData.contact_urgence_telephone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="0987654321"
              />
              <p className="text-xs text-gray-500 mt-1">Numéro d'urgence</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Relation
              </label>
              <input
                type="text"
                name="contact_urgence_relation"
                value={formData.contact_urgence_relation}
                onChange={handleInputChange}
                placeholder="Ex: Conjoint, Frère, Mère..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Lien avec l'employé</p>
            </div>
          </div>
        </div>

        {/* Boutons d'action */}
        <div className="flex justify-end space-x-4">
          <button
            onClick={handleCancel}
            disabled={saving}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            Annuler
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {saving ? 'Création...' : 'Créer l\'employé'}
          </button>
        </div>
      </div>
    </LayoutFix>
  );
}
