import React, { useEffect, useState } from "react";
import { adminService } from "@services/adminService";
import { apiClient } from "../../services/apiClient";
import './AdminDashboard.module.css';
import DeviceDisplay from '../../components/DeviceDisplay';

type PanelId = "pointage" | "heures" | "demandes" | "employes" | "admins" | "retards" | "calendrier" | "device";

// ============================================
// TYPES & INTERFACES
// ============================================

interface AdminDashboardStats {
  totalEmployes: number;
  presents: number;
  absents: number;
  retards: number;
}

interface PointageEntry {
  id: number;
  employe_id: number;
  prenom: string;
  nom: string;
  departement: string;
  date: string;
  arrivee: string | null;
  depart: string | null;
  photo?: string;
}

interface TempsTotal {
  id: number;
  prenom: string;
  nom: string;
  email: string;
  departement: string;
  total_travail: string;
  photo?: string;
}

interface Demande {
  id: number;
  prenom: string;
  nom: string;
  poste: string;
  departement: string;
  type: string;
  date_demande: string;
  statut: "en_attente" | "approuve" | "rejete";
  heures_ecoulees?: number;
  photo?: string;
}

interface DemandeStats {
  total: number;
  en_attente: number;
  approuve: number;
  rejete: number;
}

interface Employe {
  id: number;
  prenom: string;
  nom: string;
  email: string;
  telephone?: string;
  poste: string;
  departement: string;
  statut: string;
  date_embauche?: string;
  contrat_type?: string;
  contrat_duree?: string;
  salaire?: number;
  adresse?: string;
  photo?: string;
}

interface Admin {
  id: number;
  prenom: string;
  nom: string;
  email: string;
  telephone?: string;
  role: string;
  adresse?: string;
  last_activity?: string;
  status?: string;
  photo?: string;
}

interface Retard {
  id: number;
  employe_id: number;
  prenom: string;
  nom: string;
  departement: string;
  date_heure: string;
  retard_minutes: number;
  statut?: string;
  retard_raison?: string;
  est_justifie?: boolean;
}

// ============================================
// COMPOSANT PRINCIPAL
// ============================================

export const AdminDashboard: React.FC = () => {
  const [activePanel, setActivePanel] = useState<PanelId>("device");
  const [stats, setStats] = useState<AdminDashboardStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deviceType, setDeviceType] = useState<'mobile' | 'tablet' | 'desktop' | 'auto'>('auto');

  // Panel Pointage
  const [pointages, setPointages] = useState<PointageEntry[]>([]);
  const [dateFilter, setDateFilter] = useState<string>(new Date().toISOString().split("T")[0]);
  const [departementFilter, setDepartementFilter] = useState<string>("");
  const [departements, setDepartements] = useState<string[]>([]);
  const [pagePointage, setPagePointage] = useState(1);
  const [totalPagesPointage, setTotalPagesPointage] = useState(1);

  // Panel Heures
  const [tempsTotaux, setTempsTotaux] = useState<TempsTotal[]>([]);
  const [monthFilter, setMonthFilter] = useState<string>(new Date().toISOString().slice(0, 7));
  const [pageHeures, setPageHeures] = useState(1);
  const [totalPagesHeures, setTotalPagesHeures] = useState(1);

  // Panel Demandes
  const [demandes, setDemandes] = useState<Demande[]>([]);
  const [demandeStats, setDemandeStats] = useState<DemandeStats>({ total: 0, en_attente: 0, approuve: 0, rejete: 0 });
  const [pageDemandes, setPageDemandes] = useState(1);
  const [totalPagesDemandes, setTotalPagesDemandes] = useState(1);

  // Panel Employés
  const [employes, setEmployes] = useState<Employe[]>([]);
  const [searchEmploye, setSearchEmploye] = useState("");
  const [pageEmployes, setPageEmployes] = useState(1);
  const [totalPagesEmployes, setTotalPagesEmployes] = useState(1);

  // Panel Admins
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [searchAdmin, setSearchAdmin] = useState("");
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  // Panel Retards
  const [retards, setRetards] = useState<Retard[]>([]);
  const [dateRetard, setDateRetard] = useState<string>(new Date().toISOString().split("T")[0]);
  const [depRetard, setDepRetard] = useState<string>("");
  const [pageRetard, setPageRetard] = useState(1);
  const [totalPagesRetard, setTotalPagesRetard] = useState(1);

  useEffect(() => {
    const saved = window.sessionStorage.getItem("admin.activePanel") as PanelId | null;
    if (saved) setActivePanel(saved);
    void loadStats();
    void loadDepartements();
  }, []);

  useEffect(() => {
    window.sessionStorage.setItem("admin.activePanel", activePanel);
    if (activePanel === "pointage") void loadPointages();
    else if (activePanel === "heures") void loadTempsTotaux();
    else if (activePanel === "demandes") void loadDemandes();
    else if (activePanel === "employes") void loadEmployes();
    else if (activePanel === "admins") void loadAdmins();
    else if (activePanel === "retards") void loadRetards();
  }, [activePanel]);

  useEffect(() => {
    void loadPointages();
  }, [dateFilter, departementFilter, pagePointage]);

  useEffect(() => {
    void loadTempsTotaux();
  }, [monthFilter, pageHeures]);

  useEffect(() => {
    void loadDemandes();
  }, [pageDemandes]);

  useEffect(() => {
    void loadRetards();
  }, [dateRetard, depRetard, pageRetard]);

  // ============================================
  // API CALLS
  // ============================================

  async function loadStats() {
    try {
      setLoading(true);
      setError(null);
      const data = await adminService.getTodayStats();
      setStats({
        totalEmployes: data.total_employes ?? 0,
        presents: data.presents ?? 0,
        absents: data.absents ?? 0,
        retards: data.retards ?? 0,
      });
    } catch (error) {
      console.error("Erreur chargement stats:", error);
      setError("Impossible de charger les statistiques");
    } finally {
      setLoading(false);
    }
  }

  async function loadDepartements() {
    try {
      const data = await adminService.getDepartements();
      setDepartements(data || []);
    } catch (error) {
      console.error("Erreur chargement départements:", error);
    }
  }

  async function loadPointages() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (dateFilter) params.append("date", dateFilter);
      if (departementFilter) params.append("departement", departementFilter);
      params.append("page_pointage", pagePointage.toString());
      params.append("per_page", "10");

      const data = await apiClient.get<{
        success: boolean;
        pointages: PointageEntry[];
        total: number;
        total_pages: number;
      }>(`get_pointages?${params.toString()}`);

      if (data.success) {
        setPointages(data.pointages || []);
        setTotalPagesPointage(data.total_pages || 1);
      }
    } catch (error) {
      console.error("Erreur chargement pointages:", error);
      setPointages([]);
    } finally {
      setLoading(false);
    }
  }

  async function loadTempsTotaux() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.append("month", monthFilter);
      params.append("page_heures", pageHeures.toString());
      params.append("per_page", "10");

      const data = await apiClient.get<{
        success: boolean;
        items: TempsTotal[];
        total: number;
        total_pages: number;
      }>(`get_temps_totaux?${params.toString()}`);

      if (data.success) {
        setTempsTotaux(data.items || []);
        setTotalPagesHeures(data.total_pages || 1);
      }
    } catch (error) {
      console.error("Erreur chargement temps totaux:", error);
      setTempsTotaux([]);
    } finally {
      setLoading(false);
    }
  }

  async function loadDemandes() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.append("page_demandes", pageDemandes.toString());
      params.append("per_page", "10");

      const data = await apiClient.get<{
        success: boolean;
        demandes: Demande[];
        stats: DemandeStats;
        total: number;
        total_pages: number;
      }>(`get_demandes?${params.toString()}`);

      if (data.success) {
        setDemandes(data.demandes || []);
        setDemandeStats(data.stats || { total: 0, en_attente: 0, approuve: 0, rejete: 0 });
        setTotalPagesDemandes(data.total_pages || 1);
      }
    } catch (error) {
      console.error("Erreur chargement demandes:", error);
      setDemandes([]);
    } finally {
      setLoading(false);
    }
  }

  async function changeDemandeStatus(id: number, statut: "approuve" | "rejete") {
    if (!confirm("Confirmer la modification du statut ?")) return;
    try {
      await apiClient.post<{ id: number; action: "approuve" | "rejete" }, { success: boolean; message?: string }>(
        "traiter_demande",
        { id, action: statut }
      );
      void loadDemandes();
      void loadStats();
    } catch (error) {
      console.error("Erreur changement statut:", error);
      alert("Impossible de modifier le statut");
    }
  }

  async function loadEmployes() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.append("page", pageEmployes.toString());
      params.append("per_page", "10");

      const data = await apiClient.get<{
        success: boolean;
        employes: Employe[];
        total: number;
        total_pages: number;
      }>(`get_employes?${params.toString()}`);

      if (data.success) {
        setEmployes(data.employes || []);
        setTotalPagesEmployes(data.total_pages || 1);
      }
    } catch (error) {
      console.error("Erreur chargement employés:", error);
      setEmployes([]);
    } finally {
      setLoading(false);
    }
  }

  async function loadAdmins() {
    try {
      setLoading(true);
      const data = await apiClient.get<{
        success: boolean;
        admins: Admin[];
        is_super_admin: boolean;
      }>("get_admins");

      if (data.success) {
        setAdmins(data.admins || []);
        setIsSuperAdmin(data.is_super_admin || false);
      }
    } catch (error) {
      console.error("Erreur chargement admins:", error);
      setAdmins([]);
    } finally {
      setLoading(false);
    }
  }

  async function loadRetards() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (dateRetard) params.append("date_retard", dateRetard);
      if (depRetard) params.append("dep_retard", depRetard);
      params.append("page_retard", pageRetard.toString());
      params.append("per_page", "10");

      const data = await apiClient.get<{
        success: boolean;
        retards: Retard[];
        total: number;
        total_pages: number;
      }>(`get_retards?${params.toString()}`);

      if (data.success) {
        setRetards(data.retards || []);
        setTotalPagesRetard(data.total_pages || 1);
      }
    } catch (error) {
      console.error("Erreur chargement retards:", error);
      setRetards([]);
    } finally {
      setLoading(false);
    }
  }

  // ============================================
  // RENDER
  // ============================================

  return (
    <div className="adminDashboard">
      <div className="pageHeader">
        <div>
          <h1>Dashboard Administrateur</h1>
          <p className="pageSubtitle">
            Vue d&apos;ensemble du système de pointage
          </p>
        </div>
      </div>

      {/* STATS CARDS */}
      <section className="statsSection">
        <div className="statsGrid">
          <StatCard
            label="Total employés"
            value={stats?.totalEmployes ?? 0}
            icon="users"
            color="#4361ee"
            bgColor="rgba(67,97,238,.15)"
          />
          <StatCard
            label="Présents aujourd'hui"
            value={stats?.presents ?? 0}
            icon="user-check"
            color="#4cc9f0"
            bgColor="rgba(76,201,240,.18)"
          />
          <StatCard
            label="Absents aujourd'hui"
            value={stats?.absents ?? 0}
            icon="user-times"
            color="#f8961e"
            bgColor="rgba(248,150,30,.18)"
          />
          <StatCard
            label="Retards du jour"
            value={stats?.retards ?? 0}
            icon="clock"
            color="#f94144"
            bgColor="rgba(249,65,68,.18)"
          />
        </div>
      </section>

      {/* MAIN LAYOUT */}
      <section className="mainLayout">
        {/* SIDEBAR */}
        <aside className="sidebar">
          <nav className="sidebarNav">
            {(["device", "pointage", "heures", "demandes", "employes", "admins", "retards", "calendrier"] as PanelId[]).map(
              (id) => (
                <PanelButton
                  key={id}
                  id={id}
                  label={
                    id === "device"
                      ? "Device View"
                      : id === "pointage"
                        ? "Pointage"
                        : id === "heures"
                          ? "Heures"
                          : id === "demandes"
                            ? "Demandes"
                            : id === "employes"
                              ? "Employés"
                              : id === "admins"
                                ? "Admins"
                                : id === "retards"
                                  ? "Retards"
                                  : "Calendrier"
                  }
                  active={activePanel}
                  onClick={setActivePanel}
                />
              )
            )}
          </nav>
        </aside>

        {/* PANELS */}
        <div className="panelContent">
          {activePanel === "device" && (
            <div className="panel">
              <div className="panelHeader">
                <h2 className="panelTitle">
                  <i className="fas fa-mobile-alt"></i>
                  Vue Device - Pointage Multi-plateforme
                </h2>
                <div className="actionButtons">
                  <select
                    value={deviceType}
                    onChange={(e) => setDeviceType(e.target.value as any)}
                    className="filterSelect deviceSelect"
                  >
                    <option value="auto">Auto</option>
                    <option value="mobile">Mobile</option>
                    <option value="tablet">Tablette</option>
                    <option value="desktop">Desktop</option>
                  </select>
                </div>
              </div>
              <DeviceDisplay
                employeeName="Jean Dupont"
                employeeRole="Développeur"
                status="present"
                arrivalTime="08:30"
                workTime="7h 42m"
                lunchTime="12:15"
                resumeTime="13:00"
                performance="Excellent"
                attendanceRate={95}
                daysWorked={21}
                deviceType={deviceType}
                orientation="auto"
                mockData={{
                  notifications: 3,
                  nextAction: 'Pointer le départ',
                  teamMembers: 12,
                  pendingTasks: 5,
                  recentActivity: [
                    { time: '14:30', action: 'Reprise de pause' },
                    { time: '12:15', action: 'Début pause' },
                    { time: '08:30', action: 'Arrivée au bureau' },
                    { time: '08:25', action: 'Scan badge réussi' }
                  ]
                }}
                onDepartClick={() => alert('Pointer le départ')}
                onPauseClick={() => alert('Demander une pause')}
                onScanClick={() => alert('Scanner QR Code')}
              />
            </div>
          )}
          {activePanel === "pointage" && (
            <PanelPointage
              pointages={pointages}
              loading={loading}
              dateFilter={dateFilter}
              setDateFilter={setDateFilter}
              departementFilter={departementFilter}
              setDepartementFilter={setDepartementFilter}
              departements={departements}
              page={pagePointage}
              setPage={setPagePointage}
              totalPages={totalPagesPointage}
            />
          )}

          {activePanel === "heures" && (
            <PanelHeures
              tempsTotaux={tempsTotaux}
              loading={loading}
              monthFilter={monthFilter}
              setMonthFilter={setMonthFilter}
              page={pageHeures}
              setPage={setPageHeures}
              totalPages={totalPagesHeures}
            />
          )}

          {activePanel === "demandes" && (
            <PanelDemandes
              demandes={demandes}
              stats={demandeStats}
              loading={loading}
              onChangeStatus={changeDemandeStatus}
              page={pageDemandes}
              setPage={setPageDemandes}
              totalPages={totalPagesDemandes}
            />
          )}

          {activePanel === "employes" && (
            <PanelEmployes
              employes={employes}
              loading={loading}
              search={searchEmploye}
              setSearch={setSearchEmploye}
              page={pageEmployes}
              setPage={setPageEmployes}
              totalPages={totalPagesEmployes}
            />
          )}

          {activePanel === "admins" && isSuperAdmin && (
            <PanelAdmins admins={admins} loading={loading} search={searchAdmin} setSearch={setSearchAdmin} />
          )}

          {activePanel === "retards" && (
            <PanelRetards
              retards={retards}
              loading={loading}
              dateFilter={dateRetard}
              setDateFilter={setDateRetard}
              depFilter={depRetard}
              setDepFilter={setDepRetard}
              departements={departements}
              page={pageRetard}
              setPage={setPageRetard}
              totalPages={totalPagesRetard}
            />
          )}

          {activePanel === "calendrier" && <PanelCalendrier />}
        </div>
      </section>
    </div>
  );
};

// ============================================
// COMPOSANTS STATS
// ============================================

interface StatCardProps {
  label: string;
  value: number;
  icon: string;
  color: string;
  bgColor: string;
}

const StatCard: React.FC<StatCardProps> = ({ label, value, icon, color, bgColor }) => {
  return (
    <div className="statCard" style={{ background: bgColor }}>
      <div className="statCardIcon">
        <i className={`fas fa-${icon}`} style={{ color }}></i>
      </div>
      <div className="statCardValue" style={{ color }}>
        {value}
      </div>
      <div className="statCardLabel">
        {label}
      </div>
    </div>
  );
};

interface PanelButtonProps {
  id: PanelId;
  label: string;
  active: PanelId;
  onClick: (id: PanelId) => void;
}

const PanelButton: React.FC<PanelButtonProps> = ({ id, label, active, onClick }) => {
  const isActive = id === active;
  return (
    <button
      type="button"
      onClick={() => onClick(id)}
      className={`panelButton ${isActive ? 'active' : ''}`}
    >
      {label}
    </button>
  );
};

// ============================================
// PANEL POINTAGE
// ============================================

interface PanelPointageProps {
  pointages: PointageEntry[];
  loading: boolean;
  dateFilter: string;
  setDateFilter: (v: string) => void;
  departementFilter: string;
  setDepartementFilter: (v: string) => void;
  departements: string[];
  page: number;
  setPage: (p: number) => void;
  totalPages: number;
}

const PanelPointage: React.FC<PanelPointageProps> = ({
  pointages,
  loading,
  dateFilter,
  setDateFilter,
  departementFilter,
  setDepartementFilter,
  departements,
  page,
  setPage,
  totalPages,
}) => {
  return (
    <div className="panel">
      <header className="panelHeader">
        <h2 className="panelTitle">
          <i className="fas fa-calendar-check"></i>
          Historique des pointages
        </h2>
        <div className="actionButtons">
          <button className="btn btn-danger btn-sm">
            <i className="fas fa-file-pdf" /> PDF
          </button>
          <button className="btn btn-success btn-sm">
            <i className="fas fa-file-excel" /> Excel
          </button>
        </div>
      </header>

      {/* FILTRES */}
      <div className="filtersSection">
        <div className="filterGroup">
          <label className="filterLabel">Date :</label>
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="filterInput"
          />
        </div>
        <div className="filterGroup">
          <label className="filterLabel">Département :</label>
          <select
            value={departementFilter}
            onChange={(e) => setDepartementFilter(e.target.value)}
            className="filterSelect"
          >
            <option value="">Tous les départements</option>
            {departements.map((dep) => (
              <option key={dep} value={dep}>
                {dep.replace("depart_", "").replace(/_/g, " ")}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* TABLE */}
      {loading ? (
        <div className="loadingContainer">
          <div className="loadingSpinner"></div>
          <div>Chargement des pointages…</div>
        </div>
      ) : pointages.length === 0 ? (
        <div className="emptyState">
          <i className="fas fa-calendar-times emptyStateIcon"></i>
          <div className="emptyStateTitle">Aucun pointage trouvé</div>
          <div className="emptyStateMessage">Aucun pointage trouvé pour les filtres sélectionnés.</div>
        </div>
      ) : (
        <>
          <div className="tableContainer">
            <table className="table">
              <thead>
                <tr>
                  <th>Avatar</th>
                  <th>Nom complet</th>
                  <th>Département</th>
                  <th>Date</th>
                  <th>Arrivée</th>
                  <th>Départ</th>
                </tr>
              </thead>
              <tbody>
                {pointages.map((p) => {
                  const initiales = `${p.prenom[0] || ""}${p.nom[0] || ""}`.toUpperCase();
                  const depLabel = p.departement.replace("depart_", "").replace(/_/g, " ");
                  return (
                    <tr key={p.id} onClick={() => window.location.href = `/employe/${p.employe_id}`}>
                      <td>
                        <div className="avatar">
                          {initiales}
                        </div>
                      </td>
                      <td style={{ fontWeight: 600 }}>
                        {p.prenom} {p.nom}
                      </td>
                      <td style={{ textAlign: "center" }}>
                        <span className="badge badgePrimary">
                          {depLabel}
                        </span>
                      </td>
                      <td style={{ textAlign: "center" }}>
                        {p.date ? new Date(p.date).toLocaleDateString("fr-FR") : "—"}
                      </td>
                      <td style={{ textAlign: "center" }}>
                        {p.arrivee ? (
                          <span className="badge badgeSuccess">
                            {p.arrivee}
                          </span>
                        ) : (
                          <span style={{ color: "#6c757d" }}>—</span>
                        )}
                      </td>
                      <td style={{ textAlign: "center" }}>
                        {p.depart ? (
                          <span className="badge badgeDanger">
                            {p.depart}
                          </span>
                        ) : (
                          <span style={{ color: "#6c757d" }}>—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination page={page} setPage={setPage} totalPages={totalPages} />
        </>
      )}
    </div>
  );
};

// ============================================
// PANEL HEURES
// ============================================

interface PanelHeuresProps {
  tempsTotaux: TempsTotal[];
  loading: boolean;
  monthFilter: string;
  setMonthFilter: (v: string) => void;
  page: number;
  setPage: (p: number) => void;
  totalPages: number;
}

const PanelHeures: React.FC<PanelHeuresProps> = ({ tempsTotaux, loading, monthFilter, setMonthFilter, page, setPage, totalPages }) => {
  return (
    <div className="panel" style={{ background: "white", borderRadius: "12px", padding: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem" }}>
        <h2 style={{ margin: 0, fontSize: "1.5rem", fontWeight: 700 }}>
          <i className="fas fa-clock" style={{ marginRight: "0.5rem", color: "#0d6efd" }} />
          Temps total travaillé
        </h2>
        <div>
          <input
            type="month"
            value={monthFilter}
            onChange={(e) => setMonthFilter(e.target.value)}
            style={{ padding: "0.5rem", border: "1px solid #dee2e6", borderRadius: "6px" }}
          />
        </div>
      </header>

      {loading ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>Chargement…</div>
      ) : tempsTotaux.length === 0 ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>Aucune donnée disponible.</div>
      ) : (
        <>
          <div style={{ overflowX: "auto", maxHeight: "70vh", overflowY: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead style={{ background: "#f8f9fa", position: "sticky", top: 0 }}>
                <tr>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Profil</th>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Nom complet</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>Département</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>Temps total</th>
                </tr>
              </thead>
              <tbody>
                {tempsTotaux.map((t) => {
                  const initiales = `${t.prenom[0] || ""}${t.nom[0] || ""}`.toUpperCase();
                  const parts = t.total_travail.split(":");
                  const displayTime = `${parts[0] || "00"}:${parts[1] || "00"}`;
                  return (
                    <tr key={t.id} style={{ borderBottom: "1px solid #dee2e6" }}>
                      <td style={{ padding: "0.75rem" }}>
                        <div
                          style={{
                            width: "48px",
                            height: "48px",
                            borderRadius: "50%",
                            background: "#0d6efd",
                            color: "white",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontWeight: 600,
                          }}
                        >
                          {initiales}
                        </div>
                      </td>
                      <td style={{ padding: "0.75rem", fontWeight: 600 }}>
                        {t.prenom} {t.nom}
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        <span style={{ background: "#0d6efd", color: "white", padding: "0.25rem 0.75rem", borderRadius: "12px", fontSize: "0.875rem" }}>
                          {t.departement.replace("depart_", "").replace(/_/g, " ")}
                        </span>
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        <span style={{ background: "#212529", color: "white", padding: "0.5rem 1rem", borderRadius: "12px", fontWeight: 600 }}>
                          {displayTime}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination page={page} setPage={setPage} totalPages={totalPages} />
        </>
      )}
    </div>
  );
};

// ============================================
// PANEL DEMANDES
// ============================================

interface PanelDemandesProps {
  demandes: Demande[];
  stats: DemandeStats;
  loading: boolean;
  onChangeStatus: (id: number, statut: "approuve" | "rejete") => void;
  page: number;
  setPage: (p: number) => void;
  totalPages: number;
}

const PanelDemandes: React.FC<PanelDemandesProps> = ({ demandes, stats, loading, onChangeStatus, page, setPage, totalPages }) => {
  return (
    <div className="panel" style={{ background: "white", borderRadius: "12px", padding: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
      <header style={{ marginBottom: "1.5rem" }}>
        <h2 style={{ margin: 0, fontSize: "1.5rem", fontWeight: 700 }}>
          <i className="fas fa-tasks" style={{ marginRight: "0.5rem", color: "#0d6efd" }} />
          Gestion des demandes
        </h2>
      </header>

      {/* STATS */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1rem", marginBottom: "2rem" }}>
        <StatCard label="Total demandes" value={stats.total} icon="list-alt" color="#0d6efd" bgColor="rgba(13,110,253,.1)" />
        <StatCard label="En attente" value={stats.en_attente} icon="clock" color="#ffc107" bgColor="rgba(255,193,7,.1)" />
        <StatCard label="Approuvées" value={stats.approuve} icon="check-circle" color="#198754" bgColor="rgba(25,135,84,.1)" />
        <StatCard label="Rejetées" value={stats.rejete} icon="times-circle" color="#dc3545" bgColor="rgba(220,53,69,.1)" />
      </div>

      {/* TABLE */}
      {loading ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>Chargement…</div>
      ) : demandes.length === 0 ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>
          <i className="fas fa-inbox" style={{ fontSize: "3rem", marginBottom: "1rem", opacity: 0.5 }} />
          <p>Aucune demande trouvée.</p>
        </div>
      ) : (
        <>
          <div style={{ overflowX: "auto", maxHeight: "60vh", overflowY: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead style={{ background: "#f8f9fa", position: "sticky", top: 0 }}>
                <tr>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Employé</th>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Type</th>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Date</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>Statut</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {demandes.map((d) => {
                  const initiales = `${d.prenom[0] || ""}${d.nom[0] || ""}`.toUpperCase();
                  const isUrgent = d.statut === "en_attente" && (d.heures_ecoulees || 0) < 24;
                  const badgeClass =
                    d.statut === "approuve" ? "success" : d.statut === "rejete" ? "danger" : "warning";
                  return (
                    <tr
                      key={d.id}
                      style={{
                        borderBottom: "1px solid #dee2e6",
                        background: isUrgent ? "rgba(220,53,69,0.05)" : "transparent",
                      }}
                    >
                      <td style={{ padding: "0.75rem" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
                          <div
                            style={{
                              width: "45px",
                              height: "45px",
                              borderRadius: "50%",
                              background: "#6c757d",
                              color: "white",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              fontWeight: 600,
                            }}
                          >
                            {initiales}
                          </div>
                          <div>
                            <div style={{ fontWeight: 600 }}>{d.prenom} {d.nom}</div>
                            <small style={{ color: "#6c757d" }}>{d.poste} • {d.departement.replace("depart_", "")}</small>
                          </div>
                        </div>
                      </td>
                      <td style={{ padding: "0.75rem" }}>
                        <span style={{ background: "#0d6efd", color: "white", padding: "0.25rem 0.75rem", borderRadius: "12px", fontSize: "0.875rem" }}>
                          {d.type}
                        </span>
                      </td>
                      <td style={{ padding: "0.75rem" }}>
                        {new Date(d.date_demande).toLocaleString("fr-FR")}
                        {isUrgent && (
                          <span style={{ marginLeft: "0.5rem", background: "#dc3545", color: "white", padding: "0.125rem 0.5rem", borderRadius: "8px", fontSize: "0.75rem" }}>
                            URGENT
                          </span>
                        )}
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        <span
                          style={{
                            background:
                              badgeClass === "success" ? "#198754" : badgeClass === "danger" ? "#dc3545" : "#ffc107",
                            color: badgeClass === "warning" ? "#000" : "white",
                            padding: "0.5rem 1rem",
                            borderRadius: "12px",
                            fontWeight: 600,
                          }}
                        >
                          {d.statut.charAt(0).toUpperCase() + d.statut.slice(1)}
                        </span>
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        <div style={{ display: "flex", gap: "0.5rem", justifyContent: "center" }}>
                          {d.statut !== "approuve" && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onChangeStatus(d.id, "approuve");
                              }}
                              style={{
                                background: "#198754",
                                color: "white",
                                border: "none",
                                padding: "0.5rem",
                                borderRadius: "6px",
                                cursor: "pointer",
                              }}
                            >
                              <i className="fas fa-check" />
                            </button>
                          )}
                          {d.statut !== "rejete" && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onChangeStatus(d.id, "rejete");
                              }}
                              style={{
                                background: "#dc3545",
                                color: "white",
                                border: "none",
                                padding: "0.5rem",
                                borderRadius: "6px",
                                cursor: "pointer",
                              }}
                            >
                              <i className="fas fa-times" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination page={page} setPage={setPage} totalPages={totalPages} />
        </>
      )}
    </div>
  );
};

// ============================================
// PANEL EMPLOYÉS
// ============================================

interface PanelEmployesProps {
  employes: Employe[];
  loading: boolean;
  search: string;
  setSearch: (s: string) => void;
  page: number;
  setPage: (p: number) => void;
  totalPages: number;
}

const PanelEmployes: React.FC<PanelEmployesProps> = ({ employes, loading, search, setSearch, page, setPage, totalPages }) => {
  const filtered = employes.filter(
    (e) =>
      !search ||
      `${e.prenom} ${e.nom}`.toLowerCase().includes(search.toLowerCase()) ||
      e.email.toLowerCase().includes(search.toLowerCase()) ||
      e.poste.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="panel" style={{ background: "white", borderRadius: "12px", padding: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem", flexWrap: "wrap", gap: "1rem" }}>
        <h2 style={{ margin: 0, fontSize: "1.5rem", fontWeight: 700 }}>
          <i className="fas fa-users" style={{ marginRight: "0.5rem", color: "#0d6efd" }} />
          Gestion des Employés
        </h2>
        <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
          <input
            type="text"
            placeholder="Rechercher un employé..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ padding: "0.5rem 1rem", border: "1px solid #dee2e6", borderRadius: "6px", minWidth: "200px" }}
          />
          <button className="btn btn-sm" style={{ background: "#dc3545", color: "white", border: "none", padding: "0.5rem 1rem", borderRadius: "6px" }}>
            <i className="fas fa-file-pdf" /> PDF
          </button>
          <button className="btn btn-sm" style={{ background: "#198754", color: "white", border: "none", padding: "0.5rem 1rem", borderRadius: "6px" }}>
            <i className="fas fa-file-excel" /> Excel
          </button>
        </div>
      </header>

      {loading ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>Chargement…</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>
          <i className="fas fa-users" style={{ fontSize: "3rem", marginBottom: "1rem", opacity: 0.5 }} />
          <p>Aucun employé trouvé.</p>
        </div>
      ) : (
        <>
          <div style={{ overflowX: "auto", maxHeight: "70vh", overflowY: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead style={{ background: "#f8f9fa", position: "sticky", top: 0 }}>
                <tr>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Profil</th>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Nom complet</th>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Poste</th>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Contact</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>Département</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>Statut</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((e) => {
                  const initiales = `${e.prenom[0] || ""}${e.nom[0] || ""}`.toUpperCase();
                  return (
                    <tr
                      key={e.id}
                      style={{ cursor: "pointer", borderBottom: "1px solid #dee2e6" }}
                      onClick={() => (window.location.href = `/employe/${e.id}`)}
                      onMouseEnter={(ev) => (ev.currentTarget.style.background = "rgba(13, 110, 253, 0.05)")}
                      onMouseLeave={(ev) => (ev.currentTarget.style.background = "transparent")}
                    >
                      <td style={{ padding: "0.75rem" }}>
                        <div
                          style={{
                            width: "45px",
                            height: "45px",
                            borderRadius: "50%",
                            background: "#0d6efd",
                            color: "white",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontWeight: 600,
                          }}
                        >
                          {initiales}
                        </div>
                      </td>
                      <td style={{ padding: "0.75rem", fontWeight: 600 }}>
                        {e.prenom} {e.nom}
                      </td>
                      <td style={{ padding: "0.75rem" }}>{e.poste}</td>
                      <td style={{ padding: "0.75rem" }}>
                        <a href={`mailto:${e.email}`} style={{ color: "#0d6efd", textDecoration: "none" }}>
                          {e.email}
                        </a>
                        <br />
                        <small style={{ color: "#6c757d" }}>{e.telephone || "—"}</small>
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        <span style={{ background: "#0d6efd", color: "white", padding: "0.25rem 0.75rem", borderRadius: "12px", fontSize: "0.875rem" }}>
                          {e.departement.replace("depart_", "").replace(/_/g, " ")}
                        </span>
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        <span
                          style={{
                            background: e.statut === "actif" ? "#198754" : "#dc3545",
                            color: "white",
                            padding: "0.25rem 0.75rem",
                            borderRadius: "12px",
                            fontSize: "0.875rem",
                          }}
                        >
                          {e.statut === "actif" ? "Actif" : "Inactif"}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination page={page} setPage={setPage} totalPages={totalPages} />
        </>
      )}
    </div>
  );
};

// ============================================
// PANEL ADMINS
// ============================================

interface PanelAdminsProps {
  admins: Admin[];
  loading: boolean;
  search: string;
  setSearch: (s: string) => void;
}

const PanelAdmins: React.FC<PanelAdminsProps> = ({ admins, loading, search, setSearch }) => {
  const filtered = admins.filter(
    (a) =>
      !search ||
      `${a.prenom} ${a.nom}`.toLowerCase().includes(search.toLowerCase()) ||
      a.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="panel" style={{ background: "white", borderRadius: "12px", padding: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem", flexWrap: "wrap", gap: "1rem" }}>
        <h2 style={{ margin: 0, fontSize: "1.5rem", fontWeight: 700 }}>
          <i className="fas fa-user-shield" style={{ marginRight: "0.5rem", color: "#0d6efd" }} />
          Gestion des Administrateurs
        </h2>
        <div style={{ display: "flex", gap: "0.5rem" }}>
          <input
            type="text"
            placeholder="Rechercher un admin..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ padding: "0.5rem 1rem", border: "1px solid #dee2e6", borderRadius: "6px", minWidth: "200px" }}
          />
          <button className="btn btn-sm" style={{ background: "#dc3545", color: "white", border: "none", padding: "0.5rem 1rem", borderRadius: "6px" }}>
            <i className="fas fa-file-pdf" /> PDF
          </button>
          <button className="btn btn-sm" style={{ background: "#198754", color: "white", border: "none", padding: "0.5rem 1rem", borderRadius: "6px" }}>
            <i className="fas fa-file-excel" /> Excel
          </button>
        </div>
      </header>

      {loading ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>Chargement…</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>
          <i className="fas fa-user-shield" style={{ fontSize: "3rem", marginBottom: "1rem", opacity: 0.5 }} />
          <p>Aucun administrateur trouvé.</p>
        </div>
      ) : (
        <div style={{ overflowX: "auto", maxHeight: "70vh", overflowY: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead style={{ background: "#f8f9fa", position: "sticky", top: 0 }}>
              <tr>
                <th style={{ padding: "0.75rem", textAlign: "left" }}>Profil</th>
                <th style={{ padding: "0.75rem", textAlign: "left" }}>Administrateur</th>
                <th style={{ padding: "0.75rem", textAlign: "left" }}>Contact</th>
                <th style={{ padding: "0.75rem", textAlign: "left" }}>Adresse</th>
                <th style={{ padding: "0.75rem", textAlign: "center" }}>Statut</th>
                <th style={{ padding: "0.75rem", textAlign: "center" }}>Dernière activité</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => {
                const initiales = `${a.prenom[0] || ""}${a.nom[0] || ""}`.toUpperCase();
                const isActive = a.status === "active" || (a.last_activity && new Date(a.last_activity).getTime() > Date.now() - 30 * 60 * 1000);
                return (
                  <tr
                    key={a.id}
                    style={{ cursor: "pointer", borderBottom: "1px solid #dee2e6" }}
                    onClick={() => (window.location.href = `/admin/${a.id}`)}
                    onMouseEnter={(ev) => (ev.currentTarget.style.background = "rgba(13, 110, 253, 0.05)")}
                    onMouseLeave={(ev) => (ev.currentTarget.style.background = "transparent")}
                  >
                    <td style={{ padding: "0.75rem" }}>
                      <div
                        style={{
                          width: "45px",
                          height: "45px",
                          borderRadius: "50%",
                          background: "#0d6efd",
                          color: "white",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontWeight: 600,
                        }}
                      >
                        {initiales}
                      </div>
                    </td>
                    <td style={{ padding: "0.75rem" }}>
                      <div style={{ fontWeight: 600 }}>{a.prenom} {a.nom}</div>
                      <small style={{ color: "#6c757d" }}>{a.role}</small>
                    </td>
                    <td style={{ padding: "0.75rem" }}>
                      <div>{a.email}</div>
                      <small style={{ color: "#6c757d" }}>{a.telephone || "N/A"}</small>
                    </td>
                    <td style={{ padding: "0.75rem" }}>
                      <small style={{ color: "#6c757d" }}>{a.adresse || "Non renseignée"}</small>
                    </td>
                    <td style={{ padding: "0.75rem", textAlign: "center" }}>
                      <span
                        style={{
                          background: isActive ? "#198754" : "#6c757d",
                          color: "white",
                          padding: "0.25rem 0.75rem",
                          borderRadius: "12px",
                          fontSize: "0.875rem",
                        }}
                      >
                        {isActive ? "Actif" : "Inactif"}
                      </span>
                    </td>
                    <td style={{ padding: "0.75rem", textAlign: "center" }}>
                      <small style={{ color: "#6c757d" }}>
                        {a.last_activity ? new Date(a.last_activity).toLocaleString("fr-FR") : "Jamais"}
                      </small>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ============================================
// PANEL RETARDS
// ============================================

interface PanelRetardsProps {
  retards: Retard[];
  loading: boolean;
  dateFilter: string;
  setDateFilter: (v: string) => void;
  depFilter: string;
  setDepFilter: (v: string) => void;
  departements: string[];
  page: number;
  setPage: (p: number) => void;
  totalPages: number;
}

const PanelRetards: React.FC<PanelRetardsProps> = ({
  retards,
  loading,
  dateFilter,
  setDateFilter,
  depFilter,
  setDepFilter,
  departements,
  page,
  setPage,
  totalPages,
}) => {
  return (
    <div className="panel" style={{ background: "white", borderRadius: "12px", padding: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
      <header style={{ marginBottom: "1.5rem" }}>
        <h2 style={{ margin: 0, fontSize: "1.5rem", fontWeight: 700 }}>
          <i className="fas fa-clock" style={{ marginRight: "0.5rem", color: "#dc3545" }} />
          Retards à justifier
        </h2>
      </header>

      {/* FILTRES */}
      <div style={{ display: "flex", gap: "1rem", marginBottom: "1.5rem", flexWrap: "wrap" }}>
        <div style={{ flex: "1", minWidth: "200px" }}>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: 600 }}>Date :</label>
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            style={{ width: "100%", padding: "0.5rem", border: "1px solid #dee2e6", borderRadius: "6px" }}
          />
        </div>
        <div style={{ flex: "1", minWidth: "200px" }}>
          <label style={{ display: "block", marginBottom: "0.5rem", fontWeight: 600 }}>Département :</label>
          <select
            value={depFilter}
            onChange={(e) => setDepFilter(e.target.value)}
            style={{ width: "100%", padding: "0.5rem", border: "1px solid #dee2e6", borderRadius: "6px" }}
          >
            <option value="">Tous</option>
            {departements.map((dep) => (
              <option key={dep} value={dep}>
                {dep.replace("depart_", "").replace(/_/g, " ")}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>Chargement…</div>
      ) : retards.length === 0 ? (
        <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>
          <i className="fas fa-check-circle" style={{ fontSize: "3rem", marginBottom: "1rem", color: "#198754" }} />
          <h5 style={{ color: "#198754", fontWeight: 700 }}>Aucun retard</h5>
          <p style={{ color: "#6c757d" }}>Aucun employé n&apos;est en retard pour cette période.</p>
        </div>
      ) : (
        <>
          <div style={{ overflowX: "auto", maxHeight: "70vh", overflowY: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead style={{ background: "#f8f9fa", position: "sticky", top: 0 }}>
                <tr>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Avatar</th>
                  <th style={{ padding: "0.75rem", textAlign: "left" }}>Employé</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>Département</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>Date</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>Retard</th>
                  <th style={{ padding: "0.75rem", textAlign: "center" }}>État / Cause</th>
                </tr>
              </thead>
              <tbody>
                {retards.map((r) => {
                  const initiales = `${r.prenom[0] || ""}${r.nom[0] || ""}`.toUpperCase();
                  const depLabel = r.departement.replace("depart_", "").replace(/_/g, " ");
                  const isJustifie = r.statut === "approuve" || r.est_justifie;
                  return (
                    <tr
                      key={r.id}
                      style={{ cursor: "pointer", borderBottom: "1px solid #dee2e6" }}
                      onClick={() => (window.location.href = `/employe/${r.employe_id}`)}
                      onMouseEnter={(ev) => (ev.currentTarget.style.background = "rgba(13, 110, 253, 0.05)")}
                      onMouseLeave={(ev) => (ev.currentTarget.style.background = "transparent")}
                    >
                      <td style={{ padding: "0.75rem" }}>
                        <div
                          style={{
                            width: "42px",
                            height: "42px",
                            borderRadius: "50%",
                            background: "#dc3545",
                            color: "white",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontWeight: 600,
                          }}
                        >
                          {initiales}
                        </div>
                      </td>
                      <td style={{ padding: "0.75rem", fontWeight: 600 }}>
                        {r.prenom} {r.nom}
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        <span style={{ background: "#0d6efd", color: "white", padding: "0.25rem 0.75rem", borderRadius: "12px", fontSize: "0.875rem" }}>
                          {depLabel}
                        </span>
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        {new Date(r.date_heure).toLocaleDateString("fr-FR")}
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        <span style={{ background: "#dc3545", color: "white", padding: "0.5rem 1rem", borderRadius: "12px", fontWeight: 600 }}>
                          {r.retard_minutes} min
                        </span>
                      </td>
                      <td style={{ padding: "0.75rem", textAlign: "center" }}>
                        {isJustifie ? (
                          <span style={{ background: "#198754", color: "white", padding: "0.5rem 1rem", borderRadius: "12px" }}>
                            <i className="fas fa-check-circle" style={{ marginRight: "0.25rem" }} />
                            {r.retard_raison || "Justifié"}
                          </span>
                        ) : r.statut === "en_attente" ? (
                          <span style={{ background: "#ffc107", color: "#000", padding: "0.5rem 1rem", borderRadius: "12px" }}>
                            <i className="fas fa-hourglass-half" style={{ marginRight: "0.25rem" }} />
                            En attente
                          </span>
                        ) : (
                          <span style={{ background: "#dc3545", color: "white", padding: "0.5rem 1rem", borderRadius: "12px" }}>
                            <i className="fas fa-exclamation-triangle" style={{ marginRight: "0.25rem" }} />
                            Non justifié
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination page={page} setPage={setPage} totalPages={totalPages} />
        </>
      )}
    </div>
  );
};

// ============================================
// PANEL CALENDRIER
// ============================================

const PanelCalendrier: React.FC = () => {
  return (
    <div className="panel" style={{ background: "white", borderRadius: "12px", padding: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
      <header style={{ marginBottom: "1.5rem" }}>
        <h2 style={{ margin: 0, fontSize: "1.5rem", fontWeight: 700 }}>
          <i className="fas fa-calendar" style={{ marginRight: "0.5rem", color: "#0d6efd" }} />
          Calendrier des événements
        </h2>
      </header>
      <div style={{ textAlign: "center", padding: "3rem", color: "#6c757d" }}>
        <p>Le calendrier sera intégré avec FullCalendar dans une prochaine étape.</p>
        <p style={{ fontSize: "0.875rem", marginTop: "1rem" }}>
          Pour l&apos;instant, utilisez le calendrier depuis l&apos;interface PHP existante.
        </p>
      </div>
    </div>
  );
};

// ============================================
// COMPOSANT PAGINATION
// ============================================

interface PaginationProps {
  page: number;
  setPage: (p: number) => void;
  totalPages: number;
}

const Pagination: React.FC<PaginationProps> = ({ page, setPage, totalPages }) => {
  if (totalPages <= 1) return null;

  return (
    <div className="pagination">
      <span className="paginationInfo">Page {page} sur {totalPages}</span>
      <div className="paginationControls">
        <button
          onClick={() => setPage(Math.max(1, page - 1))}
          disabled={page <= 1}
          className="paginationButton"
        >
          &laquo; Précédent
        </button>
        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
          const p = Math.max(1, Math.min(totalPages - 4, page - 2)) + i;
          if (p > totalPages) return null;
          return (
            <button
              key={p}
              onClick={() => setPage(p)}
              className={`paginationButton ${p === page ? 'active' : ''}`}
            >
              {p}
            </button>
          );
        })}
        <button
          onClick={() => setPage(Math.min(totalPages, page + 1))}
          disabled={page >= totalPages}
          className="paginationButton"
        >
          Suivant &raquo;
        </button>
      </div>
    </div>
  );
};
