import React, { useEffect, useState } from 'react'
import { 
  Users, 
  UserCheck, 
  UserX, 
  Clock, 
  TrendingUp, 
  Calendar,
  FileText,
  Download,
  Plus,
  Search,
  Filter,
  Bell,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Eye,
  Edit,
  Trash2,
  ChevronLeft,
  ChevronRight,
  MoreVertical
} from 'lucide-react'
import { apiClient } from '@services/apiClient'
import Header from '../../components/layout/Header'
import Sidebar from '../../components/layout/Sidebar'

type PanelId = "pointage" | "heures" | "demandes" | "employes" | "admins" | "retards" | "calendrier"

interface AdminDashboardStats {
  totalEmployes: number;
  presents: number;
  absents: number;
  retards: number;
}

interface PointageEntry {
  id: number;
  employe_id: number;
  prenom: string;
  nom: string;
  departement: string;
  date: string;
  arrivee: string | null;
  depart: string | null;
  photo?: string;
}

interface Demande {
  id: number;
  prenom: string;
  nom: string;
  poste: string;
  departement: string;
  type: string;
  date_demande: string;
  statut: "en_attente" | "approuve" | "rejete";
  heures_ecoulees?: number;
  photo?: string;
}

interface Employe {
  id: number;
  prenom: string;
  nom: string;
  email: string;
  telephone?: string;
  poste: string;
  departement: string;
  statut: string;
  date_embauche?: string;
  contrat_type?: string;
  contrat_duree?: string;
  salaire?: number;
  adresse?: string;
  photo?: string;
}

interface Admin {
  id: number;
  prenom: string;
  nom: string;
  email: string;
  telephone?: string;
  role: string;
  adresse?: string;
  last_activity?: string;
  status?: string;
  photo?: string;
}

interface Retard {
  id: number;
  employe_id: number;
  prenom: string;
  nom: string;
  departement: string;
  date_heure: string;
  retard_minutes: number;
  statut?: string;
  retard_raison?: string;
  est_justifie?: boolean;
}

export const AdminDashboardImproved: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activePanel, setActivePanel] = useState<PanelId>("pointage")
  const [stats, setStats] = useState<AdminDashboardStats | null>(null)
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [showFilters, setShowFilters] = useState(false)

  // Panel states
  const [pointages, setPointages] = useState<PointageEntry[]>([])
  const [demandes, setDemandes] = useState<Demande[]>([])
  const [employes, setEmployes] = useState<Employe[]>([])
  const [admins, setAdmins] = useState<Admin[]>([])
  const [retards, setRetards] = useState<Retard[]>([])

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const itemsPerPage = 10

  // Filter states
  const [dateFilter, setDateFilter] = useState(new Date().toISOString().split('T')[0])
  const [departementFilter, setDepartementFilter] = useState("")
  const [departements, setDepartements] = useState<string[]>([])

  const currentUser = {
    id: 1,
    prenom: 'Admin',
    nom: 'User',
    email: 'admin@xpertpro.com',
    role: 'admin',
    avatar: ''
  }

  useEffect(() => {
    loadStats()
    loadDepartements()
    loadPointages()
  }, [])

  useEffect(() => {
    if (activePanel === "pointage") loadPointages()
    else if (activePanel === "demandes") loadDemandes()
    else if (activePanel === "employes") loadEmployes()
    else if (activePanel === "admins") loadAdmins()
    else if (activePanel === "retards") loadRetards()
    else if (activePanel === "calendrier") {
      // Initialize legacy calendar script if available
      try {
        // If the old global initCalendar exists, call it
        if (typeof (window as any).initCalendar === 'function') {
          (window as any).initCalendar()
        } else {
          // Otherwise dispatch a panel event so legacy script can react
          window.dispatchEvent(new CustomEvent('panel:shown', { detail: { panelId: 'calendrier' } }))
        }
      } catch (err) {
        console.error('Erreur initialisation calendrier:', err)
      }
    }
  }, [activePanel, currentPage, dateFilter, departementFilter])

  const loadStats = async () => {
    try {
      setLoading(true)
      const data = await apiClient.get<{
        total_employes: number;
        presents: number;
        absents: number;
        retards: number;
      }>("get_pointage_admin_day")
      
      setStats({
        totalEmployes: data.total_employes ?? 0,
        presents: data.presents ?? 0,
        absents: data.absents ?? 0,
        retards: data.retards ?? 0,
      })
    } catch (error) {
      console.error("Erreur chargement stats:", error)
    } finally {
      setLoading(false)
    }
  }

  const loadDepartements = async () => {
    try {
      const data = await apiClient.get<string[]>("get_departements").catch(() => [])
      setDepartements(data || [])
    } catch (error) {
      console.error("Erreur chargement départements:", error)
    }
  }

  const loadPointages = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (dateFilter) params.append("date", dateFilter)
      if (departementFilter) params.append("departement", departementFilter)
      params.append("page_pointage", currentPage.toString())
      params.append("per_page", itemsPerPage.toString())

      const data = await apiClient.get<{
        success: boolean;
        pointages: PointageEntry[];
        total: number;
        total_pages: number;
      }>(`get_pointages?${params.toString()}`)

      if (data.success) {
        setPointages(data.pointages || [])
        setTotalPages(data.total_pages || 1)
      }
    } catch (error) {
      console.error("Erreur chargement pointages:", error)
      setPointages([])
    } finally {
      setLoading(false)
    }
  }

  const loadDemandes = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      params.append("page_demandes", currentPage.toString())
      params.append("per_page", itemsPerPage.toString())

      const data = await apiClient.get<{
        success: boolean;
        demandes: Demande[];
        total: number;
        total_pages: number;
      }>(`get_demandes?${params.toString()}`)

      if (data.success) {
        setDemandes(data.demandes || [])
        setTotalPages(data.total_pages || 1)
      }
    } catch (error) {
      console.error("Erreur chargement demandes:", error)
      setDemandes([])
    } finally {
      setLoading(false)
    }
  }

  const loadEmployes = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      params.append("page", currentPage.toString())
      params.append("per_page", itemsPerPage.toString())

      const data = await apiClient.get<{
        success: boolean;
        employes: Employe[];
        total: number;
        total_pages: number;
      }>(`get_employes?${params.toString()}`)

      if (data.success) {
        setEmployes(data.employes || [])
        setTotalPages(data.total_pages || 1)
      }
    } catch (error) {
      console.error("Erreur chargement employés:", error)
      setEmployes([])
    } finally {
      setLoading(false)
    }
  }

  const loadAdmins = async () => {
    try {
      setLoading(true)
      const data = await apiClient.get<{
        success: boolean;
        admins: Admin[];
        is_super_admin: boolean;
      }>("get_admins")

      if (data.success) {
        setAdmins(data.admins || [])
      }
    } catch (error) {
      console.error("Erreur chargement admins:", error)
      setAdmins([])
    } finally {
      setLoading(false)
    }
  }

  const loadRetards = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (dateFilter) params.append("date_retard", dateFilter)
      if (departementFilter) params.append("dep_retard", departementFilter)
      params.append("page_retard", currentPage.toString())
      params.append("per_page", itemsPerPage.toString())

      const data = await apiClient.get<{
        success: boolean;
        retards: Retard[];
        total: number;
        total_pages: number;
      }>(`get_retards?${params.toString()}`)

      if (data.success) {
        setRetards(data.retards || [])
        setTotalPages(data.total_pages || 1)
      }
    } catch (error) {
      console.error("Erreur chargement retards:", error)
      setRetards([])
    } finally {
      setLoading(false)
    }
  }

  const handleExport = (format: 'pdf' | 'excel') => {
    // Logique d'exportation
    console.log(`Exporting ${activePanel} as ${format}`)
  }

  const handleAdd = () => {
    // Logique d'ajout selon le panel actif
    console.log(`Adding new ${activePanel}`)
  }

  const handleViewDetails = (id: number, type: 'employe' | 'admin') => {
    // Navigation vers la page de détails
    window.location.href = `/${type}/${id}`
  }

  const StatCard = ({ title, value, icon: Icon, color, trend }: {
    title: string
    value: number
    icon: React.ComponentType<any>
    color: string
    trend?: number
  }) => (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-all duration-200">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">{value}</p>
          {trend !== undefined && (
            <div className="flex items-center mt-2">
              {trend > 0 ? (
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              ) : (
                <TrendingUp className="h-4 w-4 text-red-500 mr-1 transform rotate-180" />
              )}
              <span className={`text-sm ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                {Math.abs(trend)}%
              </span>
            </div>
          )}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
      </div>
    </div>
  )

  const renderPointagePanel = () => (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Historique des pointages</h2>
        <div className="flex items-center space-x-3 mt-4 sm:mt-0">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filtres
          </button>
          <button
            onClick={() => handleExport('pdf')}
            className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
          >
            <Download className="h-4 w-4 mr-2" />
            PDF
          </button>
          <button
            onClick={() => handleExport('excel')}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Download className="h-4 w-4 mr-2" />
            Excel
          </button>
        </div>
      </div>

      {showFilters && (
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Date
              </label>
              <input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Département
              </label>
              <select
                value={departementFilter}
                onChange={(e) => setDepartementFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Tous les départements</option>
                {departements.map((dep) => (
                  <option key={dep} value={dep}>
                    {dep.replace("depart_", "").replace(/_/g, " ")}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : pointages.length === 0 ? (
          <div className="text-center py-12">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400">Aucun pointage trouvé pour les filtres sélectionnés</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Employé
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Département
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Arrivée
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Départ
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {pointages.map((pointage) => (
                  <tr key={pointage.id} className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 flex-shrink-0">
                          <div className="h-10 w-10 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 flex items-center justify-center text-white font-medium">
                            {pointage.prenom[0]}{pointage.nom[0]}
                          </div>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {pointage.prenom} {pointage.nom}
                          </div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            ID: {pointage.employe_id}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                        {pointage.departement.replace("depart_", "").replace(/_/g, " ")}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                      {new Date(pointage.date).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {pointage.arrivee ? (
                        <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                          {pointage.arrivee}
                        </span>
                      ) : (
                        <span className="text-gray-500 dark:text-gray-400">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {pointage.depart ? (
                        <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                          {pointage.depart}
                        </span>
                      ) : (
                        <span className="text-gray-500 dark:text-gray-400">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => handleViewDetails(pointage.employe_id, 'employe')}
                        className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 mr-3"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                        <MoreVertical className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-700 dark:text-gray-300">
            Page {currentPage} sur {totalPages}
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="px-3 py-1 text-sm">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  )

  const renderHeuresPanel = () => (
    <div>
      <h2 className="text-xl font-semibold mb-4">Temps totaux par employé</h2>
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        {loading ? (
          <div className="text-center py-12">Chargement...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left">Prénom</th>
                  <th className="px-6 py-3 text-left">Nom</th>
                  <th className="px-6 py-3 text-left">Email</th>
                  <th className="px-6 py-3 text-center">Temps total</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                { (/* temps_totaux placeholder */ []).map((t:any, idx:number) => (
                  <tr key={idx}>
                    <td className="px-6 py-3">{t.prenom}</td>
                    <td className="px-6 py-3">{t.nom}</td>
                    <td className="px-6 py-3">{t.email}</td>
                    <td className="px-6 py-3 text-center">{t.total ?? '00:00'}</td>
                  </tr>
                )) }
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )

  const renderDemandesPanel = () => (
    <div>
      <h2 className="text-xl font-semibold mb-4">Demandes</h2>
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        {demandes.length === 0 ? (
          <div className="text-center py-8 text-gray-500">Aucune demande pour le moment.</div>
        ) : (
          <div className="space-y-2">
            {demandes.map(d => (
              <div key={d.id} className="p-3 border rounded-md flex items-center justify-between">
                <div>
                  <div className="font-medium">{d.prenom} {d.nom} — {d.type}</div>
                  <div className="text-sm text-gray-500">{new Date(d.date_demande).toLocaleString('fr-FR')}</div>
                </div>
                <div className="space-x-2">
                  <button className="px-3 py-1 bg-green-600 text-white rounded">Approuver</button>
                  <button className="px-3 py-1 bg-red-600 text-white rounded">Rejeter</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )

  const renderEmployesPanel = () => (
    <div>
      <h2 className="text-xl font-semibold mb-4">Employés</h2>
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        {employes.length === 0 ? (
          <div className="text-center py-8 text-gray-500">Aucun employé trouvé.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left">ID</th>
                  <th className="px-6 py-3 text-left">Nom</th>
                  <th className="px-6 py-3 text-left">Email</th>
                  <th className="px-6 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {employes.map(emp => (
                  <tr key={emp.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td className="px-6 py-3">{emp.id}</td>
                    <td className="px-6 py-3">{emp.prenom} {emp.nom}</td>
                    <td className="px-6 py-3">{emp.email}</td>
                    <td className="px-6 py-3">
                      <button onClick={() => handleViewDetails(emp.id, 'employe')} className="text-blue-600">Voir</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )

  const renderAdminsPanel = () => (
    <div>
      <h2 className="text-xl font-semibold mb-4">Administrateurs</h2>
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        {admins.length === 0 ? (
          <div className="text-center py-8 text-gray-500">Aucun administrateur trouvé.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {admins.map(a => (
              <div key={a.id} className="p-3 border rounded-md flex items-center justify-between">
                <div>
                  <div className="font-medium">{a.prenom} {a.nom}</div>
                  <div className="text-sm text-gray-500">{a.email}</div>
                </div>
                <div className="text-sm text-gray-500">{a.role}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )

  const renderRetardsPanel = () => (
    <div>
      <h2 className="text-xl font-semibold mb-4">Retards</h2>
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        {retards.length === 0 ? (
          <div className="text-center py-8 text-gray-500">Aucun retard enregistré.</div>
        ) : (
          <div className="space-y-2">
            {retards.map(r => (
              <div key={r.id} className="p-3 border rounded-md flex items-center justify-between">
                <div>
                  <div className="font-medium">{r.prenom} {r.nom}</div>
                  <div className="text-sm text-gray-500">{new Date(r.date_heure).toLocaleString('fr-FR')}</div>
                </div>
                <div className="text-sm text-gray-700">{r.retard_minutes} min</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )

  const renderCalendrierPanel = () => (
    <div>
      <h2 className="text-xl font-semibold mb-4">Calendrier</h2>
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        <div id="calendar-admin" style={{minHeight: 400}} />
        <div id="calendar-loading" style={{display: 'none'}} className="text-center mt-3">Chargement...</div>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} userRole="admin" />
      
      <div className={`transition-all duration-300 ${sidebarOpen ? 'lg:ml-64' : ''}`}>
        <Header 
          user={currentUser}
          title="Dashboard Administrateur"
          onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
          sidebarOpen={sidebarOpen}
        />
        
        <main className="p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatCard
              title="Total employés"
              value={stats?.totalEmployes || 0}
              icon={Users}
              color="bg-blue-600"
              trend={5}
            />
            <StatCard
              title="Présents aujourd'hui"
              value={stats?.presents || 0}
              icon={UserCheck}
              color="bg-green-600"
              trend={2}
            />
            <StatCard
              title="Absents aujourd'hui"
              value={stats?.absents || 0}
              icon={UserX}
              color="bg-orange-600"
              trend={-1}
            />
            <StatCard
              title="Retards du jour"
              value={stats?.retards || 0}
              icon={Clock}
              color="bg-red-600"
              trend={-3}
            />
          </div>

          {/* Panel Tabs */}
          <div className="mb-6">
            <nav className="flex flex-wrap gap-2">
              {([
                ['pointage','Pointage'],
                ['heures','Heures'],
                ['demandes','Demandes'],
                ['employes','Employés'],
                ['admins','Admins'],
                ['retards','Retards'],
                ['calendrier','Calendrier']
              ] as [PanelId,string][]).map(([id,label]) => (
                <button
                  key={id}
                  onClick={() => { setActivePanel(id); setCurrentPage(1); }}
                  className={`px-3 py-2 rounded-lg border ${activePanel===id? 'bg-blue-600 text-white border-blue-600':'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-700'}`}
                >{label}</button>
              ))}
            </nav>
          </div>

          {/* Panel Content */}
          {activePanel === 'pointage' && renderPointagePanel()}
          {activePanel === 'heures' && renderHeuresPanel()}
          {activePanel === 'demandes' && renderDemandesPanel()}
          {activePanel === 'employes' && renderEmployesPanel()}
          {activePanel === 'admins' && renderAdminsPanel()}
          {activePanel === 'retards' && renderRetardsPanel()}
          {activePanel === 'calendrier' && renderCalendrierPanel()}
        </main>
      </div>
    </div>
  )
}

export default AdminDashboardImproved
