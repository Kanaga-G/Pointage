import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../services/authService';
import LayoutFix from '../../components/LayoutFix';
import { apiClient } from '../../services/apiClient';

interface EmployeDetail {
  id: number;
  nom: string;
  prenom: string;
  email: string;
  role: string;
  departement: string;
  poste: string;
  telephone?: string;
  adresse?: string;
  date_embauche: string;
  statut: string;
  photo?: string;
  contact_urgence_nom?: string;
  contact_urgence_telephone?: string;
  contact_urgence_relation?: string;
}

export default function EmployeEditPage() {
  const { user } = useAuth();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [employe, setEmploye] = useState<EmployeDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    telephone: '',
    adresse: '',
    departement: '',
    poste: '',
    statut: '',
    contact_urgence_nom: '',
    contact_urgence_telephone: '',
    contact_urgence_relation: ''
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/admin');
      return;
    }
    if (id) {
      loadEmployeDetail(parseInt(id));
    }
  }, [user, id, navigate]);

  const loadEmployeDetail = async (employeId: number) => {
    try {
      setLoading(true);
      const res = await apiClient.get<{ success: boolean; employe?: EmployeDetail; message?: string }>(`/employes/${employeId}`);
      if (!res?.success || !res.employe) {
        throw new Error(res?.message || 'Employé non trouvé');
      }

      const found = res.employe;
      setEmploye(found);
      setFormData({
        telephone: found.telephone || '',
        adresse: found.adresse || '',
        departement: found.departement || '',
        poste: found.poste || '',
        statut: found.statut || '',
        contact_urgence_nom: found.contact_urgence_nom || '',
        contact_urgence_telephone: found.contact_urgence_telephone || '',
        contact_urgence_relation: found.contact_urgence_relation || ''
      });
    } catch (err) {
      console.error('Erreur lors du chargement:', err);
      setError('Erreur lors du chargement des détails de l\'employé');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);

      if (!id) {
        throw new Error('ID employé manquant');
      }

      const employeId = Number(id);
      const res = await apiClient.put<typeof formData, { success: boolean; employe?: EmployeDetail; message?: string }>(
        `/employes/${employeId}`,
        formData
      );

      if (!res?.success) {
        throw new Error(res?.message || 'Erreur lors de la mise à jour');
      }

      if (res.employe) {
        setEmploye(res.employe);
      }

      setSuccess('Informations de l\'employé mises à jour avec succès');
      navigate(`/admin/employe/${id}`);
      
    } catch (err) {
      console.error('Erreur lors de la mise à jour:', err);
      setError('Erreur lors de la mise à jour des informations');
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    navigate(`/admin/employe/${id}`);
  };

  if (loading) {
    return (
      <LayoutFix title="Modification Employé">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </LayoutFix>
    );
  }

  if (!employe) {
    return (
      <LayoutFix title="Modification Employé">
        <div className="text-center text-red-600">
          Employé non trouvé
        </div>
      </LayoutFix>
    );
  }

  return (
    <LayoutFix title="Modification Employé">
      <div className="max-w-4xl mx-auto">
        {/* En-tête */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Modifier {employe.prenom} {employe.nom}
              </h1>
              <p className="text-gray-600">
                {employe.poste} • {employe.departement}
              </p>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={handleCancel}
                className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {saving ? 'Enregistrement...' : 'Enregistrer'}
              </button>
            </div>
          </div>
        </div>

        {/* Messages */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
            {success}
          </div>
        )}

        {/* Photo et informations de base */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center space-x-6 mb-6">
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center">
              {employe.photo ? (
                <img src={employe.photo} alt="Photo" className="w-full h-full rounded-full object-cover" />
              ) : (
                <span className="text-2xl text-gray-600">
                  {employe.prenom?.[0]}{employe.nom?.[0]}
                </span>
              )}
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                {employe.prenom} {employe.nom}
              </h2>
              <p className="text-gray-600">{employe.poste}</p>
              <span className={`inline-block px-3 py-1 rounded-full text-sm ${
                employe.statut === 'actif' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-gray-100 text-gray-800'
              }`}>
                {employe.statut}
              </span>
            </div>
          </div>
        </div>

        {/* Informations professionnelles */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations professionnelles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email professionnel
              </label>
              <input
                type="email"
                name="email"
                value={employe.email}
                disabled
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Non modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Rôle
              </label>
              <select
                name="role"
                value={employe.role}
                disabled
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="employe">Employé</option>
                <option value="admin">Administrateur</option>
                <option value="manager">Manager</option>
                <option value="hr">Ressources Humaines</option>
              </select>
              <p className="text-xs text-gray-500 mt-1">Non modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Département
              </label>
              <input
                type="text"
                name="departement"
                value={formData.departement}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Poste
              </label>
              <input
                type="text"
                name="poste"
                value={formData.poste}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Statut
              </label>
              <select
                name="statut"
                value={formData.statut}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="actif">Actif</option>
                <option value="inactif">Inactif</option>
                <option value="suspendu">Suspendu</option>
              </select>
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date d'embauche
              </label>
              <p className="text-gray-900">
                {new Date(employe.date_embauche).toLocaleDateString('fr-FR')}
              </p>
              <p className="text-xs text-gray-500 mt-1">Non modifiable</p>
            </div>
          </div>
        </div>

        {/* Informations personnelles */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations personnelles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Téléphone
              </label>
              <input
                type="tel"
                name="telephone"
                value={formData.telephone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Adresse
              </label>
              <textarea
                name="adresse"
                value={formData.adresse}
                onChange={handleInputChange}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
          </div>
        </div>

        {/* Contact d'urgence */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact d'urgence</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nom du contact
              </label>
              <input
                type="text"
                name="contact_urgence_nom"
                value={formData.contact_urgence_nom}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Téléphone du contact
              </label>
              <input
                type="tel"
                name="contact_urgence_telephone"
                value={formData.contact_urgence_telephone}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Relation
              </label>
              <input
                type="text"
                name="contact_urgence_relation"
                value={formData.contact_urgence_relation}
                onChange={handleInputChange}
                placeholder="Ex: Conjoint, Frère, Mère..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
          </div>
        </div>

        {/* Boutons d'action */}
        <div className="flex justify-end space-x-4">
          <button
            onClick={handleCancel}
            disabled={saving}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            Annuler
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {saving ? 'Enregistrement...' : 'Enregistrer'}
          </button>
        </div>
      </div>
    </LayoutFix>
  );
}
