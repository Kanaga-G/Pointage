import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, UserCheck, UserX, Clock, Calendar, FileText, TrendingUp, Download, Search, Bell, Settings, LogOut, Menu, X, Plus, Edit, Trash2 } from 'lucide-react';
import { adminService } from '../../services/adminService';
import { employeCrudService } from '../../services/employeCrudService';
import { Employe, Demande } from '../../types/dashboard';
import { AdminStats } from '../../services/adminService';
import '../../styles/admin.css';

// Import des panels depuis components/panels
import DashboardPanel from '../../components/panels/DashboardPanel';
import PanelEmployes from '../../components/panels/PanelEmployes';
import PanelPointage from '../../components/panels/PanelPointage';
import PanelDemandes from '../../components/panels/PanelDemandes';
import CalendarPanel from '../../components/panels/CalendarPanel';
import ReportsPanel from '../../components/panels/ReportsPanel';
import SettingsPanel from '../../components/panels/SettingsPanel';
import NotificationsPanel from '../../components/panels/NotificationsPanel';

interface DashboardStats {
  total_employes: number;
  present_today: number;
  absents_today: number;
  retards_today: number;
}

interface PointageEntry {
  id: number;
  employe_id: number;
  prenom: string;
  nom: string;
  departement: string;
  date: string;
  arrivee: string | null;
  depart: string | null;
}

const ModernAdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [pointages, setPointages] = useState<PointageEntry[]>([]);
  const [employes, setEmployes] = useState<Employe[]>([]);
  const [demandes, setDemandes] = useState<Demande[]>([]);
  const [demandesStats, setDemandesStats] = useState({
    total: 0,
    en_attente: 0,
    approuve: 0,
    rejete: 0
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [activePanel, setActivePanel] = useState<string>('dashboard');
  const [error, setError] = useState<string | null>(null);

  const navigationItems = [
    { id: 'dashboard', label: 'Vue d\'ensemble', icon: <TrendingUp className="h-5 w-5" /> },
    { id: 'pointages', label: 'Pointages', icon: <Clock className="h-5 w-5" /> },
    { id: 'employes', label: 'Employés', icon: <Users className="h-5 w-5" /> },
    { id: 'demandes', label: 'Demandes', icon: <FileText className="h-5 w-5" /> },
    { id: 'calendrier', label: 'Calendrier', icon: <Calendar className="h-5 w-5" /> },
    { id: 'rapports', label: 'Rapports', icon: <TrendingUp className="h-5 w-5" /> },
    { id: 'parametres', label: 'Paramètres', icon: <Bell className="h-5 w-5" /> },
  ];

  // Rendu du panel actif
  const renderActivePanel = () => {
    switch (activePanel) {
      case 'dashboard':
        return <DashboardPanel />;
      case 'pointages':
        return <PanelPointage data={pointages} />;
      case 'employes':
        return <PanelEmployes data={employes} />;
      case 'demandes':
        return <PanelDemandes data={demandes} stats={demandesStats} />;
      case 'calendrier':
        return <CalendarPanel />;
      case 'rapports':
        return <ReportsPanel />;
      case 'parametres':
        return <SettingsPanel />;
      default:
        return <DashboardPanel />;
    }
  };

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Charger les statistiques depuis le backend
        const statsData = await adminService.getStats();
        setStats(statsData);
        
        // Charger les pointages récents
        const pointagesData = await adminService.getPointages({ page: 1, per_page: 10 });
        setPointages(pointagesData.items);
        
        // Charger les employés
        const employesData = await employeCrudService.getAllEmployes({ page: 1, per_page: 20 });
        setEmployes(employesData.items as Employe[]);
        setTotalPages(employesData.total_pages);
        
      } catch (error) {
        console.error('Erreur lors du chargement des données:', error);
        setError('Impossible de charger les données du dashboard');
        
        // En cas d'erreur, utiliser des données de démonstration
        setStats({
          total_employes: 45,
          presents: 38,
          absents: 5,
          retards: 2,
          total_heures_jour: 320,
          taux_presence: 84.4
        });
        
        setPointages([
          { id: 1, employe_id: 1, prenom: 'Jean', nom: 'Dupont', departement: 'IT', date: '2024-01-15', arrivee: '08:30', depart: '17:30' },
          { id: 2, employe_id: 2, prenom: 'Marie', nom: 'Martin', departement: 'RH', date: '2024-01-15', arrivee: '08:45', depart: null },
        ]);
        
        setEmployes([
          { id: 1, prenom: 'Jean', nom: 'Dupont', email: 'jean.dupont@entreprise.com', departement: 'IT', poste: 'Développeur', statut: 'actif' },
          { id: 2, prenom: 'Marie', nom: 'Martin', email: 'marie.martin@entreprise.com', departement: 'RH', poste: 'Responsable RH', statut: 'actif' },
        ]);
        
        setDemandes([
          { id: 1, employe_id: 1, employe: 'Jean Dupont', type: 'conge', motif: 'Vacances', date_debut: '2024-01-20', date_fin: '2024-01-25', statut: 'en_attente', date_demande: '2024-01-15' },
          { id: 2, employe_id: 2, employe: 'Marie Martin', type: 'absence', motif: 'Maladie', date_debut: '2024-01-18', statut: 'approuve', date_demande: '2024-01-17', traite_par: 'Admin', date_traitement: '2024-01-18' },
        ]);
        
        setDemandesStats({
          total: 2,
          en_attente: 1,
          approuve: 1,
          rejete: 0
        });
        
      } finally {
        setLoading(false);
      }
    };
    
    loadDashboardData();
  }, []);

  const handleRowClick = (id: number) => {
    navigate(`/employe/${id}`);
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-content">
          <div className="loading-spinner mb-4"></div>
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <header className="header">
        <div className="header-content px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded hover:bg-gray-100"
            >
              {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
            <h1 className="header-title ml-4 text-xl font-bold">XpertPro Admin</h1>
          </div>
          <div className="header-actions">
            <button className="header-button">
              <Bell className="h-5 w-5" />
            </button>
            <button className="header-button">
              <Settings className="h-5 w-5" />
            </button>
            <div className="header-avatar">
              A
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'} w-64 bg-white border-r border-gray-200 min-h-screen`}>
          <div className="sidebar-content">
            <nav className="sidebar-nav">
              {navigationItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActivePanel(item.id)}
                  className={`sidebar-nav-item ${
                    activePanel === item.id ? 'active' : ''
                  }`}
                >
                  {item.icon}
                  <span className="sidebar-nav-text">{item.label}</span>
                </button>
              ))}
            </nav>
          </div>
          <div className="sidebar-footer">
            <button className={`sidebar-nav-item text-red-600`}>
              <LogOut className="h-5 w-5" />
              <span className="sidebar-nav-text">Déconnexion</span>
            </button>
          </div>
        </aside>

        <main className="main-content">
          {/* Indicateur de connexion PostgreSQL */}
          <div className={`card mb-4 bg-blue-50 border border-blue-200`}>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-blue-700">
                Connecté à PostgreSQL (moha@pointage) - Panel: {activePanel}
              </span>
            </div>
          </div>

          {/* Afficher le panel actif */}
          {error && (
            <div className={`card bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4`}>
              {error}
            </div>
          )}
          
          {renderActivePanel()}
        </main>
      </div>

      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default ModernAdminDashboard;
