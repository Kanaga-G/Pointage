import React from 'react'

const EmployeListPage: React.FC = () => {
  return (
    <div className="px-4 py-6 sm:px-0">
      <div className="border-4 border-dashed border-gray-200 rounded-lg h-96">
        <div className="p-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Liste des Employés</h1>
          <div className="bg-white shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <p className="text-gray-600">Chargement des employés...</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default EmployeListPage
