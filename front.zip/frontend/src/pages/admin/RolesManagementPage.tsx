import React, { useEffect, useMemo, useState } from 'react';
import LayoutFix from '../../components/LayoutFix';
import { apiClient } from '../../services/apiClient';

interface EmployeRow {
  id: number;
  nom: string;
  prenom: string;
  email: string;
  role?: string;
  departement?: string;
  statut?: string;
}

type RoleOption = 'admin' | 'manager' | 'hr' | 'employe';

const ROLE_OPTIONS: { value: RoleOption; label: string }[] = [
  { value: 'admin', label: 'Administrateur' },
  { value: 'manager', label: 'Manager' },
  { value: 'hr', label: 'RH' },
  { value: 'employe', label: 'Employé' }
];

export default function RolesManagementPage() {
  const [rows, setRows] = useState<EmployeRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingIds, setSavingIds] = useState<number[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const load = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await apiClient.get<EmployeRow[]>('/employes');
      setRows(Array.isArray(data) ? data : []);
    } catch (e: any) {
      console.error('Erreur chargement employes (roles):', e);
      setError(e?.message || 'Erreur lors du chargement des employés');
      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((r) => {
      return (
        `${r.prenom || ''} ${r.nom || ''}`.toLowerCase().includes(q) ||
        (r.email || '').toLowerCase().includes(q) ||
        (r.departement || '').toLowerCase().includes(q) ||
        (r.role || '').toLowerCase().includes(q)
      );
    });
  }, [rows, search]);

  const updateRole = async (employeId: number, nextRole: RoleOption) => {
    setSavingIds((prev) => (prev.includes(employeId) ? prev : [...prev, employeId]));

    try {
      const res = await apiClient.put<{ role: RoleOption }, { success: boolean; employe?: EmployeRow; message?: string }>(
        `/employes/${employeId}`,
        { role: nextRole }
      );

      if (!res?.success) {
        throw new Error(res?.message || 'Erreur lors de la mise à jour du rôle');
      }

      setRows((prev) =>
        prev.map((r) => (r.id === employeId ? { ...r, role: nextRole } : r))
      );
    } catch (e: any) {
      console.error('Erreur update role:', e);
      alert(e?.message || 'Erreur lors de la mise à jour du rôle');
    } finally {
      setSavingIds((prev) => prev.filter((id) => id !== employeId));
    }
  };

  return (
    <LayoutFix title="Gestion des rôles">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-1">Rechercher</label>
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Nom, email, département, rôle..."
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={load}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                disabled={loading}
              >
                Rafraîchir
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Attribution des rôles ({filtered.length})</h3>
            <p className="text-sm text-gray-600">Modifiez le rôle d’un employé depuis la liste.</p>
          </div>

          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
          ) : error ? (
            <div className="p-6">
              <div className="text-red-600">{error}</div>
              <button
                onClick={load}
                className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
              >
                Réessayer
              </button>
            </div>
          ) : filtered.length === 0 ? (
            <div className="p-12 text-center text-gray-600">Aucun employé trouvé</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employé</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Département</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rôle</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filtered.map((r) => {
                    const isSaving = savingIds.includes(r.id);
                    const currentRole = (r.role || 'employe') as RoleOption;
                    return (
                      <tr key={r.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{r.prenom} {r.nom}</div>
                          <div className="text-sm text-gray-500">ID: {r.id}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{r.email}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{r.departement || '-'}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <select
                            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                            value={currentRole}
                            disabled={isSaving}
                            onChange={(e) => {
                              const next = e.target.value as RoleOption;
                              void updateRole(r.id, next);
                            }}
                          >
                            {ROLE_OPTIONS.map((o) => (
                              <option key={o.value} value={o.value}>{o.label}</option>
                            ))}
                          </select>
                          {isSaving && (
                            <span className="ml-3 text-sm text-gray-500">Enregistrement…</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </LayoutFix>
  );
}
