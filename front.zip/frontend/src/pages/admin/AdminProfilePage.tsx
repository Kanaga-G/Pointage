import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../services/authService';
import LayoutFix from '../../components/LayoutFix';

interface AdminProfile {
  id: number;
  nom: string;
  prenom: string;
  email: string;
  role: string;
  telephone?: string;
  adresse?: string;
  date_embauche: string;
  departement: string;
  poste: string;
  permissions: string[];
}

export default function AdminProfilePage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<AdminProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    telephone: '',
    adresse: '',
    departement: '',
    poste: ''
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/admin');
      return;
    }
    loadProfile();
  }, [user, navigate]);

  const loadProfile = async () => {
    try {
      setLoading(true);
      // Simuler la récupération du profil admin
      const mockProfile: AdminProfile = {
        id: user?.id || 1,
        nom: user?.nom || 'Admin',
        prenom: user?.prenom || 'Super',
        email: user?.email || 'admin@xpertpro.com',
        role: user?.role || 'admin',
        telephone: '0612345678',
        adresse: '123 Rue de l\'Admin, 75001 Paris',
        date_embauche: '2023-01-01',
        departement: 'IT',
        poste: 'Administrateur Système',
        permissions: ['*']
      };
      
      setProfile(mockProfile);
      setFormData({
        telephone: mockProfile.telephone || '',
        adresse: mockProfile.adresse || '',
        departement: mockProfile.departement || '',
        poste: mockProfile.poste || ''
      });
    } catch (err) {
      console.error('Erreur lors du chargement du profil:', err);
      setError('Erreur lors du chargement du profil');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    setEditing(true);
    setError(null);
    setSuccess(null);
  };

  const handleCancel = () => {
    setEditing(false);
    setError(null);
    setSuccess(null);
    if (profile) {
      setFormData({
        telephone: profile.telephone || '',
        adresse: profile.adresse || '',
        departement: profile.departement || '',
        poste: profile.poste || ''
      });
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);
      
      // Simuler la sauvegarde
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (profile) {
        setProfile({
          ...profile,
          ...formData
        });
      }
      
      setSuccess('Profil mis à jour avec succès');
      setEditing(false);
    } catch (err) {
      console.error('Erreur lors de la mise à jour:', err);
      setError('Erreur lors de la mise à jour du profil');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <LayoutFix title="Mon Profil">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </LayoutFix>
    );
  }

  if (!profile) {
    return (
      <LayoutFix title="Mon Profil">
        <div className="text-center text-red-600">
          Profil non trouvé
        </div>
      </LayoutFix>
    );
  }

  return (
    <LayoutFix title="Mon Profil">
      <div className="max-w-4xl mx-auto">
        {/* En-tête */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Mon Profil Administrateur
              </h1>
              <p className="text-gray-600">
                {profile.poste} • {profile.departement}
              </p>
            </div>
            <div className="flex space-x-2">
              {!editing && (
                <button
                  onClick={handleEdit}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Modifier
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Messages */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
            {success}
          </div>
        )}

        {/* Photo et informations de base */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center space-x-6 mb-6">
            <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center">
              <span className="text-3xl text-blue-600 font-bold">
                {profile.prenom?.[0]}{profile.nom?.[0]}
              </span>
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                {profile.prenom} {profile.nom}
              </h2>
              <p className="text-gray-600">{profile.poste}</p>
              <span className="inline-block px-3 py-1 rounded-full text-sm bg-purple-100 text-purple-800">
                Administrateur
              </span>
            </div>
          </div>
        </div>

        {/* Informations professionnelles */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations professionnelles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email professionnel
              </label>
              <input
                type="email"
                name="email"
                value={profile.email}
                disabled
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Non modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Rôle
              </label>
              <input
                type="text"
                name="role"
                value="Administrateur"
                disabled
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">Non modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Département
              </label>
              {editing ? (
                <input
                  type="text"
                  name="departement"
                  value={formData.departement}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              ) : (
                <p className="text-gray-900">{profile.departement}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Poste
              </label>
              {editing ? (
                <input
                  type="text"
                  name="poste"
                  value={formData.poste}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              ) : (
                <p className="text-gray-900">{profile.poste}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date d'embauche
              </label>
              <p className="text-gray-900">
                {new Date(profile.date_embauche).toLocaleDateString('fr-FR')}
              </p>
              <p className="text-xs text-gray-500 mt-1">Non modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Permissions
              </label>
              <div className="flex flex-wrap gap-2">
                <span className="inline-block px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                  Accès total
                </span>
                <span className="inline-block px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                  Gestion des utilisateurs
                </span>
                <span className="inline-block px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">
                  Configuration système
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">Non modifiable</p>
            </div>
          </div>
        </div>

        {/* Informations personnelles */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations personnelles</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Téléphone
              </label>
              {editing ? (
                <input
                  type="tel"
                  name="telephone"
                  value={formData.telephone}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              ) : (
                <p className="text-gray-900">{profile.telephone || 'Non renseigné'}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Adresse
              </label>
              {editing ? (
                <textarea
                  name="adresse"
                  value={formData.adresse}
                  onChange={handleInputChange}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              ) : (
                <p className="text-gray-900">{profile.adresse || 'Non renseignée'}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">Modifiable</p>
            </div>
          </div>
        </div>

        {/* Boutons d'action */}
        {editing && (
          <div className="flex justify-end space-x-4">
            <button
              onClick={handleCancel}
              disabled={saving}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
            >
              Annuler
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {saving ? 'Enregistrement...' : 'Enregistrer'}
            </button>
          </div>
        )}
      </div>
    </LayoutFix>
  );
}
