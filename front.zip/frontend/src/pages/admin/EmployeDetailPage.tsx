import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../services/authService';
import { apiClient } from '../../services/apiClient';
import LayoutFix from '../../components/LayoutFix';
import Icon from '../../components/Icons';

interface EmployeDetail {
  id: number;
  matricule?: string;
  nom: string;
  prenom: string;
  email: string;
  role: string;
  departement: string;
  poste: string;
  telephone?: string;
  adresse?: string;
  date_embauche: string;
  statut: string;
  photo?: string;
  contact_urgence_nom?: string;
  contact_urgence_telephone?: string;
  contact_urgence_relation?: string;
}

export default function EmployeDetailPage() {
  const { user } = useAuth();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [employe, setEmploye] = useState<EmployeDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    telephone: '',
    adresse: '',
    departement: '',
    poste: '',
    statut: '',
    contact_urgence_nom: '',
    contact_urgence_telephone: '',
    contact_urgence_relation: ''
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (!['admin', 'super_admin', 'manager', 'hr'].includes(user.role)) {
      navigate(user.role === 'employe' ? '/employe' : '/admin');
      return;
    }
    if (id) {
      loadEmployeDetail(parseInt(id));
    }
  }, [user, id, navigate]);

  const loadEmployeDetail = async (employeId: number) => {
    try {
      setLoading(true);
      setError(null);
      const data = await apiClient.get<EmployeDetail>(`/employes/${employeId}`);
      setEmploye(data);
      setFormData({
        telephone: data.telephone || '',
        adresse: data.adresse || '',
        departement: data.departement || '',
        poste: data.poste || '',
        statut: data.statut || '',
        contact_urgence_nom: data.contact_urgence_nom || '',
        contact_urgence_telephone: data.contact_urgence_telephone || '',
        contact_urgence_relation: data.contact_urgence_relation || ''
      });
    } catch (err: any) {
      console.error('Erreur chargement détail employé:', err);
      setError('Erreur lors du chargement des détails de l\'employé');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    setEditing(true);
    setError(null);
    setSuccess(null);
  };

  const handleCancel = () => {
    setEditing(false);
    setError(null);
    setSuccess(null);
    if (employe) {
      setFormData({
        telephone: employe.telephone || '',
        adresse: employe.adresse || '',
        departement: employe.departement || '',
        poste: employe.poste || '',
        statut: employe.statut || '',
        contact_urgence_nom: employe.contact_urgence_nom || '',
        contact_urgence_telephone: employe.contact_urgence_telephone || '',
        contact_urgence_relation: employe.contact_urgence_relation || ''
      });
    }
  };

  const handleSave = async () => {
    if (!employe) return;

    try {
      setSaving(true);
      setError(null);

      const updateData = {
        ...employe,
        telephone: formData.telephone,
        adresse: formData.adresse,
        departement: formData.departement,
        poste: formData.poste,
        statut: formData.statut,
        contact_urgence_nom: formData.contact_urgence_nom,
        contact_urgence_telephone: formData.contact_urgence_telephone,
        contact_urgence_relation: formData.contact_urgence_relation
      };

      const updatedData = await apiClient.put<EmployeDetail, EmployeDetail>(`/employes/${employe.id}`, updateData);
      
      setEmploye(updatedData);
      setEditing(false);
      setSuccess('Informations mises à jour avec succès');
    } catch (err: any) {
      console.error('Erreur mise à jour employé:', err);
      setError('Erreur lors de la mise à jour des informations');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!employe) return;
    
    if (!confirm('Êtes-vous sûr de vouloir supprimer cet employé ?')) {
      return;
    }

    try {
      setError(null);
      await apiClient.delete(`/employes/${employe.id}`);
      navigate('/admin/employe');
    } catch (err: any) {
      console.error('Erreur suppression employé:', err);
      setError('Erreur lors de la suppression de l\'employé');
    }
  };

  if (loading) {
    return (
      <LayoutFix title="Détail Employé">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </LayoutFix>
    );
  }

  if (!employe) {
    return (
      <LayoutFix title="Détail Employé">
        <div className="text-center text-red-600">
          Employé non trouvé
        </div>
      </LayoutFix>
    );
  }

  return (
    <LayoutFix title="Détail Employé">
      <div className="max-w-4xl mx-auto">
        {/* En-tête */}
        <div className="bg-white shadow-sm rounded-lg p-6 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/admin/employe')}
                className="text-gray-600 hover:text-gray-900"
              >
                <Icon name="arrow-left" className="w-5 h-5 mr-2" />
                Retour
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Détail Employé</h1>
                <p className="text-gray-600">Informations complètes de l'employé</p>
              </div>
            </div>
            <div className="flex space-x-2">
              {!editing ? (
                <>
                  <button
                    onClick={handleEdit}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                  >
                    <Icon name="edit" className="w-4 h-4 mr-2" />
                    Modifier
                  </button>
                  <button
                    onClick={handleDelete}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
                  >
                    <Icon name="trash" className="w-4 h-4 mr-2" />
                    Supprimer
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    {saving ? 'Sauvegarde...' : 'Sauvegarder'}
                  </button>
                  <button
                    onClick={handleCancel}
                    className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400"
                  >
                    Annuler
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Messages */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6">
            {success}
          </div>
        )}

        {/* Photo et informations de base */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center space-x-6 mb-6">
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center">
              {employe.photo ? (
                <img src={employe.photo} alt="Photo" className="w-full h-full rounded-full object-cover" />
              ) : (
                <span className="text-2xl text-gray-600">
                  {employe.prenom?.[0]}{employe.nom?.[0]}
                </span>
              )}
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                {employe.prenom} {employe.nom}
              </h2>
              <p className="text-gray-600">{employe.poste}</p>
              <span className={`inline-block px-3 py-1 rounded-full text-sm ${
                employe.statut === 'actif' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-gray-100 text-gray-800'
              }`}>
                {employe.statut}
              </span>
            </div>
          </div>

          {/* Informations détaillées */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Identifiants</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700">ID</label>
                  <div className="mt-1 p-3 bg-gray-50 border border-gray-200 rounded-lg">
                    <div className="text-lg font-mono font-semibold text-blue-600">
                      {employe.id}
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">ID unique système</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Matricule</label>
                  <div className="mt-1 p-3 bg-gray-50 border border-gray-200 rounded-lg">
                    <div className="text-lg font-mono font-semibold text-green-600">
                      {employe.matricule || 'Non assigné'}
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Matricule employé</p>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations personnelles</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <p className="text-gray-900">{employe.email}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Téléphone</label>
                  {editing ? (
                    <input
                      type="tel"
                      value={formData.telephone}
                      onChange={(e) => setFormData({...formData, telephone: e.target.value})}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2"
                    />
                  ) : (
                    <p className="text-gray-900">{employe.telephone || 'Non spécifié'}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Adresse</label>
                  {editing ? (
                    <textarea
                      value={formData.adresse}
                      onChange={(e) => setFormData({...formData, adresse: e.target.value})}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2"
                      rows={3}
                    />
                  ) : (
                    <p className="text-gray-900">{employe.adresse || 'Non spécifiée'}</p>
                  )}
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations professionnelles</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Département</label>
                  {editing ? (
                    <input
                      type="text"
                      value={formData.departement}
                      onChange={(e) => setFormData({...formData, departement: e.target.value})}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2"
                    />
                  ) : (
                    <p className="text-gray-900">{employe.departement}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Poste</label>
                  {editing ? (
                    <input
                      type="text"
                      value={formData.poste}
                      onChange={(e) => setFormData({...formData, poste: e.target.value})}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2"
                    />
                  ) : (
                    <p className="text-gray-900">{employe.poste}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Statut</label>
                  {editing ? (
                    <select
                      value={formData.statut}
                      onChange={(e) => setFormData({...formData, statut: e.target.value})}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2"
                    >
                      <option value="actif">Actif</option>
                      <option value="inactif">Inactif</option>
                    </select>
                  ) : (
                    <span className={`inline-block px-3 py-1 rounded-full text-sm ${
                      employe.statut === 'actif' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {employe.statut}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Contact d'urgence */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact d'urgence</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">Nom</label>
              {editing ? (
                <input
                  type="text"
                  value={formData.contact_urgence_nom}
                  onChange={(e) => setFormData({...formData, contact_urgence_nom: e.target.value})}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2"
                />
              ) : (
                <p className="text-gray-900">{employe.contact_urgence_nom || 'Non spécifié'}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Téléphone</label>
              {editing ? (
                <input
                  type="tel"
                  value={formData.contact_urgence_telephone}
                  onChange={(e) => setFormData({...formData, contact_urgence_telephone: e.target.value})}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2"
                />
              ) : (
                <p className="text-gray-900">{employe.contact_urgence_telephone || 'Non spécifié'}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Relation</label>
              {editing ? (
                <input
                  type="text"
                  value={formData.contact_urgence_relation}
                  onChange={(e) => setFormData({...formData, contact_urgence_relation: e.target.value})}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2"
                />
              ) : (
                <p className="text-gray-900">{employe.contact_urgence_relation || 'Non spécifié'}</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </LayoutFix>
  );
}
