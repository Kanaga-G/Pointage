import React, { useState, useEffect } from 'react'
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Briefcase, 
  Edit, 
  Save, 
  X, 
  Clock,
  FileText,
  Download,
  ArrowLeft
} from 'lucide-react'
import { useNavigate, useParams } from 'react-router-dom'
import Header from '../components/layout/Header'
import Sidebar from '../components/layout/Sidebar'

interface EmployeDetails {
  id: number
  prenom: string
  nom: string
  email: string
  telephone?: string
  poste: string
  departement: string
  statut: string
  date_embauche?: string
  contrat_type?: string
  contrat_duree?: string
  salaire?: number
  adresse?: string
  photo?: string
  // Informations professionnelles (non modifiables par l'employé)
  informations_professionnelles: {
    matricule: string
    numero_secu: string
    iban: string
    banque: string
    taux_horaire: number
    categorie: string
    echelon: string
    manager_id: number
    manager_nom: string
  }
  // Historique des pointages
  pointages: Array<{
    id: number
    date: string
    arrivee: string | null
    depart: string | null
    statut: 'normal' | 'retard' | 'absent'
  }>
  // Historique des demandes
  demandes: Array<{
    id: number
    type: string
    date_debut: string
    date_fin: string
    motif: string
    statut: string
    created_at: string
  }>
}

export default function EmployeDetails() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [activeTab, setActiveTab] = useState<'personnel' | 'professionnel' | 'pointages' | 'demandes'>('personnel')
  
  const [employe, setEmploye] = useState<EmployeDetails | null>(null)
  const [formData, setFormData] = useState({
    telephone: '',
    adresse: '',
    email: ''
  })

  useEffect(() => {
    if (id) {
      loadEmployeDetails(parseInt(id))
    }
  }, [id])

  const loadEmployeDetails = async (employeId: number) => {
    try {
      setLoading(true)
      // Simuler un appel API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const mockData: EmployeDetails = {
        id: employeId,
        prenom: 'Jean',
        nom: 'Dupont',
        email: 'jean.dupont@email.com',
        telephone: '0123456789',
        poste: 'Développeur Senior',
        departement: 'IT',
        statut: 'actif',
        date_embauche: '2022-01-15',
        contrat_type: 'CDI',
        contrat_duree: 'indéterminé',
        salaire: 45000,
        adresse: '123 Rue de la République, 75001 Paris',
        photo: '',
        informations_professionnelles: {
          matricule: 'EMP001',
          numero_secu: '1 23 45 67 890 123 456',
          iban: 'FR76 3000 4000 4000 4000 4000 123',
          banque: 'BNP Paribas',
          taux_horaire: 25.50,
          categorie: 'A',
          echelon: '3',
          manager_id: 2,
          manager_nom: 'Marie Martin'
        },
        pointages: [
          { id: 1, date: '2024-01-15', arrivee: '08:45', depart: '17:30', statut: 'normal' },
          { id: 2, date: '2024-01-14', arrivee: '09:15', depart: '17:45', statut: 'retard' },
          { id: 3, date: '2024-01-13', arrivee: '08:30', depart: '17:00', statut: 'normal' },
          { id: 4, date: '2024-01-12', arrivee: '08:00', depart: '17:15', statut: 'normal' },
          { id: 5, date: '2024-01-11', arrivee: '08:20', depart: '17:30', statut: 'normal' }
        ],
        demandes: [
          {
            id: 1,
            type: 'congé',
            date_debut: '2024-01-20',
            date_fin: '2024-01-22',
            motif: 'Vacances familiales',
            statut: 'approuvée',
            created_at: '2024-01-10'
          },
          {
            id: 2,
            type: 'permission',
            date_debut: '2024-01-16',
            date_fin: '2024-01-16',
            motif: 'Rendez-vous médical',
            statut: 'en_attente',
            created_at: '2024-01-14'
          }
        ]
      }
      
      setEmploye(mockData)
      setFormData({
        telephone: mockData.telephone || '',
        adresse: mockData.adresse || '',
        email: mockData.email
      })
    } catch (error) {
      console.error('Erreur lors du chargement des détails:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    if (!employe) return
    
    try {
      setSaving(true)
      // Simuler un appel API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setEmploye({
        ...employe,
        telephone: formData.telephone,
        adresse: formData.adresse,
        email: formData.email
      })
      
      setEditing(false)
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error)
    } finally {
      setSaving(false)
    }
  }

  const handleCancel = () => {
    if (employe) {
      setFormData({
        telephone: employe.telephone || '',
        adresse: employe.adresse || '',
        email: employe.email
      })
    }
    setEditing(false)
  }

  const currentUser = {
    id: employe?.id || 1,
    prenom: employe?.prenom || 'Employé',
    nom: employe?.nom || 'User',
    email: employe?.email || 'email@example.com',
    role: 'employee',
    avatar: ''
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!employe) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Employé non trouvé</h2>
          <button
            onClick={() => navigate('/admin/employes')}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à la liste
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} userRole="admin" />
      
      <div className={`transition-all duration-300 ${sidebarOpen ? 'lg:ml-64' : ''}`}>
        <Header 
          user={currentUser}
          title={`Profil de ${employe.prenom} ${employe.nom}`}
          onSidebarToggle={() => setSidebarOpen(!sidebarOpen)}
          sidebarOpen={sidebarOpen}
        />
        
        <main className="p-6">
          {/* Bouton retour */}
          <button
            onClick={() => navigate('/admin/employes')}
            className="inline-flex items-center px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-6 transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Retour à la liste des employés
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Carte profil */}
            <div className="lg:col-span-1">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <div className="text-center">
                  <div className="h-24 w-24 mx-auto bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mb-4">
                    {employe.prenom[0]}{employe.nom[0]}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    {employe.prenom} {employe.nom}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">{employe.poste}</p>
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                    employe.statut === 'actif' 
                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                      : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                  }`}>
                    {employe.statut === 'actif' ? 'Actif' : 'Inactif'}
                  </span>
                </div>
                
                <div className="mt-6 space-y-3">
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <Briefcase className="h-4 w-4 mr-2" />
                    {employe.departement}
                  </div>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <Calendar className="h-4 w-4 mr-2" />
                    Depuis le {new Date(employe.date_embauche!).toLocaleDateString('fr-FR')}
                  </div>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                    <FileText className="h-4 w-4 mr-2" />
                    {employe.contrat_type} - {employe.contrat_duree}
                  </div>
                </div>
              </div>
            </div>

            {/* Contenu principal */}
            <div className="lg:col-span-2">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
                {/* Tabs */}
                <div className="border-b border-gray-200 dark:border-gray-700">
                  <nav className="flex space-x-8 px-6">
                    {[
                      { id: 'personnel', label: 'Informations personnelles' },
                      { id: 'professionnel', label: 'Informations professionnelles' },
                      { id: 'pointages', label: 'Historique des pointages' },
                      { id: 'demandes', label: 'Mes demandes' }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                          activeTab === tab.id
                            ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                            : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </nav>
                </div>

                <div className="p-6">
                  {/* Actions */}
                  {activeTab === 'personnel' && (
                    <div className="flex justify-end mb-4">
                      {!editing ? (
                        <button
                          onClick={() => setEditing(true)}
                          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Modifier
                        </button>
                      ) : (
                        <div className="flex space-x-3">
                          <button
                            onClick={handleCancel}
                            disabled={saving}
                            className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50"
                          >
                            <X className="h-4 w-4 mr-2" />
                            Annuler
                          </button>
                          <button
                            onClick={handleSave}
                            disabled={saving}
                            className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                          >
                            {saving ? (
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            ) : (
                              <Save className="h-4 w-4 mr-2" />
                            )}
                            {saving ? 'Sauvegarde...' : 'Sauvegarder'}
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Contenu des tabs */}
                  {activeTab === 'personnel' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          value={editing ? formData.email : employe.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          disabled={!editing}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:bg-gray-50 dark:disabled:bg-gray-800 disabled:text-gray-500 dark:disabled:text-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Téléphone
                        </label>
                        <input
                          type="tel"
                          value={editing ? formData.telephone : employe.telephone}
                          onChange={(e) => setFormData({...formData, telephone: e.target.value})}
                          disabled={!editing}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:bg-gray-50 dark:disabled:bg-gray-800 disabled:text-gray-500 dark:disabled:text-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Adresse
                        </label>
                        <textarea
                          value={editing ? formData.adresse : employe.adresse}
                          onChange={(e) => setFormData({...formData, adresse: e.target.value})}
                          disabled={!editing}
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white disabled:bg-gray-50 dark:disabled:bg-gray-800 disabled:text-gray-500 dark:disabled:text-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>
                    </div>
                  )}

                  {activeTab === 'professionnel' && (
                    <div className="space-y-6">
                      <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                        <p className="text-sm text-yellow-800 dark:text-yellow-200">
                          <strong>Note:</strong> Ces informations sont gérées par l'administrateur et ne sont pas modifiables par l'employé.
                        </p>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Matricule
                          </label>
                          <input
                            type="text"
                            value={employe.informations_professionnelles.matricule}
                            disabled
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Numéro de sécurité sociale
                          </label>
                          <input
                            type="text"
                            value={employe.informations_professionnelles.numero_secu}
                            disabled
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            IBAN
                          </label>
                          <input
                            type="text"
                            value={employe.informations_professionnelles.iban}
                            disabled
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Banque
                          </label>
                          <input
                            type="text"
                            value={employe.informations_professionnelles.banque}
                            disabled
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Taux horaire
                          </label>
                          <input
                            type="text"
                            value={`${employe.informations_professionnelles.taux_horaire}€/h`}
                            disabled
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Manager
                          </label>
                          <input
                            type="text"
                            value={employe.informations_professionnelles.manager_nom}
                            disabled
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-800 text-gray-500 dark:text-gray-400"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === 'pointages' && (
                    <div>
                      <div className="flex justify-between items-center mb-4">
                        <h4 className="text-lg font-medium text-gray-900 dark:text-white">Historique des pointages</h4>
                        <button className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                          <Download className="h-4 w-4 mr-2" />
                          Exporter
                        </button>
                      </div>
                      
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead className="bg-gray-50 dark:bg-gray-700">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Date
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Arrivée
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Départ
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Statut
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            {employe.pointages.map((pointage) => (
                              <tr key={pointage.id} className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                                  {new Date(pointage.date).toLocaleDateString('fr-FR')}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                                  {pointage.arrivee || '-'}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                                  {pointage.depart || '-'}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                                    pointage.statut === 'normal' 
                                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                                      : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                                  }`}>
                                    {pointage.statut === 'normal' ? 'Normal' : 'Retard'}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {activeTab === 'demandes' && (
                    <div>
                      <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Mes demandes</h4>
                      
                      <div className="space-y-4">
                        {employe.demandes.map((demande) => (
                          <div key={demande.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="flex items-center space-x-3">
                                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                                    demande.type === 'congé' 
                                      ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                                      : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                                  }`}>
                                    {demande.type}
                                  </span>
                                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                                    demande.statut === 'approuvée'
                                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                                      : demande.statut === 'rejetée'
                                      ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                                      : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                                  }`}>
                                    {demande.statut}
                                  </span>
                                </div>
                                <p className="text-sm text-gray-900 dark:text-white mt-2">{demande.motif}</p>
                                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                                  Du {new Date(demande.date_debut).toLocaleDateString('fr-FR')} au {new Date(demande.date_fin).toLocaleDateString('fr-FR')}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
