import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/pages/LoginPage.css';

interface User {
  id: string;
  email: string;
  password: string;
  name: string;
  role: 'employee' | 'admin';
  department: string;
  avatar?: string;
}

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginType, setLoginType] = useState<'employee' | 'admin'>('employee');

  // Base de données simulée
  const mockUsers: User[] = [
    {
      id: '1',
      email: 'jean.dupont@xpertpro.com',
      password: 'employee123',
      name: 'Jean Dupont',
      role: 'employee',
      department: 'Développement',
      avatar: 'JD'
    },
    {
      id: '2',
      email: 'marie.martin@xpertpro.com',
      password: 'employee123',
      name: 'Marie Martin',
      role: 'employee',
      department: 'Marketing',
      avatar: 'MM'
    },
    {
      id: '3',
      email: 'admin@xpertpro.com',
      password: 'admin123',
      name: 'Administrateur',
      role: 'admin',
      department: 'Administration',
      avatar: 'AD'
    }
  ];

  useEffect(() => {
    // Récupérer le type de login depuis l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const type = urlParams.get('type') as 'employee' | 'admin';
    if (type) {
      setLoginType(type);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      // Simuler une connexion API
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Vérifier les identifiants
      const user = mockUsers.find(u => 
        u.email === formData.email.toLowerCase() && 
        u.password === formData.password
      );

      if (user) {
        // Vérifier si le type de login correspond au rôle
        if ((loginType === 'employee' && user.role !== 'employee') ||
            (loginType === 'admin' && user.role !== 'admin')) {
          setError(`Ce compte n'a pas les droits d'accès ${loginType === 'employee' ? 'employé' : 'administrateur'}`);
          return;
        }

        // Stocker les infos utilisateur
        localStorage.setItem('user', JSON.stringify({
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          department: user.department,
          avatar: user.avatar
        }));

        // Rediriger vers le dashboard approprié
        if (user.role === 'admin') {
          navigate('/admin/dashboard');
        } else {
          navigate('/employee/dashboard');
        }
      } else {
        setError('Email ou mot de passe incorrect');
      }
    } catch (err) {
      setError('Erreur de connexion. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  const switchLoginType = (type: 'employee' | 'admin') => {
    setLoginType(type);
    setError('');
    setFormData({ email: '', password: '' });
  };

  return (
    <div className="login-page">
      <div className="login-background">
        <div className="animated-shapes">
          <div className="shape shape-1"></div>
          <div className="shape shape-2"></div>
          <div className="shape shape-3"></div>
        </div>
      </div>

      <div className="login-container">
        <div className="login-card">
          <div className="login-header">
            <div className="login-logo">
              <i className="fas fa-qrcode"></i>
              <span>Xpert Pro</span>
            </div>
            <h2>Connexion {loginType === 'admin' ? 'Administrateur' : 'Employé'}</h2>
            <p>Accédez à votre espace de travail</p>
          </div>

          <div className="login-tabs">
            <button 
              className={`tab-btn ${loginType === 'employee' ? 'active' : ''}`}
              onClick={() => switchLoginType('employee')}
            >
              <i className="fas fa-user-tie"></i>
              Employé
            </button>
            <button 
              className={`tab-btn ${loginType === 'admin' ? 'active' : ''}`}
              onClick={() => switchLoginType('admin')}
            >
              <i className="fas fa-shield-alt"></i>
              Admin
            </button>
          </div>

          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <label htmlFor="email">
                <i className="fas fa-envelope"></i>
                Email professionnel
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder={loginType === 'admin' ? 'admin@xpertpro.com' : 'jean.dupont@xpertpro.com'}
                required
                disabled={isLoading}
              />
            </div>

            <div className="form-group">
              <label htmlFor="password">
                <i className="fas fa-lock"></i>
                Mot de passe
              </label>
              <div className="password-input">
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder={loginType === 'admin' ? 'admin123' : 'employee123'}
                  required
                  disabled={isLoading}
                />
                <button
                  type="button"
                  className="toggle-password"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={isLoading}
                >
                  <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
              </div>
            </div>

            {error && (
              <div className="error-message">
                <i className="fas fa-exclamation-triangle"></i>
                {error}
              </div>
            )}

            <button 
              type="submit" 
              className="login-btn"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <i className="fas fa-spinner fa-spin"></i>
                  Connexion en cours...
                </>
              ) : (
                <>
                  <i className="fas fa-sign-in-alt"></i>
                  Se connecter
                </>
              )}
            </button>
          </form>

          <div className="login-footer">
            <div className="demo-accounts">
              <h4>Comptes de démonstration</h4>
              <div className="demo-accounts-grid">
                <div className="demo-account">
                  <strong>Employé:</strong>
                  <div>jean.dupont@xpertpro.com</div>
                  <div>Mot de passe: employee123</div>
                </div>
                <div className="demo-account">
                  <strong>Admin:</strong>
                  <div>admin@xpertpro.com</div>
                  <div>Mot de passe: admin123</div>
                </div>
              </div>
            </div>
            
            <div className="login-links">
              <a href="#" className="forgot-password">
                <i className="fas fa-question-circle"></i>
                Mot de passe oublié ?
              </a>
              <a href="/" className="back-home">
                <i className="fas fa-arrow-left"></i>
                Retour à l'accueil
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
