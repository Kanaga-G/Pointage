import React, { useState, useEffect } from 'react'
import { Search, Users, Clock, Calendar, AlertCircle, TrendingUp, Plus, Edit, Trash2, Eye, CheckCircle, XCircle, UserCheck, UserX, Activity, BarChart3, FileText, Settings, LogOut, Menu, X, Filter, Download, RefreshCw, Bell, ChevronDown } from 'lucide-react'

interface StatCard {
  title: string
  value: number | string
  icon: React.ReactNode
  color: string
  trend?: number
}

interface Employe {
  id: number
  prenom: string
  nom: string
  email: string
  departement: string
  poste: string
  telephone: string
  date_embauche: string
  statut: string
}

interface Pointage {
  id: number
  employe_nom: string
  date_heure: string
  type: string
  departement: string
  statut: string
}

interface Demande {
  id: number
  employe_nom: string
  type: string
  date_debut: string
  date_fin: string
  motif: string
  statut: string
  created_at: string
}

interface Retard {
  id: number
  employe_nom: string
  date: string
  heure_arrivee: string
  retard_minutes: number
  motif: string
  statut: string
}

export default function AdminDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeSection, setActiveSection] = useState('overview')
  const [searchTerm, setSearchTerm] = useState('')
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)
  const [editingItem, setEditingItem] = useState<any>(null)
  
  // États pour les données
  const [stats, setStats] = useState({
    total_employes: 0,
    present_today: 0,
    absents_today: 0,
    retards_today: 0,
    total_pointages: 0,
    demandes_en_attente: 0,
    heures_mensuelles: 0
  })
  
  const [employes, setEmployes] = useState<Employe[]>([])
  const [pointages, setPointages] = useState<Pointage[]>([])
  const [demandes, setDemandes] = useState<Demande[]>([])
  const [retards, setRetards] = useState<Retard[]>([])

  // Charger les données du dashboard
  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    try {
      setLoading(true)
      // Simuler des données réelles
      const mockStats = {
        total_employes: 45,
        present_today: 38,
        absents_today: 7,
        retards_today: 3,
        total_pointages: 156,
        demandes_en_attente: 12,
        heures_mensuelles: 892
      }

      const mockEmployes: Employe[] = [
        { id: 1, prenom: 'Jean', nom: 'Dupont', email: 'jean.dupont@email.com', departement: 'IT', poste: 'Développeur', telephone: '0123456789', date_embauche: '2023-01-15', statut: 'actif' },
        { id: 2, prenom: 'Marie', nom: 'Martin', email: 'marie.martin@email.com', departement: 'RH', poste: 'Responsable RH', telephone: '0123456780', date_embauche: '2022-06-20', statut: 'actif' },
        { id: 3, prenom: 'Pierre', nom: 'Durand', email: 'pierre.durand@email.com', departement: 'Finance', poste: 'Comptable', telephone: '0123456781', date_embauche: '2021-11-10', statut: 'actif' },
      ]

      const mockPointages: Pointage[] = [
        { id: 1, employe_nom: 'Jean Dupont', date_heure: '2024-01-15 08:45:00', type: 'arrivée', departement: 'IT', statut: 'normal' },
        { id: 2, employe_nom: 'Marie Martin', date_heure: '2024-01-15 09:15:00', type: 'arrivée', departement: 'RH', statut: 'retard' },
        { id: 3, employe_nom: 'Pierre Durand', date_heure: '2024-01-15 08:30:00', type: 'arrivée', departement: 'Finance', statut: 'normal' },
      ]

      const mockDemandes: Demande[] = [
        { id: 1, employe_nom: 'Jean Dupont', type: 'congé', date_debut: '2024-01-20', date_fin: '2024-01-25', motif: 'Vacances', statut: 'en_attente', created_at: '2024-01-10' },
        { id: 2, employe_nom: 'Marie Martin', type: 'permission', date_debut: '2024-01-16', date_fin: '2024-01-16', motif: 'Rendez-vous médical', statut: 'approuvée', created_at: '2024-01-12' },
      ]

      const mockRetards: Retard[] = [
        { id: 1, employe_nom: 'Marie Martin', date: '2024-01-15', heure_arrivee: '09:15', retard_minutes: 15, motif: 'Circulation dense', statut: 'justifié' },
        { id: 2, employe_nom: 'Pierre Durand', date: '2024-01-14', heure_arrivee: '09:30', retard_minutes: 30, motif: 'Problème de transport', statut: 'en_attente' },
      ]

      setStats(mockStats)
      setEmployes(mockEmployes)
      setPointages(mockPointages)
      setDemandes(mockDemandes)
      setRetards(mockRetards)
    } catch (error) {
      console.error('Erreur lors du chargement des données:', error)
    } finally {
      setLoading(false)
    }
  }

  const statCards: StatCard[] = [
    { title: 'Total Employés', value: stats.total_employes, icon: <Users className="w-5 h-5" />, color: 'bg-blue-500' },
    { title: 'Présents Aujourd\'hui', value: stats.present_today, icon: <UserCheck className="w-5 h-5" />, color: 'bg-green-500' },
    { title: 'Absents Aujourd\'hui', value: stats.absents_today, icon: <UserX className="w-5 h-5" />, color: 'bg-red-500' },
    { title: 'Retards du Jour', value: stats.retards_today, icon: <Clock className="w-5 h-5" />, color: 'bg-orange-500' },
    { title: 'Total Pointages', value: stats.total_pointages, icon: <Activity className="w-5 h-5" />, color: 'bg-purple-500' },
    { title: 'Demandes en Attente', value: stats.demandes_en_attente, icon: <FileText className="w-5 h-5" />, color: 'bg-yellow-500' },
    { title: 'Heures Mensuelles', value: `${stats.heures_mensuelles}h`, icon: <BarChart3 className="w-5 h-5" />, color: 'bg-indigo-500' },
  ]

  const menuItems = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: <BarChart3 className="w-5 h-5" /> },
    { id: 'employes', label: 'Gestion des Employés', icon: <Users className="w-5 h-5" /> },
    { id: 'pointages', label: 'Pointages', icon: <Clock className="w-5 h-5" /> },
    { id: 'demandes', label: 'Demandes', icon: <FileText className="w-5 h-5" /> },
    { id: 'retards', label: 'Retards', icon: <AlertCircle className="w-5 h-5" /> },
    { id: 'calendrier', label: 'Calendrier', icon: <Calendar className="w-5 h-5" /> },
    { id: 'rapports', label: 'Rapports', icon: <TrendingUp className="w-5 h-5" /> },
    { id: 'parametres', label: 'Paramètres', icon: <Settings className="w-5 h-5" /> },
  ]

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {statCards.map((card, index) => (
                <div key={index} className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">{card.title}</p>
                      <p className="text-2xl font-bold text-gray-900">{card.value}</p>
                    </div>
                    <div className={`${card.color} text-white p-3 rounded-lg`}>
                      {card.icon}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">Derniers Pointages</h3>
                <div className="space-y-3">
                  {pointages.slice(0, 5).map((pointage) => (
                    <div key={pointage.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div>
                        <p className="font-medium">{pointage.employe_nom}</p>
                        <p className="text-sm text-gray-600">{pointage.date_heure}</p>
                      </div>
                      <span className={`px-2 py-1 rounded text-xs ${
                        pointage.statut === 'normal' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {pointage.statut}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">Demandes Récentes</h3>
                <div className="space-y-3">
                  {demandes.slice(0, 5).map((demande) => (
                    <div key={demande.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div>
                        <p className="font-medium">{demande.employe_nom}</p>
                        <p className="text-sm text-gray-600">{demande.type} - {demande.motif}</p>
                      </div>
                      <span className={`px-2 py-1 rounded text-xs ${
                        demande.statut === 'approuvée' ? 'bg-green-100 text-green-800' : 
                        demande.statut === 'en_attente' ? 'bg-yellow-100 text-yellow-800' : 
                        'bg-red-100 text-red-800'
                      }`}>
                        {demande.statut}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )

      case 'employes':
        return (
          <div className="bg-white rounded-lg shadow">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold">Gestion des Employés</h2>
                <button
                  onClick={() => setShowAddModal(true)}
                  className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Ajouter un Employé
                </button>
              </div>
              <div className="mt-4 flex items-center gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <input
                    type="text"
                    placeholder="Rechercher un employé..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <Filter className="w-4 h-4" />
                  Filtrer
                </button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employé</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Département</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Poste</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {employes.map((employe) => (
                    <tr key={employe.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                            <span className="text-sm font-medium">{employe.prenom[0]}{employe.nom[0]}</span>
                          </div>
                          <div className="ml-3">
                            <div className="text-sm font-medium text-gray-900">{employe.prenom} {employe.nom}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{employe.email}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{employe.departement}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{employe.poste}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          employe.statut === 'actif' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {employe.statut}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex items-center gap-2">
                          <button className="text-blue-600 hover:text-blue-900">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => setEditingItem(employe)}
                            className="text-indigo-600 hover:text-indigo-900"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="text-red-600 hover:text-red-900">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )

      case 'pointages':
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Gestion des Pointages</h2>
              <div className="flex items-center gap-2">
                <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <Download className="w-4 h-4" />
                  Exporter
                </button>
                <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <RefreshCw className="w-4 h-4" />
                  Actualiser
                </button>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employé</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date/Heure</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Département</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {pointages.map((pointage) => (
                    <tr key={pointage.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{pointage.employe_nom}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{pointage.date_heure}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{pointage.type}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{pointage.departement}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          pointage.statut === 'normal' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {pointage.statut}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )

      case 'demandes':
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-6">Gestion des Demandes</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Demandes en Attente</h3>
                <div className="space-y-3">
                  {demandes.filter(d => d.statut === 'en_attente').map((demande) => (
                    <div key={demande.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{demande.employe_nom}</h4>
                        <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded">En attente</span>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{demande.type}: {demande.motif}</p>
                      <p className="text-sm text-gray-500">Du {demande.date_debut} au {demande.date_fin}</p>
                      <div className="flex items-center gap-2 mt-3">
                        <button className="flex items-center gap-1 px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600">
                          <CheckCircle className="w-3 h-3" />
                          Approuver
                        </button>
                        <button className="flex items-center gap-1 px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600">
                          <XCircle className="w-3 h-3" />
                          Rejeter
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium mb-4">Historique</h3>
                <div className="space-y-3">
                  {demandes.filter(d => d.statut !== 'en_attente').map((demande) => (
                    <div key={demande.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{demande.employe_nom}</h4>
                        <span className={`px-2 py-1 text-xs rounded ${
                          demande.statut === 'approuvée' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {demande.statut}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{demande.type}: {demande.motif}</p>
                      <p className="text-sm text-gray-500">Du {demande.date_debut} au {demande.date_fin}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )

      case 'retards':
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-6">Gestion des Retards</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employé</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Heure d'arrivée</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Retard (min)</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Motif</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {retards.map((retard) => (
                    <tr key={retard.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{retard.employe_nom}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{retard.date}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{retard.heure_arrivee}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{retard.retard_minutes}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{retard.motif}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          retard.statut === 'justifié' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {retard.statut}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        {retard.statut === 'en_attente' && (
                          <div className="flex items-center gap-2">
                            <button className="text-green-600 hover:text-green-900">
                              <CheckCircle className="w-4 h-4" />
                            </button>
                            <button className="text-red-600 hover:text-red-900">
                              <XCircle className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )

      default:
        return (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">{menuItems.find(item => item.id === activeSection)?.label}</h2>
            <p className="text-gray-600">Cette section est en cours de développement.</p>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
              >
                {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
              <h1 className="ml-4 text-xl font-semibold text-gray-900">Dashboard Administrateur</h1>
            </div>
            <div className="flex items-center gap-4">
              <button className="p-2 rounded-full text-gray-400 hover:text-gray-500 hover:bg-gray-100">
                <Bell className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">A</span>
                </div>
                <span className="text-sm font-medium text-gray-700">Admin</span>
                <ChevronDown className="w-4 h-4 text-gray-400" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`${sidebarOpen ? 'w-64' : 'w-0'} transition-all duration-300 bg-white shadow-lg overflow-hidden`}>
          <nav className="mt-5 px-2">
            <div className="space-y-1">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`${
                    activeSection === item.id
                      ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  } group flex items-center px-2 py-2 text-sm font-medium rounded-md w-full text-left`}
                >
                  {item.icon}
                  <span className="ml-3">{item.label}</span>
                </button>
              ))}
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <main className={`flex-1 p-6 ${sidebarOpen ? 'ml-0' : ''}`}>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
            </div>
          ) : (
            renderContent()
          )}
        </main>
      </div>
    </div>
  )
}
