import React from "react";
import { Link } from "react-router-dom";

export const HomePage: React.FC = () => {
  return (
    <div className="page page-home">
      <section className="hero">
        <h1>Tableau de bord Pointage &amp; Badges</h1>
        <p className="hero-subtitle">
          Nouvelle interface 100% TypeScript / React, basée sur ton ancien projet PHP.
        </p>
        <div className="hero-actions">
          <Link to="/admin" className="btn btn-primary">
            Accéder à l&apos;espace Admin
          </Link>
          <Link to="/employe" className="btn btn-secondary">
            Accéder à l&apos;espace Employé
          </Link>
          <Link to="/scan" className="btn btn-ghost">
            Ouvrir le scanner de badges
          </Link>
        </div>
      </section>
    </div>
  );
};

