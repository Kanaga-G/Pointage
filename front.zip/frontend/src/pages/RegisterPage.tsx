import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../services/auth'

interface RegisterFormData {
  nom: string
  prenom: string
  email: string
  password: string
  confirmPassword: string
  role: 'admin' | 'employe'
  telephone?: string
  departement?: string
}

export default function RegisterPage() {
  const navigate = useNavigate()
  const { loading } = useAuth()
  const [formData, setFormData] = useState<RegisterFormData>({
    nom: '',
    prenom: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'employe',
    telephone: '',
    departement: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [step, setStep] = useState(1) // Étape 1: Vérification admin, Étape 2: Formulaire

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
    
    // Effacer les messages lors de la saisie
    if (error) setError(null)
    if (success) setSuccess(null)
  }

  const validateStep1 = () => {
    // En production, cette étape vérifierait si l'utilisateur est admin
    // Pour le développement, on passe directement à l'étape 2
    if (true) { // Toujours autoriser en développement
      setStep(2)
      return
    }
    
    // Logique de vérification admin à implémenter
    // Pour l'instant, on demande un code admin
    const adminCode = prompt('Entrez le code administrateur pour créer un compte:')
    if (adminCode === 'ADMIN2024') {
      setStep(2)
    } else {
      setError('Code administrateur incorrect')
    }
  }

  const validateForm = () => {
    if (!formData.nom || !formData.prenom || !formData.email || !formData.password) {
      setError('Veuillez remplir tous les champs obligatoires.')
      return false
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setError('Format d\'email invalide.')
      return false
    }

    if (formData.password.length < 6) {
      setError('Le mot de passe doit contenir au moins 6 caractères.')
      return false
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Les mots de passe ne correspondent pas.')
      return false
    }

    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(null)

    if (!validateForm()) {
      return
    }

    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Erreur lors de l\'inscription')
      }

      setSuccess('Compte créé avec succès ! Redirection vers la page de connexion...')
      
      // Redirection après 2 secondes
      setTimeout(() => {
        navigate('/login')
      }, 2000)

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur technique est survenue.')
    }
  }

  if (step === 1) {
    return (
      <div className="min-vh-100 d-flex justify-content-center align-items-center bg-light">
        <div className="card shadow-lg p-4 rounded-4" style={{ maxWidth: '420px', width: '100%' }}>
          <div className="text-center mb-4">
            <div className="mb-3">
              <div className="logo-dot mx-auto" style={{ width: '60px', height: '60px' }} />
            </div>
            <h3 className="fw-bold mt-2">Création de Compte</h3>
            <p className="text-muted">Vérification d'accès administrateur</p>
          </div>

          {error && (
            <div className="alert alert-danger d-flex align-items-center mb-3" role="alert">
              <i className="fas fa-exclamation-circle me-2 fs-5"></i>
              <div>{error}</div>
            </div>
          )}

          <div className="text-center">
            <p className="mb-4">
              Seuls les administrateurs peuvent créer de nouveaux comptes.
            </p>
            <button 
              className="btn btn-primary w-100"
              onClick={validateStep1}
              disabled={loading}
            >
              {loading ? (
                <>
                  <i className="fas fa-spinner fa-spin me-2"></i>
                  Vérification...
                </>
              ) : (
                <>
                  <i className="fas fa-shield-alt me-2"></i>
                  Continuer
                </>
              )}
            </button>
          </div>

          <div className="text-center mt-4">
            <Link to="/login" className="link-dark text-decoration-none">
              <i className="fas fa-arrow-left me-2"></i>
              Retour à la connexion
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-vh-100 d-flex justify-content-center align-items-center bg-light">
      <div className="card shadow-lg p-4 rounded-4" style={{ maxWidth: '500px', width: '100%' }}>
        
        {/* En-tête */}
        <div className="text-center mb-4">
          <div className="mb-3">
            <div className="logo-dot mx-auto" style={{ width: '60px', height: '60px' }} />
          </div>
          <h3 className="fw-bold mt-2">Créer un Compte</h3>
          <p className="text-muted">Ajouter un nouvel utilisateur</p>
        </div>

        {/* Messages */}
        {error && (
          <div className="alert alert-danger d-flex align-items-center mb-3" role="alert">
            <i className="fas fa-exclamation-circle me-2 fs-5"></i>
            <div>{error}</div>
          </div>
        )}
        
        {success && (
          <div className="alert alert-success d-flex align-items-center mb-3" role="alert">
            <i className="fas fa-check-circle me-2 fs-5"></i>
            <div>{success}</div>
          </div>
        )}

        {/* Formulaire */}
        <form onSubmit={handleSubmit} autoComplete="off" noValidate>
          
          {/* Informations personnelles */}
          <div className="row mb-3">
            <div className="col-md-6">
              <label htmlFor="prenom" className="form-label fw-semibold">Prénom *</label>
              <input
                type="text"
                id="prenom"
                name="prenom"
                className="form-control"
                placeholder="Jean"
                required
                value={formData.prenom}
                onChange={handleInputChange}
                disabled={loading}
              />
            </div>
            <div className="col-md-6">
              <label htmlFor="nom" className="form-label fw-semibold">Nom *</label>
              <input
                type="text"
                id="nom"
                name="nom"
                className="form-control"
                placeholder="Dupont"
                required
                value={formData.nom}
                onChange={handleInputChange}
                disabled={loading}
              />
            </div>
          </div>

          {/* Email */}
          <div className="mb-3">
            <label htmlFor="email" className="form-label fw-semibold">Adresse email *</label>
            <div className="input-group">
              <span className="input-group-text">
                <i className="fas fa-envelope"></i>
              </span>
              <input
                type="email"
                id="email"
                name="email"
                className="form-control"
                placeholder="jean.dupont@entreprise.com"
                required
                value={formData.email}
                onChange={handleInputChange}
                disabled={loading}
              />
            </div>
          </div>

          {/* Rôle */}
          <div className="mb-3">
            <label htmlFor="role" className="form-label fw-semibold">Rôle *</label>
            <select
              id="role"
              name="role"
              className="form-select"
              value={formData.role}
              onChange={handleInputChange}
              disabled={loading}
            >
              <option value="employe">Employé</option>
              <option value="admin">Administrateur</option>
            </select>
          </div>

          {/* Téléphone et Département */}
          <div className="row mb-3">
            <div className="col-md-6">
              <label htmlFor="telephone" className="form-label fw-semibold">Téléphone</label>
              <input
                type="tel"
                id="telephone"
                name="telephone"
                className="form-control"
                placeholder="+33 6 12 34 56 78"
                value={formData.telephone}
                onChange={handleInputChange}
                disabled={loading}
              />
            </div>
            <div className="col-md-6">
              <label htmlFor="departement" className="form-label fw-semibold">Département</label>
              <input
                type="text"
                id="departement"
                name="departement"
                className="form-control"
                placeholder="Informatique"
                value={formData.departement}
                onChange={handleInputChange}
                disabled={loading}
              />
            </div>
          </div>

          {/* Mot de passe */}
          <div className="mb-3">
            <label htmlFor="password" className="form-label fw-semibold">Mot de passe *</label>
            <div className="input-group">
              <span className="input-group-text">
                <i className="fas fa-lock"></i>
              </span>
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                name="password"
                className="form-control"
                placeholder="Min. 6 caractères"
                required
                value={formData.password}
                onChange={handleInputChange}
                disabled={loading}
              />
              <button
                type="button"
                className="btn btn-outline-secondary btn-sm"
                onClick={() => setShowPassword(!showPassword)}
                disabled={loading}
              >
                <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
              </button>
            </div>
          </div>

          {/* Confirmation mot de passe */}
          <div className="mb-4">
            <label htmlFor="confirmPassword" className="form-label fw-semibold">Confirmer le mot de passe *</label>
            <div className="input-group">
              <span className="input-group-text">
                <i className="fas fa-lock"></i>
              </span>
              <input
                type={showConfirmPassword ? 'text' : 'password'}
                id="confirmPassword"
                name="confirmPassword"
                className="form-control"
                placeholder="Confirmer le mot de passe"
                required
                value={formData.confirmPassword}
                onChange={handleInputChange}
                disabled={loading}
              />
              <button
                type="button"
                className="btn btn-outline-secondary btn-sm"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                disabled={loading}
              >
                <i className={`fas ${showConfirmPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
              </button>
            </div>
          </div>

          {/* Bouton de soumission */}
          <button
            type="submit"
            className="btn btn-primary w-100 py-2"
            disabled={loading}
          >
            {loading ? (
              <>
                <i className="fas fa-spinner fa-spin me-2"></i>
                Création du compte...
              </>
            ) : (
              <>
                <i className="fas fa-user-plus me-2"></i>
                Créer le compte
              </>
            )}
          </button>

        </form>

        {/* Liens */}
        <div className="text-center mt-4">
          <Link to="/login" className="link-dark text-decoration-none">
            <i className="fas fa-arrow-left me-2"></i>
            Retour à la connexion
          </Link>
        </div>

      </div>
    </div>
  )
}
