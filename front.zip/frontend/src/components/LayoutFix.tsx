import React from 'react';
import Header from './Header';
import RoleBasedSidebar from './RoleBasedSidebar';
import Footer from './Footer';

interface LayoutFixProps {
  title?: string;
  showNavigation?: boolean;
  children?: React.ReactNode;
}

export default function LayoutFix({ title, showNavigation = true, children }: LayoutFixProps) {
  return (
    <div className="h-screen flex flex-col">
      {/* Header fixe en haut */}
      <Header title={title || "Xpert Pro"} showNavigation={showNavigation} />
      
      {/* Conteneur principal avec sidebar et contenu */}
      <div className="flex flex-1">
        {/* Sidebar fixe à gauche qui s'étend du header au footer */}
        <div className="flex-shrink-0">
          <RoleBasedSidebar />
        </div>
        
        {/* Contenu principal avec scroll uniquement sur la page */}
        <main className="flex-1 overflow-y-auto bg-gray-50 p-6">
          {children}
        </main>
      </div>
      
      {/* Footer fixe en bas */}
      <Footer />
    </div>
  );
}
