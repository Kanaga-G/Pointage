import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header';
import Sidebar from './Sidebar';
import Footer from './Footer';

interface EmployeLayoutProps {
  title?: string;
  showNavigation?: boolean;
  children?: React.ReactNode;
}

export default function EmployeLayout({ title, showNavigation = true, children }: EmployeLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header title={title || "Xpert Pro"} showNavigation={showNavigation} />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          {children || <Outlet />}
        </main>
      </div>
      <Footer />
    </div>
  );
}
