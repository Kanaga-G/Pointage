import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../services/authService';
import { usePermissions } from './PermissionGuard';
import Icon from './Icons';

interface SidebarItem {
  id: string;
  label: string;
  icon: string; // Nom de l'icône SVG
  href: string;
  permission?: string;
  resource?: string;
  action?: string;
  badge?: number;
  children?: SidebarItem[];
}

export default function RoleBasedSidebar() {
  const location = useLocation();
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { user } = useAuth();
  const { hasPermission, canAccess, isAdmin, isManager, isHR } = usePermissions();

  const menuItems: SidebarItem[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: 'home',
      href: user?.role === 'employe' ? '/employe' : '/admin',
    },
    {
      id: 'badge',
      label: 'Badge',
      icon: 'id-card',
      href: '/badge',
    },
    ...(user?.role === 'super_admin' ? [
      {
        id: 'admins',
        label: 'Administrateurs',
        icon: 'crown',
        href: '/admin/admins',
      }
    ] : []),
    ...(user?.role === 'admin' || user?.role === 'super_admin' || user?.role === 'manager' || user?.role === 'hr' ? [
      {
        id: 'employes',
        label: 'Employés',
        icon: 'users',
        href: '/admin/employe/new',
        children: [
          {
            id: 'employees-new',
            label: 'Nouvel employé',
            icon: 'user-plus',
            href: '/admin/employe/new',
          },
          {
            id: 'employees-list',
            label: 'Liste des employés',
            icon: 'list',
            href: '/admin/employe',
          }
        ]
      }
    ] : []),
    {
      id: 'pointages',
      label: 'Pointages',
      icon: 'clock',
      href: '/pointage',
      badge: 3
    },
    {
      id: 'heures',
      label: 'Heures',
      icon: 'hourglass-half',
      href: '/heures',
    },
    {
      id: 'demandes',
      label: 'Demandes',
      icon: 'file-alt',
      href: '/employe/conges-management',
      badge: 2
    },
    {
      id: 'calendrier',
      label: 'Calendrier',
      icon: 'calendar',
      href: '/calendrier',
    },
    {
      id: 'rapports',
      label: 'Rapports',
      icon: 'chart-bar',
      href: '/employe/reports-management',
    },
    {
      id: 'parametres',
      label: 'Paramètres',
      icon: 'cog',
      href: '/settings',
    }
  ];

  // Filtrer les éléments du menu selon le rôle de l'utilisateur
  const filteredMenuItems = menuItems.filter(item => {
    // Filtrer les enfants aussi
    if (item.children) {
      item.children = item.children.filter(child => true);
    }
    
    return true;
  });

  const toggleExpanded = (itemId: string) => {
    setExpandedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const isActive = (href: string) => {
    if (href.startsWith('#')) {
      return location.hash === href;
    }
    return location.pathname.startsWith(href);
  };

  const hasAccess = (item: SidebarItem): boolean => {
    // Simplifié : tous les éléments sont accessibles selon le rôle
    return true;
  };

  const renderSidebarItem = (item: SidebarItem, level = 0) => {
    if (!hasAccess(item)) return null;

    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedItems.includes(item.id);
    const active = isActive(item.href);

    return (
      <div key={item.id} className="w-full">
        <Link
          to={item.href}
          onClick={(e) => {
            if (hasChildren) {
              e.preventDefault();
              toggleExpanded(item.id);
            }
          }}
          className={`w-full flex items-center justify-between px-3 py-2 rounded-lg transition-colors ${
            active 
              ? 'bg-blue-100 text-blue-700' 
              : 'text-gray-700 hover:bg-gray-100'
          } ${isCollapsed && !hasChildren ? 'justify-center' : ''}`}
          style={{ paddingLeft: `${level * 12 + 12}px` }}
        >
          <div className="flex items-center space-x-3">
            <Icon name={item.icon} className="w-5 h-5" />
            {!isCollapsed && (
              <span className="text-sm font-medium">{item.label}</span>
            )}
          </div>
          
          {!isCollapsed && (
            <div className="flex items-center space-x-2">
              {item.badge && (
                <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {item.badge}
                </span>
              )}
              {hasChildren && (
                <Icon 
                  name="chevron-right"
                  className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                />
              )}
            </div>
          )}
        </Link>
        
        {hasChildren && isExpanded && !isCollapsed && (
          <div className="mt-1 space-y-1">
            {item.children!.map(child => renderSidebarItem(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`bg-white border-r border-gray-200 flex flex-col h-full ${
      isCollapsed ? 'w-16' : 'w-64'
    } transition-all duration-300`}>
      {/* Header du Sidebar */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className={`flex items-center space-x-2 ${isCollapsed ? 'justify-center w-full' : ''}`}>
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">XP</span>
            </div>
            {!isCollapsed && (
              <span className="font-semibold text-gray-900">Xpert Pro</span>
            )}
          </div>
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1 rounded-lg hover:bg-gray-100"
          >
            <Icon name="bars" className="w-5 h-5 text-gray-500" />
          </button>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-2">
          {filteredMenuItems.map(item => renderSidebarItem(item))}
        </div>
      </div>

      {/* Footer du Sidebar */}
      <div className="p-4 border-t border-gray-200">
        <div className={`flex items-center space-x-3 ${isCollapsed ? 'justify-center' : ''}`}>
          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
            <span className="text-sm font-medium text-gray-600">
              {user?.prenom?.[0]}{user?.nom?.[0]}
            </span>
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {user?.prenom} {user?.nom}
              </p>
              <p className="text-xs text-gray-500 truncate capitalize">
                {user?.role}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
