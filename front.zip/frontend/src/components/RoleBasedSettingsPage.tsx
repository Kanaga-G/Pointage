import React from 'react';
import { useAuth } from '../services/authService';

export default function RoleBasedSettingsPage() {
  useAuth();
  
  return (
    <div style={{ 
      padding: '20px', 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 50%, #f1f5f9 100%)' 
    }}>
      <div style={{ 
        maxWidth: '1200px', 
        margin: '0 auto',
        background: 'rgba(255, 255, 255, 0.95)',
        backdropFilter: 'blur(20px)',
        borderRadius: '20px',
        padding: '30px',
        boxShadow: '0 20px 60px rgba(0, 0, 0, 0.1)'
      }}>
        <h1 style={{ 
          color: '#2563eb', 
          marginBottom: '30px',
          fontSize: '2rem',
          fontWeight: '700'
        }}>
          <i className="fas fa-shield-alt" style={{ marginRight: '10px' }}></i>
          Dashboard Administrateur
        </h1>
        
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
          gap: '20px',
          marginBottom: '30px'
        }}>
          <div style={{
            background: 'linear-gradient(135deg, #2563eb, #f59e0b)',
            color: 'white',
            padding: '25px',
            borderRadius: '15px',
            textAlign: 'center'
          }}>
            <i className="fas fa-users" style={{ fontSize: '2rem', marginBottom: '10px' }}></i>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '1.5rem' }}>156</h3>
            <p style={{ margin: 0 }}>Employés Total</p>
          </div>
          
          <div style={{
            background: 'linear-gradient(135deg, #10b981, #3b82f6)',
            color: 'white',
            padding: '25px',
            borderRadius: '15px',
            textAlign: 'center'
          }}>
            <i className="fas fa-user-check" style={{ fontSize: '2rem', marginBottom: '10px' }}></i>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '1.5rem' }}>142</h3>
            <p style={{ margin: 0 }}>Présents Aujourd'hui</p>
          </div>
          
          <div style={{
            background: 'linear-gradient(135deg, #f59e0b, #ef4444)',
            color: 'white',
            padding: '25px',
            borderRadius: '15px',
            textAlign: 'center'
          }}>
            <i className="fas fa-chart-line" style={{ fontSize: '2rem', marginBottom: '10px' }}></i>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '1.5rem' }}>91%</h3>
            <p style={{ margin: 0 }}>Taux de Présence</p>
          </div>
        </div>
        
        <div style={{
          background: '#f8fafc',
          padding: '20px',
          borderRadius: '10px',
          border: '1px solid #e5e7eb'
        }}>
          <h2 style={{ color: '#374151', marginBottom: '15px' }}>
            <i className="fas fa-cog" style={{ marginRight: '10px' }}></i>
            Actions Rapides
          </h2>
          <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap' }}>
            <button style={{
              background: '#2563eb',
              color: 'white',
              border: 'none',
              padding: '12px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '0.9rem'
            }}>
              <i className="fas fa-user-plus" style={{ marginRight: '5px' }}></i>
              Ajouter Employé
            </button>
            <button style={{
              background: '#10b981',
              color: 'white',
              border: 'none',
              padding: '12px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '0.9rem'
            }}>
              <i className="fas fa-file-export" style={{ marginRight: '5px' }}></i>
              Exporter Rapport
            </button>
            <button style={{
              background: '#f59e0b',
              color: 'white',
              border: 'none',
              padding: '12px 20px',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '0.9rem'
            }}>
              <i className="fas fa-chart-bar" style={{ marginRight: '5px' }}></i>
              Voir Statistiques
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
