import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'

// Sidebar - remplace `sidebar_canonique.php`
// Navigation principale avec gestion des états actifs
interface SidebarItem {
  id: string
  label: string
  icon: string
  href: string
  badge?: number
  children?: SidebarItem[]
}

export default function Sidebar() {
  const location = useLocation()
  const [expandedItems, setExpandedItems] = useState<string[]>([])
  const [isCollapsed, setIsCollapsed] = useState(false)

  const menuItems: SidebarItem[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: '📊',
      href: '/employe'
    },
    {
      id: 'profile',
      label: 'Mon Profil',
      icon: '👤',
      href: '/employe/profile'
    },
    {
      id: 'pointage',
      label: 'Pointage',
      icon: '⏰',
      href: '/employe/pointage',
      badge: 3
    },
    {
      id: 'retards',
      label: 'Retards',
      icon: '⚠️',
      href: '/employe/retards'
    },
    {
      id: 'heures',
      label: 'Heures',
      icon: '�',
      href: '/employe/heures'
    },
    {
      id: 'calendrier',
      label: 'Calendrier',
      icon: '📅',
      href: '/employe/calendrier'
    },
    {
      id: 'badges',
      label: 'Mon Badge',
      icon: '🎫',
      href: '/employe/badge'
    },
    {
      id: 'notifications',
      label: 'Notifications',
      icon: '�',
      href: '/employe/notifications',
      badge: 5
    },
    {
      id: 'parametres',
      label: 'Paramètres',
      icon: '⚙️',
      href: '/employe/settings'
    }
  ]

  const toggleExpanded = (itemId: string) => {
    setExpandedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    )
  }

  const isActive = (href: string) => {
    if (href.startsWith('#')) {
      return location.hash === href
    }
    return location.pathname.startsWith(href)
  }

  const renderSidebarItem = (item: SidebarItem, level = 0) => {
    const hasChildren = item.children && item.children.length > 0
    const isExpanded = expandedItems.includes(item.id)
    const active = isActive(item.href)

    return (
      <div key={item.id} className={`${level > 0 ? 'ml-4' : ''}`}>
        <div className="relative">
          <Link
            to={item.href}
            className={`
              flex items-center justify-between w-full px-3 py-2 rounded-lg text-sm transition-all duration-200
              ${active 
                ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-700' 
                : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
              }
              ${isCollapsed ? 'justify-center' : ''}
            `}
            onClick={() => hasChildren && toggleExpanded(item.id)}
          >
            <div className="flex items-center">
              <span className="text-lg mr-3">{item.icon}</span>
              {!isCollapsed && (
                <span className="font-medium">{item.label}</span>
              )}
            </div>
            
            {!isCollapsed && (
              <div className="flex items-center">
                {item.badge && (
                  <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full mr-2">
                    {item.badge}
                  </span>
                )}
                {hasChildren && (
                  <svg
                    className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                )}
              </div>
            )}
          </Link>
        </div>

        {hasChildren && isExpanded && !isCollapsed && (
          <div className="mt-1 space-y-1">
            {item.children!.map(child => renderSidebarItem(child, level + 1))}
          </div>
        )}
      </div>
    )
  }

  return (
    <aside className={`
      bg-white border-r border-gray-200 h-full flex flex-col transition-all duration-300
      ${isCollapsed ? 'w-16' : 'w-64'}
    `}>
      {/* Header du sidebar */}
      <div className="p-4 border-b border-gray-200 flex-shrink-0">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Menu</h2>
              <p className="text-xs text-gray-500">Navigation principale</p>
            </div>
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-2 text-gray-600 hover:text-gray-900 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <svg
              className={`w-5 h-5 transition-transform ${isCollapsed ? 'rotate-180' : ''}`}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
            </svg>
          </button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-2 flex-1 overflow-y-auto">
        {menuItems.map(item => renderSidebarItem(item))}
      </nav>

      {/* Footer du sidebar */}
      <div className="p-4 border-t border-gray-200 flex-shrink-0">
        {!isCollapsed ? (
          <div className="text-center">
            <p className="text-xs text-gray-500 mb-2">Version 2.0</p>
            <div className="flex items-center justify-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-xs text-gray-600">En ligne</span>
            </div>
          </div>
        ) : (
          <div className="text-center">
            <div className="w-2 h-2 bg-green-500 rounded-full mx-auto"></div>
          </div>
        )}
      </div>
    </aside>
  )
}
