import React from 'react'

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-semibold text-gray-900">Xpert Pro</h1>
            </div>
            <nav className="flex items-center space-x-4">
              <a href="/employes" className="text-gray-600 hover:text-gray-900">Employés</a>
              <a href="/pointages" className="text-gray-600 hover:text-gray-900">Pointages</a>
              <a href="/roles" className="text-gray-600 hover:text-gray-900">Rôles</a>
            </nav>
          </div>
        </div>
      </header>
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {children}
      </main>
    </div>
  )
}

export default Layout
