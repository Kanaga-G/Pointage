import React from 'react'

// Composant Footer - remplace le footer PHP
// Contient les informations de copyright et liens utiles
export default function Footer() {
  const currentYear = new Date().getFullYear()
  
  return (
    <footer className="bg-gray-800 text-white py-6 px-4 flex-shrink-0">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Informations société */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Xpert Pro</h3>
            <p className="text-gray-300 text-sm">
              Solution de pointage et gestion des ressources humaines
            </p>
            <p className="text-gray-400 text-xs mt-2">
              Version 2.0 - Migration React/TypeScript
            </p>
          </div>
          
          {/* Liens rapides */}
          <div>
            <h4 className="text-md font-semibold mb-3">Liens rapides</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="/admin" className="text-gray-300 hover:text-white transition-colors">
                  Dashboard Admin
                </a>
              </li>
              <li>
                <a href="/employe" className="text-gray-300 hover:text-white transition-colors">
                  Dashboard Employé
                </a>
              </li>
              <li>
                <a href="/scan" className="text-gray-300 hover:text-white transition-colors">
                  Scanner QR Code
                </a>
              </li>
              <li>
                <a href="/login" className="text-gray-300 hover:text-white transition-colors">
                  Connexion
                </a>
              </li>
            </ul>
          </div>
          
          {/* Support et contact */}
          <div>
            <h4 className="text-md font-semibold mb-3">Support</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Documentation
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Centre d'aide
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Contact technique
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  Signaler un problème
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-gray-700 mt-6 pt-4 text-center text-sm text-gray-400">
          <p>
            © {currentYear} Xpert Pro. Tous droits réservés. | 
            <a href="#" className="hover:text-white transition-colors ml-1">
              Mentions légales
            </a> | 
            <a href="#" className="hover:text-white transition-colors ml-1">
              Politique de confidentialité
            </a>
          </p>
          <p className="text-xs mt-2">
            Propulsé par Supabase et React
          </p>
        </div>
      </div>
    </footer>
  )
}
