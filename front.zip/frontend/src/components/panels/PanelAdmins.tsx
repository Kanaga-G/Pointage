import React from 'react'

// PanelAdmins : affichage minimal des administrateurs (visible pour super-admins)
export default function PanelAdmins({ data }: { data: any[] }) {
  return (
    <section id="admins" className="panel-section card bg-white p-4 rounded shadow-sm">
      <h3 className="mb-3">Admins</h3>
      {data.length === 0 ? (
        <div className="text-muted">Aucun administrateur.</div>
      ) : (
        <ul>
          {data.map((a, i) => (
            <li key={i}>{a.nom} ({a.email})</li>
          ))}
        </ul>
      )}
    </section>
  )
}
