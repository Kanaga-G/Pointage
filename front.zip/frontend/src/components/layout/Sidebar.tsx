import React, { useState } from 'react'
import { 
  Home,
  Clock,
  Calendar,
  Users,
  FileText,
  Settings,
  BarChart3,
  UserCheck,
  AlertTriangle,
  LogOut,
  ChevronDown,
  ChevronRight,
  Building,
  Award,
  TrendingUp,
  Bell,
  User
} from 'lucide-react'
import { useNavigate, useLocation } from 'react-router-dom'

interface SidebarItem {
  id: string
  label: string
  icon: React.ComponentType<any>
  path?: string
  badge?: number
  children?: SidebarItem[]
}

interface SidebarProps {
  isOpen?: boolean
  onClose?: () => void
  userRole?: 'admin' | 'employee'
}

export default function Sidebar({ isOpen = true, onClose, userRole = 'employee' }: SidebarProps) {
  const [expandedItems, setExpandedItems] = useState<string[]>([])
  const navigate = useNavigate()
  const location = useLocation()

  const adminItems: SidebarItem[] = [
    {
      id: 'dashboard',
      label: 'Tableau de bord',
      icon: Home,
      path: '/admin/dashboard'
    },
    {
      id: 'pointage',
      label: 'Pointage',
      icon: Clock,
      children: [
        { id: 'pointage-today', label: "Aujourd'hui", icon: Calendar, path: '/admin/pointage/today' },
        { id: 'pointage-history', label: 'Historique', icon: FileText, path: '/admin/pointage/history' },
        { id: 'pointage-retards', label: 'Retards', icon: AlertTriangle, path: '/admin/pointage/retards', badge: 3 }
      ]
    },
    {
      id: 'employes',
      label: 'Employés',
      icon: Users,
      children: [
        { id: 'employes-list', label: 'Liste des employés', icon: Users, path: '/admin/employes' },
        { id: 'employes-add', label: 'Ajouter un employé', icon: UserCheck, path: '/admin/employes/add' }
      ]
    },
    {
      id: 'demandes',
      label: 'Demandes',
      icon: FileText,
      children: [
        { id: 'demandes-conges', label: 'Congés', icon: Calendar, path: '/admin/demandes/conges' },
        { id: 'demandes-permissions', label: 'Permissions', icon: Clock, path: '/admin/demandes/permissions', badge: 5 }
      ]
    },
    {
      id: 'rapports',
      label: 'Rapports',
      icon: BarChart3,
      children: [
        { id: 'rapports-heures', label: 'Heures travaillées', icon: Clock, path: '/admin/rapports/heures' },
        { id: 'rapports-presence', label: 'Présence', icon: UserCheck, path: '/admin/rapports/presence' },
        { id: 'rapports-export', label: 'Export', icon: FileText, path: '/admin/rapports/export' }
      ]
    },
    {
      id: 'departements',
      label: 'Départements',
      icon: Building,
      path: '/admin/departements'
    },
    {
      id: 'parametres',
      label: 'Paramètres',
      icon: Settings,
      children: [
        { id: 'parametres-general', label: 'Général', icon: Settings, path: '/admin/parametres/general' },
        { id: 'parametres-notifications', label: 'Notifications', icon: Bell, path: '/admin/parametres/notifications' }
      ]
    }
  ]

  const employeeItems: SidebarItem[] = [
    {
      id: 'dashboard',
      label: 'Tableau de bord',
      icon: Home,
      path: '/employee/dashboard'
    },
    {
      id: 'pointage',
      label: 'Pointage',
      icon: Clock,
      path: '/employee/pointage'
    },
    {
      id: 'historique',
      label: 'Historique',
      icon: FileText,
      path: '/employee/historique'
    },
    {
      id: 'demandes',
      label: 'Mes demandes',
      icon: Calendar,
      path: '/employee/demandes'
    },
    {
      id: 'statistiques',
      label: 'Statistiques',
      icon: BarChart3,
      path: '/employee/statistiques'
    },
    {
      id: 'profil',
      label: 'Mon profil',
      icon: User,
      path: '/employee/profil'
    }
  ]

  const menuItems = userRole === 'admin' ? adminItems : employeeItems

  const toggleExpanded = (itemId: string) => {
    setExpandedItems(prev =>
      prev.includes(itemId)
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    )
  }

  const isActive = (path?: string) => {
    if (!path) return false
    return location.pathname === path || location.pathname.startsWith(path + '/')
  }

  const handleItemClick = (item: SidebarItem) => {
    if (item.children) {
      toggleExpanded(item.id)
    } else if (item.path) {
      navigate(item.path)
      if (onClose) onClose()
    }
  }

  const renderMenuItem = (item: SidebarItem, level: number = 0) => {
    const isExpanded = expandedItems.includes(item.id)
    const active = isActive(item.path)
    const hasChildren = item.children && item.children.length > 0

    return (
      <div key={item.id}>
        <button
          onClick={() => handleItemClick(item)}
          className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-all duration-200 group ${
            active
              ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-r-2 border-blue-500'
              : 'text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700'
          }`}
          style={{ paddingLeft: `${level * 12 + 12}px` }}
        >
          <item.icon className={`h-5 w-5 mr-3 ${active ? 'text-blue-500' : 'text-gray-400 group-hover:text-gray-500'}`} />
          <span className="flex-1 text-left">{item.label}</span>
          {item.badge && (
            <span className="ml-2 px-2 py-1 text-xs font-medium bg-red-500 text-white rounded-full">
              {item.badge}
            </span>
          )}
          {hasChildren && (
            <div className={`transform transition-transform duration-200 ${isExpanded ? 'rotate-90' : ''}`}>
              <ChevronRight className="h-4 w-4" />
            </div>
          )}
        </button>
        
        {hasChildren && isExpanded && (
          <div className="mt-1 space-y-1">
            {item.children!.map(child => renderMenuItem(child, level + 1))}
          </div>
        )}
      </div>
    )
  }

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside className={`
        fixed top-0 left-0 z-50 h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700
        transform transition-transform duration-300 ease-in-out
        lg:relative lg:translate-x-0
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        ${isOpen ? 'w-64' : 'w-0 lg:w-64'}
      `}>
        {/* Logo section */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Award className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900 dark:text-white">XpertPro</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {userRole === 'admin' ? 'Admin' : 'Employé'}
              </p>
            </div>
          </div>
          
          {onClose && (
            <button
              onClick={onClose}
              className="lg:hidden p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-200 dark:hover:bg-gray-700"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto h-[calc(100vh-8rem)]">
          {menuItems.map(item => renderMenuItem(item))}
        </nav>

        {/* Bottom section */}
        <div className="border-t border-gray-200 dark:border-gray-700 p-4">
          <div className="space-y-2">
            <button
              onClick={() => navigate('/settings')}
              className="w-full flex items-center px-3 py-2 text-sm font-medium text-gray-700 dark:text-gray-200 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              <Settings className="h-5 w-5 mr-3 text-gray-400" />
              Paramètres
            </button>
            <button
              onClick={() => {
                // Logique de déconnexion
                window.location.href = '/login'
              }}
              className="w-full flex items-center px-3 py-2 text-sm font-medium text-red-600 dark:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
            >
              <LogOut className="h-5 w-5 mr-3" />
              Déconnexion
            </button>
          </div>
        </div>
      </aside>
    </>
  )
}
