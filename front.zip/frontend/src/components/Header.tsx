import React from 'react'
import { Link } from 'react-router-dom'
import ProfileDropdown from './ProfileDropdown'
import Icon from './Icons'

// Composant Header - remplace `partials/header.php`
// Contient le logo, navigation, et actions utilisateur
interface HeaderProps {
  title?: string
  user?: {
    nom: string
    prenom: string
    role: string
    email: string
  }
  showNavigation?: boolean
}

export default function Header({ title = "Xpert Pro", user, showNavigation = true }: HeaderProps) {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo et titre */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">X</span>
                </div>
              </div>
              <div className="ml-3">
                <h1 className="text-xl font-bold text-gray-900">{title}</h1>
                <p className="text-xs text-gray-500">Système de pointage</p>
              </div>
            </Link>
          </div>

          {/* Actions utilisateur */}
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <button className="relative p-2 text-gray-600 hover:text-gray-900 transition-colors">
              <Icon name="bell" className="w-6 h-6" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>

            {/* ProfileDropdown */}
            <ProfileDropdown />
          </div>
        </div>
      </div>
    </header>
  );
}
