import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../services/authService'

interface ProtectedRouteProps {
  children: React.ReactNode
  requiredRole?: 'admin' | 'super_admin' | 'manager' | 'hr' | 'employe'
  redirectTo?: string
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  requiredRole,
  redirectTo = '/login'
}) => {
  const { isAuthenticated, isLoading, user } = useAuth()
  const location = useLocation()

  // Pendant le chargement, afficher un spinner
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement...</p>
        </div>
      </div>
    )
  }

  // Si non authentifié, rediriger vers login
  if (!isAuthenticated) {
    return <Navigate to={redirectTo} state={{ from: location }} replace />
  }

  // Si un rôle est requis et que l'utilisateur ne l'a pas
  if (requiredRole && user?.role !== requiredRole) {
    // Rediriger vers la page appropriée selon le rôle de l'utilisateur
    if (user?.role === 'admin' || user?.role === 'super_admin' || user?.role === 'manager' || user?.role === 'hr') {
      return <Navigate to="/admin" replace />
    } else if (user?.role === 'employe') {
      return <Navigate to="/employe" replace />
    } else {
      return <Navigate to="/login" replace />
    }
  }

  // Sinon, afficher le contenu
  return <>{children}</>
}

export default ProtectedRoute
