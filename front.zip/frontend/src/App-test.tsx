import React from 'react'

function App() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1 style={{ color: '#2563eb', marginBottom: '20px' }}>
        🎉 Xpert Pro - Page de Test
      </h1>
      <p style={{ marginBottom: '10px' }}>
        Si vous voyez ce message, React fonctionne !
      </p>
      <div style={{ 
        backgroundColor: '#f3f4f6', 
        padding: '20px', 
        borderRadius: '8px',
        marginBottom: '20px'
      }}>
        <h2>🌐 Serveurs Actifs:</h2>
        <p>Frontend: http://localhost:5173</p>
        <p>Backend: http://localhost:3003</p>
      </div>
      <div style={{ 
        backgroundColor: '#e0f2fe', 
        padding: '20px', 
        borderRadius: '8px'
      }}>
        <h2>🔐 Identifiants:</h2>
        <p><strong>Admin:</strong> admin@xpertpro.com / admin123</p>
        <p><strong>Employé:</strong> jean.dupont@xpertpro.com / password123</p>
      </div>
    </div>
  )
}

export default App
