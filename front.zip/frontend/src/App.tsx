import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import LandingPage from './pages/LandingPage'
import LoginPage from './pages/LoginPage'
import EmployeDashboardImproved from './pages/EmployeDashboardImproved'
import ModernAdminDashboard from './pages/admin/ModernAdminDashboard'
import AdminDetails from './pages/AdminDetails'
import './styles/globals.css'
import './styles/dashboard.css'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/employee/dashboard" element={<EmployeDashboardImproved />} />
        <Route path="/admin/dashboard" element={<ModernAdminDashboard />} />
        <Route path="/admin/employes" element={<ModernAdminDashboard />} />
        <Route path="/employe/dashboard" element={<EmployeDashboardImproved />} />
        <Route path="/employe/:id" element={<AdminDetails />} />
        <Route path="/admin/:id" element={<AdminDetails />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  )
}

export default App
