import React from 'react'
import { Routes, Route } from 'react-router-dom'
import LandingPage from './pages/LandingPage'
import Login from './pages/Login'

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/login/:type" element={<Login />} />
        <Route path="/admin" element={<div>Admin Dashboard</div>} />
        <Route path="/employe" element={<div>Employé Dashboard</div>} />
      </Routes>
    </div>
  )
}

export default App
